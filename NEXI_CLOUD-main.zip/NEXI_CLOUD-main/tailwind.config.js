/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './app/**/*.{js,jsx}',
    './src/**/*.{js,jsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: {
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1400px',
      },
    },
    extend: {
      fontFamily: {
        sans: ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', '"Helvetica Neue"', 'Arial', 'sans-serif'],
      },
      fontWeight: {
        light: '300',
        normal: '400', // 'normal' is equivalent to 400 by default
        semibold: '600',
      },
      fontSize: {
        'hero': 'clamp(2.5rem, 8vw + 1rem, 6rem)',
        'h2-desktop': '2.25rem',
        'h2-mobile': '1.5rem',
        'body-base': '1rem',
        'body-lg': '1.125rem',
      },
      lineHeight: {
        'body': '1.4',
      },
      colors: {
        // Apple Design Tokens
        'apple-primary': '#1d1d1f',   // For headings/body text
        'apple-secondary': '#6e6e73',  // For subheads/captions
        'apple-accent': '#0071e3',    // For links/buttons
        'apple-bg': '#ffffff',        // For page/card backgrounds

        // shadcn/ui compatible theme colors (can be mapped from Apple's if desired, or kept separate)
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))', // Often same as accent
        background: 'hsl(var(--background))', // Maps to apple-bg
        foreground: 'hsl(var(--foreground))', // Maps to apple-primary
        primary: {
          DEFAULT: 'hsl(var(--primary))', // Maps to apple-accent
          foreground: 'hsl(var(--primary-foreground))', // Text on primary buttons
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))', // Maps to apple-secondary (or a variation)
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))', // Can be same as primary or a different accent
          foreground: 'hsl(var(--accent-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        card: {
          DEFAULT: 'hsl(var(--card))', // Maps to apple-bg
          foreground: 'hsl(var(--card-foreground))', // Text in cards, maps to apple-primary
        },
      },
      spacing: {
        '2': '0.5rem', // 8px
        '4': '1rem',   // 16px
        '8': '2rem',   // 32px
        // You can add more multiples as needed: '1', '3', '5', '6', '10', '12', '16', etc.
        'px': '1px',
        '0': '0',
        '0.5': '0.125rem', // 2px
        '1': '0.25rem',   // 4px
        '1.5': '0.375rem', // 6px
        '2.5': '0.625rem', // 10px
        '3': '0.75rem',   // 12px
        '3.5': '0.875rem', // 14px
        '5': '1.25rem',   // 20px
        '6': '1.5rem',    // 24px
        '7': '1.75rem',   // 28px
        '9': '2.25rem',   // 36px
        '10': '2.5rem',   // 40px
        '11': '2.75rem',  // 44px
        '12': '3rem',     // 48px
        '14': '3.5rem',   // 56px
        '16': '4rem',     // 64px
        '20': '5rem',     // 80px
        '24': '6rem',     // 96px
        '28': '7rem',     // 112px
        '32': '8rem',     // 128px
        '36': '9rem',     // 144px
        '40': '10rem',    // 160px
        '44': '11rem',    // 176px
        '48': '12rem',    // 192px
        '52': '13rem',    // 208px
        '56': '14rem',    // 224px
        '60': '15rem',    // 240px
        '64': '16rem',    // 256px
        '72': '18rem',    // 288px
        '80': '20rem',    // 320px
        '96': '24rem',    // 384px
      },
      borderRadius: {
        lg: 'var(--radius)', // Default shadcn/ui
        md: 'calc(var(--radius) - 2px)', // Default shadcn/ui
        sm: 'calc(var(--radius) - 4px)', // Default shadcn/ui
      },
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: '0' },
        },
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(40px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        fadeInUp: 'fadeInUp 0.6s ease-out both',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
};