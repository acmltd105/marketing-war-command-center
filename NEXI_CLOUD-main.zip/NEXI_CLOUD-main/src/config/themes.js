
import React from 'react';

export const THEMES = {
  appleLight: {
    name: "Apple Light",
    className: "theme-apple-light",
    variables: {
      '--color-bg-val-rgb': '255, 255, 255',
      '--color-primary-val-rgb': '29, 29, 31',
      '--color-secondary-val-rgb': '110, 110, 115',
      '--color-accent-val-rgb': '0, 113, 227',
      '--color-input-bg-rgb': '245, 245, 247',
      '--color-border-rgb': '210, 210, 215',
      '--color-card-border-rgb': '229, 229, 229',
    }
  },
  nexieDark: {
    name: "Nexie Dark",
    className: "theme-nexie-dark",
    variables: {
      '--color-bg-val-rgb': '20, 20, 30',        
      '--color-primary-val-rgb': '230, 230, 255',  
      '--color-secondary-val-rgb': '160, 160, 190',
      '--color-accent-val-rgb': '120, 80, 220',   
      '--color-input-bg-rgb': '30, 30, 45',     
      '--color-border-rgb': '50, 50, 70',       
      '--color-card-border-rgb': '40, 40, 60',   
    }
  },
  vibrantNexie: {
    name: "Vibrant Nexie",
    className: "theme-vibrant-nexie",
    variables: {
      '--color-bg-val-rgb': '230, 240, 255',      
      '--color-primary-val-rgb': '10, 20, 40',     
      '--color-secondary-val-rgb': '80, 90, 110',  
      '--color-accent-val-rgb': '255, 50, 150',   
      '--color-input-bg-rgb': '255, 255, 255',    
      '--color-border-rgb': '180, 190, 210',    
      '--color-card-border-rgb': '200, 210, 225',  
    }
  },
  solarFlare: {
    name: "Solar Flare",
    className: "theme-solar-flare",
    variables: {
      '--color-bg-val-rgb': '10, 5, 0',
      '--color-primary-val-rgb': '255, 220, 180',
      '--color-secondary-val-rgb': '200, 150, 100',
      '--color-accent-val-rgb': '255, 100, 0',
      '--color-input-bg-rgb': '30, 20, 10',
      '--color-border-rgb': '80, 60, 40',
      '--color-card-border-rgb': '60, 40, 20',
    }
  },
  oceanicDeep: {
    name: "Oceanic Deep",
    className: "theme-oceanic-deep",
    variables: {
      '--color-bg-val-rgb': '5, 15, 25',
      '--color-primary-val-rgb': '200, 230, 255',
      '--color-secondary-val-rgb': '120, 160, 190',
      '--color-accent-val-rgb': '0, 180, 220',
      '--color-input-bg-rgb': '15, 30, 45',
      '--color-border-rgb': '40, 60, 80',
      '--color-card-border-rgb': '30, 50, 70',
    }
  },
  forestMist: {
    name: "Forest Mist",
    className: "theme-forest-mist",
    variables: {
      '--color-bg-val-rgb': '235, 245, 230',
      '--color-primary-val-rgb': '20, 50, 30',
      '--color-secondary-val-rgb': '100, 140, 110',
      '--color-accent-val-rgb': '60, 180, 90',
      '--color-input-bg-rgb': '250, 255, 248',
      '--color-border-rgb': '190, 210, 180',
      '--color-card-border-rgb': '210, 225, 200',
    }
  },
  crimsonNight: {
    name: "Crimson Night",
    className: "theme-crimson-night",
    variables: {
      '--color-bg-val-rgb': '20, 0, 5',
      '--color-primary-val-rgb': '255, 200, 210',
      '--color-secondary-val-rgb': '180, 120, 130',
      '--color-accent-val-rgb': '220, 20, 60',
      '--color-input-bg-rgb': '40, 10, 20',
      '--color-border-rgb': '70, 30, 40',
      '--color-card-border-rgb': '50, 20, 30',
    }
  },
  goldenHour: {
    name: "Golden Hour",
    className: "theme-golden-hour",
    variables: {
      '--color-bg-val-rgb': '255, 250, 230',
      '--color-primary-val-rgb': '80, 60, 20',
      '--color-secondary-val-rgb': '160, 140, 100',
      '--color-accent-val-rgb': '255, 190, 0',
      '--color-input-bg-rgb': '255, 253, 245',
      '--color-border-rgb': '220, 200, 160',
      '--color-card-border-rgb': '235, 220, 190',
    }
  },
  lavenderDreams: {
    name: "Lavender Dreams",
    className: "theme-lavender-dreams",
    variables: {
      '--color-bg-val-rgb': '240, 235, 250',
      '--color-primary-val-rgb': '60, 50, 90',
      '--color-secondary-val-rgb': '140, 130, 170',
      '--color-accent-val-rgb': '150, 100, 220',
      '--color-input-bg-rgb': '252, 250, 255',
      '--color-border-rgb': '200, 190, 220',
      '--color-card-border-rgb': '220, 210, 235',
    }
  },
  slateGray: {
    name: "Slate Gray",
    className: "theme-slate-gray",
    variables: {
      '--color-bg-val-rgb': '50, 60, 70',
      '--color-primary-val-rgb': '220, 225, 230',
      '--color-secondary-val-rgb': '130, 140, 150',
      '--color-accent-val-rgb': '100, 150, 200',
      '--color-input-bg-rgb': '65, 75, 85',
      '--color-border-rgb': '90, 100, 110',
      '--color-card-border-rgb': '75, 85, 95',
    }
  },
  mintRefresh: {
    name: "Mint Refresh",
    className: "theme-mint-refresh",
    variables: {
      '--color-bg-val-rgb': '230, 255, 245',
      '--color-primary-val-rgb': '10, 70, 50',
      '--color-secondary-val-rgb': '100, 160, 140',
      '--color-accent-val-rgb': '50, 200, 150',
      '--color-input-bg-rgb': '248, 255, 252',
      '--color-border-rgb': '180, 220, 200',
      '--color-card-border-rgb': '200, 235, 220',
    }
  },
  sandstone: {
    name: "Sandstone",
    className: "theme-sandstone",
    variables: {
      '--color-bg-val-rgb': '245, 235, 220',
      '--color-primary-val-rgb': '90, 70, 50',
      '--color-secondary-val-rgb': '170, 150, 130',
      '--color-accent-val-rgb': '210, 150, 80',
      '--color-input-bg-rgb': '253, 248, 240',
      '--color-border-rgb': '210, 190, 170',
      '--color-card-border-rgb': '225, 210, 190',
    }
  },
  graphiteDark: {
    name: "Graphite Dark",
    className: "theme-graphite-dark",
    variables: {
      '--color-bg-val-rgb': '30, 30, 35',
      '--color-primary-val-rgb': '210, 210, 215',
      '--color-secondary-val-rgb': '120, 120, 125',
      '--color-accent-val-rgb': '100, 180, 220',
      '--color-input-bg-rgb': '45, 45, 50',
      '--color-border-rgb': '70, 70, 75',
      '--color-card-border-rgb': '55, 55, 60',
    }
  },
  roseGold: {
    name: "Rose Gold",
    className: "theme-rose-gold",
    variables: {
      '--color-bg-val-rgb': '250, 240, 238',
      '--color-primary-val-rgb': '90, 60, 55',
      '--color-secondary-val-rgb': '190, 150, 145',
      '--color-accent-val-rgb': '200, 120, 110',
      '--color-input-bg-rgb': '255, 250, 248',
      '--color-border-rgb': '220, 200, 195',
      '--color-card-border-rgb': '235, 220, 215',
    }
  },
  electricBlue: {
    name: "Electric Blue",
    className: "theme-electric-blue",
    variables: {
      '--color-bg-val-rgb': '15, 25, 55',
      '--color-primary-val-rgb': '220, 240, 255',
      '--color-secondary-val-rgb': '130, 150, 190',
      '--color-accent-val-rgb': '0, 120, 255',
      '--color-input-bg-rgb': '25, 40, 70',
      '--color-border-rgb': '50, 70, 110',
      '--color-card-border-rgb': '40, 55, 90',
    }
  },
};
