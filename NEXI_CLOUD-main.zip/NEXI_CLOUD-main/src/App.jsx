import React, { useState, useEffect, createContext, useContext } from 'react';
import { Routes, Route, useLocation, Link, Navigate, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { MainApplication } from '@/components/MainApplication';
import { DashboardBuilder } from '@/components/DashboardBuilder';
import { JourneyBuilder } from '@/components/JourneyBuilder';
import { ReportsPage } from '@/components/ReportsPage';
import { SettingsPage } from '@/components/SettingsPage';
import { PredictorTool } from '@/components/PredictorTool';
import { StudioBuilder } from '@/components/StudioBuilder';
import { FlexInsights } from '@/components/FlexInsights';
import { LeadIntelHub } from '@/components/LeadIntelHub';
import { BotArmyBuilder } from '@/components/BotArmyBuilder';
import { BackupProviders } from '@/components/BackupProviders';
import { ComplianceCenter } from '@/components/ComplianceCenter';
import { MachineHealth } from '@/components/MachineHealth';
import { LeadLifecycleManager } from '@/components/LeadLifecycleManager';
import { LeadResumeEngine } from '@/components/LeadResumeEngine.jsx';
import { GiveawayManager } from '@/components/GiveawayManager.jsx';
import { GPTCampaignBrain } from '@/components/GPTCampaignBrain.jsx';
import { Sidebar } from '@/components/Sidebar'; 
import { AdvancedFeaturesHub } from '@/components/AdvancedFeaturesHub';
import { DeploymentPlanWidget } from '@/components/DeploymentPlanWidget';
import { LiveStatsHeader } from '@/components/LiveStatsHeader';
import { HeroVideo } from '@/components/HeroVideo';
import { TwilioFlowBuilder } from '@/components/TwilioFlowBuilder';
import { PhoneServicesManager } from '@/components/PhoneServicesManager';
import { BillingUsageManager } from '@/components/BillingUsageManager';
import { TwilioAPIs } from '@/components/TwilioAPIs';
import { ApiProfileManager } from '@/components/ApiProfileManager';
import { AuthPage } from '@/components/AuthPage';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { IgnitionSequence } from '@/components/IgnitionSequence'; // New Import
import { THEMES } from '@/config/themes';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/supabaseClient';
import { useAppContext } from '@/contexts/AppContext';

export const ThemeContext = createContext();
export const AuthContext = createContext();

export const useTheme = () => useContext(ThemeContext);
export const useAuth = () => useContext(AuthContext);

function App() {
  const location = useLocation();
  const navigate = useNavigate();
  
  const [appReady, setAppReady] = useState(false);
  const [showHeroVideo, setShowHeroVideo] = useState(true);
  const [currentTheme, setCurrentTheme] = useState('appleLight');
  const [isThemeLoading, setIsThemeLoading] = useState(true);
  const { withSavingState } = useAppContext();
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [isDevelopmentBypassActive, setIsDevelopmentBypassActive] = useState(true); // DEVELOPMENT BYPASS FLAG

  useEffect(() => {
    if (isDevelopmentBypassActive) {
      setAuthLoading(false); 
      setSession({ user: { id: 'dev-bypass-user' } }); 
      console.warn("DEVELOPMENT AUTH BYPASS IS ACTIVE!");
      return; 
    }

    const getSession = async () => {
      try {
        const { data: { session: currentSession }, error } = await supabase.auth.getSession();
        if (error) {
          console.error("Error getting session:", error.message);
        }
        setSession(currentSession);
      } catch (e) {
        console.error("Exception getting session:", e);
      } finally {
        setAuthLoading(false);
      }
    };
    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, sessionState) => {
      setSession(sessionState);
      if (!sessionState && location.pathname !== '/auth' && !isDevelopmentBypassActive) {
        navigate('/auth');
      }
      if (authLoading) setAuthLoading(false); 
    });

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, [navigate, location.pathname, authLoading, isDevelopmentBypassActive]);

  useEffect(() => {
    const fetchTheme = async () => {
      setIsThemeLoading(true); 
      try {
        const { data, error } = await supabase
          .from('app_settings')
          .select('theme_name')
          .eq('id', 1)
          .single();

        if (data && data.theme_name && THEMES[data.theme_name]) {
          setCurrentTheme(data.theme_name);
        } else if (error) {
          console.error("Error fetching theme:", error.message);
          setCurrentTheme('appleLight');
        }
      } catch (e) {
        console.error("Exception fetching theme:", e);
        setCurrentTheme('appleLight'); 
      } finally {
        setIsThemeLoading(false);
      }
    };

    fetchTheme();
  }, []);

  useEffect(() => {
    const theme = THEMES[currentTheme];
    if (theme) {
      document.documentElement.className = theme.className; 
      Object.entries(theme.variables).forEach(([key, value]) => {
        document.documentElement.style.setProperty(key, value);
      });
    }
  }, [currentTheme]);

  useEffect(() => {
    if (!isThemeLoading && !authLoading) {
      if (showHeroVideo && location.pathname !== '/auth' && !isDevelopmentBypassActive) {
        // Hero video logic
      } else {
        const timer = setTimeout(() => setAppReady(true), 300); 
        return () => clearTimeout(timer);
      }
    }
  }, [isThemeLoading, authLoading, showHeroVideo, location.pathname, isDevelopmentBypassActive]);


  const handleVideoEnd = () => {
    setShowHeroVideo(false);
  };

  const setTheme = (themeName) => {
    if (THEMES[themeName]) {
      setCurrentTheme(themeName);
      withSavingState(async () => {
        const { error } = await supabase
          .from('app_settings')
          .update({ theme_name: themeName })
          .eq('id', 1);
        
        if(error) {
          console.error("Error saving theme:", error.message);
          throw error; 
        }
      });
    }
  };

  const toggleTheme = () => {
    const themeKeys = Object.keys(THEMES);
    const currentIndex = themeKeys.indexOf(currentTheme);
    const nextIndex = (currentIndex + 1) % themeKeys.length;
    setTheme(themeKeys[nextIndex]);
  };

  if (showHeroVideo && location.pathname !== '/auth' && !appReady && !isDevelopmentBypassActive) {
    return <HeroVideo onVideoEnd={handleVideoEnd} />;
  }

  if (!appReady) { 
    return (
      <div className={cn("min-h-screen flex items-center justify-center bg-apple-bg text-apple-primary overflow-hidden", currentTheme ? THEMES[currentTheme]?.className : THEMES.appleLight.className)}>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15, duration: 0.5 }}
          className="text-center"
        >
          <svg className="animate-spin h-10 w-10 text-apple-accent mx-auto mb-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="text-sm text-apple-secondary">Initializing NEXIE Command Center...</p>
          {isDevelopmentBypassActive && <p className="text-xs text-red-500 font-bold mt-2">AUTH BYPASS ACTIVE</p>}
        </motion.div>
      </div>
    );
  }
  
  return (
    <AuthContext.Provider value={{ session, setSession, isDevelopmentBypassActive, setIsDevelopmentBypassActive }}>
    <ThemeContext.Provider value={{ currentTheme, toggleTheme, setTheme, themes: THEMES }}>
      <div className={cn("app-container marketing-bg flex flex-col min-h-screen max-h-screen", currentTheme ? THEMES[currentTheme]?.className : THEMES.appleLight.className, (!session && !isDevelopmentBypassActive) ? "overflow-hidden" : "overflow-y-auto")}>
        {(session || isDevelopmentBypassActive) && <DeploymentPlanWidget />}
        {(session || isDevelopmentBypassActive) && <LiveStatsHeader />}
        {isDevelopmentBypassActive && (
          <div className="fixed top-0 left-1/2 -translate-x-1/2 bg-red-500 text-white px-4 py-1 text-xs font-bold z-50 rounded-b-lg">
            DEVELOPMENT AUTH BYPASS ACTIVE
          </div>
        )}
        <div className={cn("flex flex-grow min-h-0 bg-transparent text-apple-primary", (session || isDevelopmentBypassActive) ? "pt-[60px]" : "")}>
          {(session || isDevelopmentBypassActive) && <Sidebar />} 
          <main className={cn("flex-grow flex flex-col bg-transparent", (session || isDevelopmentBypassActive) ? "p-6 md:p-8 lg:p-10 overflow-y-auto" : "h-full w-full")}>
            <AnimatePresence mode="wait">
              <Routes location={location} key={location.pathname}>
                <Route path="/auth" element={<AuthPage />} />
                <Route path="/" element={<ProtectedRoute><MainApplication /></ProtectedRoute>} />
                <Route path="/ignition-sequence" element={<ProtectedRoute><IgnitionSequence /></ProtectedRoute>} /> {/* New Route */}
                <Route path="/dashboard-builder" element={<ProtectedRoute><DashboardBuilder /></ProtectedRoute>} />
                <Route path="/journey-builder" element={<ProtectedRoute><JourneyBuilder /></ProtectedRoute>} />
                <Route path="/lead-lifecycle" element={<ProtectedRoute><LeadLifecycleManager /></ProtectedRoute>} />
                <Route path="/predictor" element={<ProtectedRoute><PredictorTool /></ProtectedRoute>} />
                <Route path="/studio-builder" element={<ProtectedRoute><StudioBuilder /></ProtectedRoute>} />
                <Route path="/twilio-flow-builder" element={<ProtectedRoute><TwilioFlowBuilder /></ProtectedRoute>} />
                <Route path="/phone-services" element={<ProtectedRoute><PhoneServicesManager /></ProtectedRoute>} />
                <Route path="/billing" element={<ProtectedRoute><BillingUsageManager /></ProtectedRoute>} />
                <Route path="/flex-insights" element={<ProtectedRoute><FlexInsights /></ProtectedRoute>} />
                <Route path="/lead-intel-hub" element={<ProtectedRoute><LeadIntelHub /></ProtectedRoute>} />
                <Route path="/bot-army-builder" element={<ProtectedRoute><BotArmyBuilder /></ProtectedRoute>} />
                <Route path="/backup-providers" element={<ProtectedRoute><BackupProviders /></ProtectedRoute>} />
                <Route path="/compliance-center" element={<ProtectedRoute><ComplianceCenter /></ProtectedRoute>} />
                <Route path="/machine-health" element={<ProtectedRoute><MachineHealth /></ProtectedRoute>} />
                <Route path="/lead-resume-engine" element={<ProtectedRoute><LeadResumeEngine /></ProtectedRoute>} />
                <Route path="/giveaway-manager" element={<ProtectedRoute><GiveawayManager /></ProtectedRoute>} />
                <Route path="/gpt-campaign-brain" element={<ProtectedRoute><GPTCampaignBrain /></ProtectedRoute>} />
                <Route path="/advanced-features" element={<ProtectedRoute><AdvancedFeaturesHub /></ProtectedRoute>} />
                <Route path="/reports" element={<ProtectedRoute><ReportsPage /></ProtectedRoute>} />
                <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
                <Route path="/twilio-apis" element={<ProtectedRoute><TwilioAPIs /></ProtectedRoute>} />
                <Route path="/api-profile-manager" element={<ProtectedRoute><ApiProfileManager /></ProtectedRoute>} />
                 <Route path="*" element={<Navigate to={(session || isDevelopmentBypassActive) ? "/" : "/auth"} replace />} />
              </Routes>
            </AnimatePresence>
          </main>
        </div>
        <Toaster />
      </div>
    </ThemeContext.Provider>
    </AuthContext.Provider>
  );
}

export default App;