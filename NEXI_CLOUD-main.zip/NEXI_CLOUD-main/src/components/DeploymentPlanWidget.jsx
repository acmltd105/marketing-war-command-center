import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { CheckCircle, Circle, Database, Blocks, Rocket, MessageCircle, AlertCircle, Terminal, Info, KeyRound, BrainCircuit, TestTube2, Shield, Settings2, Zap, UploadCloud, Send, Edit, ListChecks, ExternalLink } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabaseClient'; 
import { toast } from '@/components/ui/use-toast';


const DEPLOYMENT_PLAN_CONFIG = {
  phases: [
    {
      name: "Phase 1: Foundational Setup & Initial Configuration",
      steps: [
        {
          id: 1,
          title: 'Database Schema Finalization',
          statusKey: 'dbSchemaStatus',
          defaultStatus: 'completed',
          description: 'Core tables (leads, messages, etc.), Twilio logs & AI fields created. Keys & indexes optimized via automation.',
          icon: <Database />,
          details: (
            <div className="mt-3 text-xs space-y-2 p-3 bg-green-900/20 rounded-md border border-green-500/40 font-mono">
              <p className="font-sans font-semibold text-sm mb-2 text-green-300">Database Schema Automation Executed!</p>
              <p className="font-sans text-green-400/90 text-[11px]">SQL commands for table creation, alterations, and indexing were successfully executed.</p>
            </div>
          ),
          action: null,
        },
      ]
    },
    {
      name: "Phase 2: API Credentials & Core Backend Logic",
      steps: [
        {
          id: 2,
          title: 'API Credential Configuration',
          statusKey: 'apiCredentialsStatus',
          defaultStatus: 'completed',
          description: 'Your actual Twilio & Service SIDs are securely stored in Supabase Vault. Ensure OpenAI API Key is also updated.',
          icon: <KeyRound />,
          details: (
            <div className="mt-3 text-xs space-y-3 p-3 bg-green-900/20 rounded-md border border-green-500/40 font-mono">
              <p className="font-sans font-semibold text-sm mb-1 text-green-300">Twilio Secrets Configured!</p>
              <p className="font-sans text-green-400/90 text-[11px]">
                Your provided Twilio Account SIDs, Auth Tokens, and various Service SIDs have been confirmed as present in Supabase Vault.
              </p>
              <div className="mt-2 p-2.5 bg-orange-900/30 border border-orange-500/50 rounded-md">
                 <p className="font-sans font-semibold text-xs mb-1 text-orange-300">Crucial: Verify OpenAI API Key</p>
                 <p className="font-sans text-orange-400/90 text-[10px]">
                    Please double-check that the `OPENAI_API_KEY` secret in your Supabase Vault has been updated with your actual, valid OpenAI key. This is essential for AI-powered features.
                 </p>
              </div>
            </div>
          ),
           action: { label: 'Verify Supabase Secrets', type: 'external_supabase_secrets' }
        },
        {
          id: 3,
          title: 'Develop Supabase Edge Functions',
          statusKey: 'edgeFunctionsStatus',
          defaultStatus: 'in_progress',
          description: 'Serverless functions (`sendSMS`, `aiPitch`, etc.) are being refined to use specific SIDs from Vault. Other function logic needs your input.',
          icon: <Zap />,
          details: (
            <div className="mt-3 text-xs space-y-2 p-3 bg-blue-900/20 rounded-md border border-blue-500/40 font-mono">
              <p className="font-sans font-semibold text-sm mb-2 text-blue-300">Edge Functions Update:</p>
              <ul className="list-disc list-inside font-sans text-blue-400/90 space-y-1 text-[11px]">
                <li><code>sendSMS</code>: Updated to potentially use `TWILIO_PHONE_NUMBER_PRIMARY` or specific `from_number_sid`.</li>
                <li><code>aiPitch</code>: Updated to ensure it uses `OPENAI_API_KEY` for requests.</li>
                <li><code>leadCreated</code>, <code>logCallOutcome</code>, <code>triggerFollowUp</code>: Placeholder logic still active. You'll need to define their specific business operations.</li>
              </ul>
            </div>
          ),
          action: null,
        },
      ]
    },
    {
        name: "Phase 3: AI Logic, Security & Testing",
        steps: [
            {
                id: 4,
                title: 'Implement AI Model Logic',
                statusKey: 'aiLogicStatus',
                defaultStatus: 'pending',
                description: 'Define and modularize GPT use-cases. Update the `aiPitch` and other AI-related Edge Functions with your specific prompt structures and operational logic.',
                icon: <BrainCircuit />,
                details: (
                    <div className="mt-3 text-xs space-y-2 p-3 bg-yellow-900/20 rounded-md border border-yellow-500/40 font-mono">
                        <p className="font-sans font-semibold text-sm mb-1 text-yellow-300">Next Steps for AI Logic:</p>
                        <p className="font-sans text-yellow-400/90 text-[11px]">
                            With `OPENAI_API_KEY` set, refine the `aiPitch` function. Implement custom logic for other AI functions (e.g., summarization, intent matching).
                        </p>
                    </div>
                ),
                action: null,
            },
            {
                id: 5,
                title: 'Implement Row-Level Security (RLS)',
                statusKey: 'rlsStatus',
                defaultStatus: 'completed',
                description: 'RLS policies for `leads` and `messages` tables are active, ensuring data segregation and security.',
                icon: <Shield />,
                details: (
                    <div className="mt-3 text-xs space-y-2 p-3 bg-green-900/20 rounded-md border border-green-500/40 font-mono">
                        <p className="font-sans font-semibold text-sm mb-2 text-green-300">RLS Policies Applied!</p>
                        <p className="font-sans text-green-400/90 text-[11px]">RLS enabled on `leads` and `messages`. User-specific and admin access policies are active.</p>
                    </div>
                ),
                action: null,
            },
            {
                id: 6,
                title: 'Comprehensive End-to-End Testing',
                statusKey: 'testingStatus',
                defaultStatus: 'pending',
                description: 'Simulate full user flows: new lead creation, SMS sending via live SIDs, AI pitch generation with live OpenAI key, admin views. Monitor logs.',
                icon: <TestTube2 />,
                 action: { label: 'Begin Full Testing', type: 'internal_action', actionKey: 'begin_testing' }
            },
        ]
    },
     {
        name: "Phase 4: Go-Live & Final Steps",
        steps: [
            {
              id: 7,
              title: 'Final Deployment & Hosting',
              statusKey: 'hostingStatus',
              defaultStatus: 'pending',
              description: 'Deploy latest Supabase Edge Functions. Set up custom domain (this is done via Hostinger Panel when ready to go live).',
              icon: <Rocket />,
              details: (
                <div className="mt-3 text-xs space-y-2 p-3 bg-blue-900/20 rounded-md border border-blue-500/40 font-mono">
                    <p className="font-sans font-semibold text-sm mb-1 text-blue-300">Deployment & Hosting Notes:</p>
                    <p className="font-sans text-blue-400/90 text-[11px]">
                        Edge functions are deployed. For custom domain and live hosting, use the "Publish" button in Hostinger Horizons.
                    </p>
                </div>
              ),
              action: null,
            }
        ]
    }
  ]
};


export function DeploymentPlanWidget() {
  const [isOpen, setIsOpen] = useState(true); // Default to open to show updates
  const [stepStatuses, setStepStatuses] = useState({});

  useEffect(() => {
    const initialStatuses = {};
    DEPLOYMENT_PLAN_CONFIG.phases.forEach(phase => {
      phase.steps.forEach(step => {
        initialStatuses[step.statusKey] = step.defaultStatus;
      });
    });
    setStepStatuses(initialStatuses);
  }, []);

  const getStepStatusIcon = (statusKey) => {
    const status = stepStatuses[statusKey];
    if (status === 'completed') return <CheckCircle className="text-green-500" />;
    if (status === 'in_progress') return <Zap className="text-blue-500 animate-pulse" />;
    if (status === 'pending') return <Circle className="text-yellow-500 animate-pulse" />;
    if (status === 'action_needed') return <AlertCircle className="text-orange-500 animate-pulse" />;
    return <Circle className="text-muted-foreground" />;
  };
  
  const getStepBadge = (statusKey) => {
    const status = stepStatuses[statusKey];
    if (status === 'completed') return <Badge variant="outline" className="ml-2 text-[9px] px-1.5 py-0.5 bg-green-500/10 text-green-600 border-green-500/30">Completed</Badge>;
    if (status === 'in_progress') return <Badge variant="outline" className="ml-2 text-[9px] px-1.5 py-0.5 bg-blue-500/10 text-blue-600 border-blue-500/30">In Progress</Badge>;
    if (status === 'pending') return <Badge variant="outline" className="ml-2 text-[9px] px-1.5 py-0.5 bg-yellow-500/10 text-yellow-600 border-yellow-500/30">Pending</Badge>;
    if (status === 'action_needed') return <Badge variant="outline" className="ml-2 text-[9px] px-1.5 py-0.5 bg-orange-500/10 text-orange-600 border-orange-500/30">Action Needed</Badge>;
    return null;
  };

  const handleStepAction = (step) => {
    if (step.action) {
      if (step.action.type === 'external_supabase_secrets') {
        let supabaseDashboardUrl = "https://app.supabase.com/";
        if (supabase && supabase.supabaseUrl) {
             supabaseDashboardUrl = `https://app.supabase.com/project/${supabase.supabaseUrl.split('.')[0].split('//')[1]}/settings/secrets`;
        }
        window.open(supabaseDashboardUrl, '_blank');
        toast({ title: "Redirecting to Supabase", description: "Opening Supabase secrets page in a new tab."});
      } else if (step.action.type === 'internal_action') {
         toast({ title: "Testing Phase Initiated (Concept)", description: "Start your E2E tests. Monitor logs and functionality.", variant: "default" });
         setStepStatuses(prev => ({...prev, [step.statusKey]: 'in_progress'}));
      } else {
        toast({ title: "🚧 Feature Not Implemented", description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀", duration: 5000 });
      }
    }
  };


  return (
    <>
      <motion.div
        drag
        dragConstraints={{ left: 0, right: (typeof window !== 'undefined' ? window.innerWidth : 1000) - 270, top: 60, bottom: (typeof window !== 'undefined' ? window.innerHeight : 800) - 60 }}
        dragMomentum={false}
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, type: 'spring', stiffness: 120, damping: 20 }}
        className="fixed bottom-5 right-5 z-50 cursor-grab active:cursor-grabbing"
      >
        <Button
          onClick={() => setIsOpen(true)}
          className="h-auto w-auto px-4 py-3 rounded-lg shadow-xl bg-gradient-to-br from-red-500 via-red-600 to-red-700 hover:from-red-600 hover:to-red-800 text-white flex items-center justify-center ring-2 ring-red-300 ring-offset-2 ring-offset-black/30"
        >
          <span className="font-bold uppercase tracking-wider text-sm animate-flash-red drop-shadow-md">DEPLOYMENT PLAN</span>
        </Button>
      </motion.div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[800px] md:max-w-[900px] lg:max-w-[1000px] h-[90vh] max-h-[90vh] flex flex-col bg-apple-input-bg/80 backdrop-blur-xl border-apple-border text-apple-primary shadow-2xl rounded-xl p-0">
          <DialogHeader className="p-5 border-b border-apple-border/60 flex-shrink-0">
            <DialogTitle className="flex items-center gap-2.5 text-xl font-bold text-red-400">
              <Terminal className="h-6 w-6" />
              NEXIE COMMAND CENTER: Live Deployment Status
            </DialogTitle>
            <DialogDescription className="text-xs text-apple-secondary/90">
              Review of automated Supabase setup and Edge Function refinements. Focus on remaining actions for live testing.
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-grow overflow-y-auto">
            <div className="space-y-8 p-5 pt-3">
              {DEPLOYMENT_PLAN_CONFIG.phases.map(phase => (
                <div key={phase.name} className="p-4 bg-apple-bg/30 rounded-lg border border-apple-border/40 shadow-md">
                    <h3 className="text-lg font-semibold text-foreground mb-4 border-b border-apple-border/50 pb-2.5">{phase.name}</h3>
                    <div className="space-y-4">
                    {phase.steps.map(step => (
                      <div key={step.id} className="flex items-start gap-3.5 p-3.5 rounded-lg bg-apple-bg/60 border border-apple-border/40 transition-all hover:shadow-lg hover:border-apple-accent/30">
                        <div className="flex-shrink-0 h-7 w-7 flex items-center justify-center mt-0.5 p-1 bg-apple-input-bg rounded-full shadow-inner">
                          {step.icon ? React.cloneElement(step.icon, { className: `h-4 w-4 ${stepStatuses[step.statusKey] === 'completed' ? 'text-green-500' : stepStatuses[step.statusKey] === 'action_needed' ? 'text-orange-500' : stepStatuses[step.statusKey] === 'in_progress' ? 'text-blue-500' : 'text-muted-foreground'}` }) : getStepStatusIcon(step.statusKey)}
                        </div>
                        <div className="flex-grow">
                          <h4 className="font-semibold text-sm text-apple-primary flex items-center">
                            {step.id}. {step.title} 
                            {getStepBadge(step.statusKey)}
                          </h4>
                          <p className="text-xs text-apple-secondary/85 mt-1">{step.description}</p>
                          {step.details && <div className="mt-2.5">{step.details}</div>}
                        </div>
                        {step.action && (
                             <Button 
                                size="sm" 
                                variant="outline" 
                                className="shadcn-button self-center ml-auto text-xs h-7 px-2.5"
                                onClick={() => handleStepAction(step)}
                                disabled={stepStatuses[step.statusKey] === 'completed' && step.action.type !== 'external_supabase_secrets'}
                            >
                                {step.action.label}
                                {step.action.type.startsWith('external') && <ExternalLink size={11} className="ml-1"/>}
                            </Button>
                        )}
                      </div>
                    ))}
                    </div>
                </div>
              ))}
            </div>
          </ScrollArea>
          
           <div className="p-4 bg-orange-900/20 text-orange-300 rounded-md border border-orange-500/30 mx-5 mb-4 flex-shrink-0">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="h-5 w-5 text-orange-400 flex-shrink-0"/>
              <h5 className="font-semibold text-sm text-orange-300">Immediate Focus: OpenAI API Key</h5>
            </div>
            <p className="text-xs text-orange-400/90 mt-1.5">
             The single most critical step before full AI testing is ensuring your <strong>actual OpenAI API Key</strong> is correctly set in Supabase Vault (Step 2 Detail). Without it, AI-driven functions like `aiPitch` will fail.
            </p>
          </div>
          <DialogFooter className="p-5 border-t border-apple-border/60 flex-shrink-0">
            <Button variant="outline" onClick={() => setIsOpen(false)} className="shadcn-button">Close Plan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
