
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, ShoppingCart, Clock, GitFork, Mail, MessageSquare, UserPlus, Heart, Zap, Award, Repeat, Megaphone, ShieldCheck, Gem, Share2, TrendingUp } from 'lucide-react';

const templates = [
  {
    title: "Abandoned Cart Recovery",
    description: "Nudge customers who add items to their cart but don't complete the purchase within a set time.",
    category: "E-Commerce",
    color: "border-sky-500/30",
    flow: [
      { icon: ShoppingCart, label: "Item Added to Cart" },
      { icon: Clock, label: "Wait 2 Hours" },
      { icon: GitFork, label: "Purchased?" },
      { icon: MessageSquare, label: "Send SMS Reminder" },
    ]
  },
  {
    title: "New User Onboarding",
    description: "Welcome new users with a series of helpful messages to guide them to activation.",
    category: "SaaS",
    color: "border-green-500/30",
    flow: [
      { icon: UserPlus, label: "User Signs Up" },
      { icon: Mail, label: "Send Welcome Email" },
      { icon: Clock, label: "Wait 1 Day" },
      { icon: Award, label: "Check for 'Aha' Moment" },
    ]
  },
  {
    title: "Win-Back Lapsed Customers",
    description: "Re-engage customers who haven't made a purchase or logged in for a while with a special offer.",
    category: "Retention",
    color: "border-amber-500/30",
    flow: [
      { icon: Heart, label: "User becomes 'Inactive'" },
      { icon: Clock, label: "Wait 30 Days" },
      { icon: Megaphone, label: "Send 'We Miss You' Offer" },
      { icon: GitFork, label: "Did they convert?" },
    ]
  },
  {
    title: "Post-Purchase Feedback",
    description: "Automatically ask for a review or feedback a few days after a customer's order is delivered.",
    category: "E-Commerce",
    color: "border-sky-500/30",
    flow: [
      { icon: Zap, label: "Order Delivered" },
      { icon: Clock, label: "Wait 3 Days" },
      { icon: MessageSquare, label: "Send NPS Survey via SMS" },
      { icon: Mail, label: "Follow-up Email" },
    ]
  },
   {
    title: "Subscription Renewal Reminder",
    description: "Proactively notify customers before their subscription is about to renew to reduce churn.",
    category: "SaaS",
    color: "border-green-500/30",
    flow: [
      { icon: Repeat, label: "Sub renewal in 7 days" },
      { icon: Mail, label: "Send Reminder Email" },
      { icon: Clock, label: "Wait 5 Days" },
      { icon: MessageSquare, label: "Final SMS Alert" },
    ]
  },
  {
    title: "Appointment Reminders",
    description: "Reduce no-shows by sending automated reminders before a scheduled appointment.",
    category: "Services",
    color: "border-purple-500/30",
    flow: [
      { icon: Zap, label: "Appointment Booked" },
      { icon: Clock, label: "Wait until 24hrs before" },
      { icon: MessageSquare, label: "Send SMS Confirmation" },
      { icon: Clock, label: "Wait until 1hr before" },
    ]
  },
  {
    title: "Post-Enrollment Nurture",
    description: "Keep new clients engaged and successful with a welcome series, check-ins, and helpful tips.",
    category: "Retention",
    color: "border-indigo-500/30",
    flow: [
      { icon: UserPlus, label: "Client Enrolled" },
      { icon: Mail, label: "Welcome Email" },
      { icon: Clock, label: "Wait 7 Days" },
      { icon: MessageSquare, label: "Satisfaction Check-in" },
    ]
  },
  {
    title: "Dynamic Upsell Engine",
    description: "Automatically offer relevant upgrades or add-ons based on how clients use your product.",
    category: "Growth",
    color: "border-teal-500/30",
    flow: [
      { icon: Zap, label: "Feature Usage Trigger" },
      { icon: TrendingUp, label: "Qualifies for Upsell" },
      { icon: Mail, label: "Send Targeted Offer" },
      { icon: GitFork, label: "Converted?" },
    ]
  },
  {
    title: "Referral Program Kick-off",
    description: "Turn happy customers into advocates by inviting them to your referral program after a positive signal.",
    category: "Growth",
    color: "border-teal-500/30",
    flow: [
      { icon: Award, label: "Positive NPS Score" },
      { icon: Clock, label: "Wait 1 Day" },
      { icon: Share2, label: "Invite to Refer" },
      { icon: Gem, label: "Reward for Referral" },
    ]
  },
  {
    title: "Loyalty Milestone Reward",
    description: "Celebrate customer loyalty by automatically sending rewards on anniversaries or spending milestones.",
    category: "Retention",
    color: "border-indigo-500/30",
    flow: [
      { icon: ShieldCheck, label: "1-Year Anniversary" },
      { icon: Gem, label: "Send Loyalty Gift" },
      { icon: MessageSquare, label: "Thank You Message" },
      { icon: Heart, label: "Confirm Engagement" },
    ]
  },
];

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.05,
      duration: 0.5,
      ease: 'easeOut'
    }
  })
};

const TemplateCard = ({ template, index }) => (
  <motion.div variants={cardVariants} custom={index}>
    <Card className={`h-full flex flex-col frosty-glass p-0.5 border ${template.color}`}>
      <CardHeader className="p-4">
        <div className="flex justify-between items-start">
            <div>
                <CardTitle className="text-base font-semibold text-foreground">{template.title}</CardTitle>
                <CardDescription className="text-xs mt-1">{template.description}</CardDescription>
            </div>
            <Badge variant="outline" className="text-[10px] uppercase tracking-wider">{template.category}</Badge>
        </div>
      </CardHeader>
      <CardContent className="flex-grow p-4 space-y-3">
        <p className="text-xs font-semibold text-muted-foreground">Journey Flow:</p>
        <div className="flex items-center gap-2 flex-wrap">
          {template.flow.map((step, i) => (
            <React.Fragment key={i}>
              <div className="flex items-center gap-1.5 p-1.5 bg-muted/50 rounded-md">
                <step.icon className="h-3.5 w-3.5 text-primary opacity-80" />
                <span className="text-xs text-foreground">{step.label}</span>
              </div>
              {i < template.flow.length - 1 && <ArrowRight className="h-4 w-4 text-muted-foreground/50" />}
            </React.Fragment>
          ))}
        </div>
      </CardContent>
      <div className="p-4 pt-3 mt-auto">
        <Button size="sm" className="w-full shadcn-button">Use Template</Button>
      </div>
    </Card>
  </motion.div>
);

export function JourneyTemplates() {
  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{
        visible: { transition: { staggerChildren: 0.1 } }
      }}
      className="p-1"
    >
      <motion.div variants={cardVariants} className="mb-6">
        <h3 className="text-xl font-bold tracking-tight text-foreground">Journey Templates</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Kickstart your automation with pre-built journeys inspired by Twilio Segment & Engage.
        </p>
      </motion.div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {templates.map((template, index) => (
          <TemplateCard key={template.title} template={template} index={index} />
        ))}
      </div>
    </motion.div>
  );
}
