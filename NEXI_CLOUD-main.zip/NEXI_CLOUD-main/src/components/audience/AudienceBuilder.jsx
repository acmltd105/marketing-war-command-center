import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from "@/components/ui/use-toast";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { X, PlusCircle, Filter, Loader2, Users, Check, ChevronsUpDown } from 'lucide-react';

const fields = [
  { value: 'city', label: 'City', type: 'text' },
  { value: 'state', label: 'State', type: 'text' },
  { value: 'country', label: 'Country', type: 'text' },
  { value: 'total_spend', label: 'Total Spend', type: 'number' },
  { value: 'last_seen', label: 'Last Seen', type: 'date' },
  { value: 'tags', label: 'Tags', type: 'text_array' },
];

const operators = {
  text: [ { value: 'eq', label: '=' }, { value: 'neq', label: '!=' }, { value: 'like', label: 'contains' }, { value: 'in', label: 'in (comma-separated)' } ],
  number: [ { value: 'eq', label: '=' }, { value: 'neq', label: '!=' }, { value: 'gt', label: '>' }, { value: 'lt', label: '<' }, { value: 'gte', label: '>=' }, { value: 'lte', label: '<=' } ],
  date: [ { value: 'gt', label: 'after' }, { value: 'lt', label: 'before' } ],
  text_array: [ { value: 'cs', label: 'contains' } ],
};

function AudienceRule({ rule, onUpdate, onRemove }) {
  const selectedField = fields.find(f => f.value === rule.field);
  const availableOperators = operators[selectedField?.type || 'text'];

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex items-center gap-2 p-2 bg-muted/50 rounded-lg"
    >
      <Select value={rule.field} onValueChange={(value) => onUpdate({ ...rule, field: value, operator: operators[fields.find(f=>f.value===value).type][0].value })}>
        <SelectTrigger className="w-[140px] shadcn-input text-xs"><SelectValue/></SelectTrigger>
        <SelectContent>{fields.map(f => <SelectItem key={f.value} value={f.value} className="text-xs">{f.label}</SelectItem>)}</SelectContent>
      </Select>
      <Select value={rule.operator} onValueChange={(value) => onUpdate({ ...rule, operator: value })}>
        <SelectTrigger className="w-[80px] shadcn-input text-xs"><SelectValue/></SelectTrigger>
        <SelectContent>{availableOperators.map(o => <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>)}</SelectContent>
      </Select>
      <Input
        type={selectedField?.type === 'date' ? 'date' : selectedField?.type === 'number' ? 'number' : 'text'}
        value={rule.value}
        onChange={(e) => onUpdate({ ...rule, value: e.target.value })}
        className="flex-1 shadcn-input text-xs"
        placeholder="Enter value..."
      />
      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground" onClick={onRemove}><X size={14} /></Button>
    </motion.div>
  );
}

export function AudienceBuilder({ initialRules = [], onSave }) {
  const [rules, setRules] = useState(initialRules.length > 0 ? initialRules : [{ id: 1, field: 'city', operator: 'eq', value: '' }]);
  const [nextId, setNextId] = useState(initialRules.length + 2);
  const [isLoading, setIsLoading] = useState(false);
  const [audienceCount, setAudienceCount] = useState(null);
  const { toast } = useToast();

  const addRule = () => {
    setRules([...rules, { id: nextId, field: 'city', operator: 'eq', value: '' }]);
    setNextId(nextId + 1);
  };

  const updateRule = (id, updatedRule) => {
    setRules(rules.map(rule => rule.id === id ? { ...rule, ...updatedRule } : rule));
  };

  const removeRule = (id) => {
    setRules(rules.filter(rule => rule.id !== id));
  };

  const handleCalculate = async () => {
    setIsLoading(true);
    setAudienceCount(null);
    const validRules = rules.filter(r => r.value.toString().trim() !== '');

    if (validRules.length === 0) {
      toast({ title: "No rules defined", description: "Please set at least one rule to calculate audience.", variant: "destructive" });
      setIsLoading(false);
      return;
    }
    
    const { data, error } = await supabase.functions.invoke('segment-counter', {
      body: { rules: validRules.map(({id, ...rest}) => rest) }
    });
    setIsLoading(false);

    if (error || data.error) {
      toast({ title: "Error Calculating Audience", description: error?.message || data?.error, variant: "destructive" });
    } else {
      setAudienceCount(data.count);
      toast({ title: "Calculation Complete!", description: `Found ${data.count} contacts matching your criteria.` });
    }
  };

  const handleSave = () => {
    const validRules = rules.filter(r => r.value.toString().trim() !== '');
    onSave(validRules, audienceCount);
  }

  return (
    <div className="p-1">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold text-foreground">Audience Builder</h3>
        <Button variant="outline" size="sm" onClick={addRule}><PlusCircle size={14} className="mr-2"/> Add Rule</Button>
      </div>
      <div className="space-y-2 max-h-[300px] overflow-y-auto p-1">
        <AnimatePresence>
          {rules.map(rule => (
            <AudienceRule key={rule.id} rule={rule} onUpdate={(updated) => updateRule(rule.id, updated)} onRemove={() => removeRule(rule.id)}/>
          ))}
        </AnimatePresence>
      </div>

      <div className="mt-4 pt-4 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3">
        <Button onClick={handleCalculate} disabled={isLoading} className="w-full sm:w-auto">
          {isLoading ? <Loader2 size={16} className="mr-2 animate-spin"/> : <Filter size={16} className="mr-2"/>}
          Calculate Audience Size
        </Button>
        
        {audienceCount !== null && (
          <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 p-2 bg-primary/10 rounded-lg">
            <Users size={18} className="text-primary"/>
            <span className="font-bold text-lg text-primary">{audienceCount.toLocaleString()}</span>
            <span className="text-sm text-muted-foreground">Contacts Found</span>
          </motion.div>
        )}
      </div>

       <div className="mt-4 flex justify-end">
          <Button onClick={handleSave} disabled={audienceCount === null}>Save Audience</Button>
       </div>
    </div>
  );
}
