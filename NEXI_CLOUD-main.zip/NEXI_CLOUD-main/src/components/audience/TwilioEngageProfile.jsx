import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Mail, Phone, Tag, DollarSign, Calendar, Sparkles, MapPin, ExternalLink, ShoppingCart, LogIn, CheckCircle } from 'lucide-react';

const mockProfile = {
  avatarUrl: null, // Will be replaced by an image
  name: "Alex Johnson",
  email: "alex.j@example.com",
  phone: "+1-555-123-4567",
  userId: "user_1a2b3c4d5e",
  computed_traits: [
    { key: 'LTV', value: '$482.50', icon: DollarSign },
    { key: 'Status', value: 'VIP', icon: Sparkles },
    { key: 'Last Seen', value: '2 hours ago', icon: Calendar },
    { key: 'Location', value: 'New York, NY', icon: MapPin },
  ],
  traits: [
    { key: 'Plan', value: 'Premium Tier' },
    { key: 'Joined', value: '2024-03-15' },
    { key: 'Total Orders', value: '12' },
  ],
  timeline: [
    { event: 'Order Completed', time: '2 hours ago', icon: CheckCircle, details: { orderId: 'ORD-98765', total: '$75.00' } },
    { event: 'Added to Cart', time: '3 hours ago', icon: ShoppingCart, details: { items: 3, value: '$95.00' } },
    { event: 'Viewed Product Page', time: '3 hours ago', icon: ExternalLink, details: { page: '/products/x-widget-pro' } },
    { event: 'Logged In', time: '1 day ago', icon: LogIn, details: { device: 'Mobile App' } },
  ]
};

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.05,
      duration: 0.5,
      ease: 'easeOut'
    }
  })
};

export function TwilioEngageProfile() {
  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      className="p-1"
    >
      <motion.div variants={cardVariants} className="mb-6">
        <h3 className="text-xl font-bold tracking-tight text-foreground">Unified Customer Profile</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Powered by Twilio Segment, this is the single source of truth for each customer.
        </p>
      </motion.div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div variants={cardVariants} className="lg:col-span-1">
          <Card className="frosty-glass p-0.5">
            <CardContent className="p-6 text-center">
              <div className="w-24 h-24 rounded-full mx-auto bg-primary/10 flex items-center justify-center mb-4">
                  <User className="w-12 h-12 text-primary opacity-80" />
              </div>
              <h4 className="text-xl font-semibold text-foreground">{mockProfile.name}</h4>
              <p className="text-sm text-muted-foreground">{mockProfile.userId}</p>
              
              <div className="text-left space-y-3 mt-6 text-sm">
                  <div className="flex items-center gap-3 text-foreground">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{mockProfile.email}</span>
                  </div>
                  <div className="flex items-center gap-3 text-foreground">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{mockProfile.phone}</span>
                  </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} className="lg:col-span-2">
           <Card className="frosty-glass p-0.5 h-full">
            <CardHeader>
                <CardTitle>Computed Traits & Segments</CardTitle>
                <CardDescription>Real-time attributes and audiences calculated by Segment.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 gap-4">
                    {mockProfile.computed_traits.map(trait => (
                        <div key={trait.key} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                            <trait.icon className="h-5 w-5 text-primary opacity-80 mt-0.5" />
                            <div>
                                <p className="text-xs text-muted-foreground">{trait.key}</p>
                                <p className="font-semibold text-foreground">{trait.value}</p>
                            </div>
                        </div>
                    ))}
                </div>
                 <div className="mt-4">
                    <p className="text-sm font-semibold text-foreground mb-2">Audiences</p>
                    <div className="flex flex-wrap gap-2">
                        <Badge variant="outline" className="shadcn-badge bg-purple-500/10 text-purple-600 border-purple-500/20">High-Value Customers</Badge>
                        <Badge variant="outline" className="shadcn-badge bg-sky-500/10 text-sky-600 border-sky-500/20">Likely to Churn</Badge>
                        <Badge variant="outline" className="shadcn-badge bg-green-500/10 text-green-600 border-green-500/20">Active in Last 7 Days</Badge>
                    </div>
                </div>
            </CardContent>
           </Card>
        </motion.div>

         <motion.div variants={cardVariants} className="lg:col-span-3">
           <Card className="frosty-glass p-0.5">
                <CardHeader>
                    <CardTitle>Event Timeline</CardTitle>
                    <CardDescription>A real-time stream of every interaction this user has had.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {mockProfile.timeline.map((item, index) => (
                             <div key={index} className="flex gap-4">
                                <div className="flex flex-col items-center">
                                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                                        <item.icon className="h-4 w-4 text-primary"/>
                                    </div>
                                    {index < mockProfile.timeline.length - 1 && <div className="w-px h-full bg-border/70 mt-2"></div>}
                                </div>
                                <div className="pb-4">
                                    <p className="font-semibold text-foreground">{item.event}</p>
                                    <p className="text-xs text-muted-foreground">{item.time}</p>
                                    <div className="text-xs mt-1 flex flex-wrap gap-x-3 gap-y-1">
                                        {Object.entries(item.details).map(([key, value]) => (
                                             <p key={key} className="text-muted-foreground"><span className="capitalize text-muted-foreground/80">{key.replace(/([A-Z])/g, ' $1').trim()}:</span> <span className="font-medium text-foreground/90">{value}</span></p>
                                        ))}
                                    </div>
                                </div>
                             </div>
                        ))}
                    </div>
                </CardContent>
           </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}
