import React, { useEffect, useState } from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';

export function CountUp({ end, duration = 1.5, prefix = '', suffix = '' }) {
  const [displayValue, setDisplayValue] = useState(0);
  const springValue = useSpring(0, { duration: duration * 1000, stiffness: 100, damping: 30 });

  useEffect(() => {
    springValue.set(end);
  }, [end, springValue]);

  useEffect(() => {
    const unsubscribe = springValue.onChange(latest => {
      setDisplayValue(Math.round(latest));
    });
    return unsubscribe;
  }, [springValue]);

  return (
    <motion.span>
      {prefix}
      {displayValue.toLocaleString()}
      {suffix}
    </motion.span>
  );
}