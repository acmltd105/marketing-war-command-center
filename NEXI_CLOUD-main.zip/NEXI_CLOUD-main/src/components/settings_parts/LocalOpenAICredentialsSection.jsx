
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BrainCircuit, Save, Info } from 'lucide-react';

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

export function LocalOpenAICredentialsSection({ credentials, onChange, onSave }) {
  return (
    <Card className="frosty-glass p-0.5">
      <CardHeader className="pb-4 pt-5 px-5">
        <div className="flex items-center gap-2.5">
          <BrainCircuit className="h-6 w-6 text-primary opacity-90" />
          <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">OpenAI API Key (Local Fallback)</CardTitle>
        </div>
        <CardDescription className="text-sm md:text-base">Manage OpenAI API key stored locally. Supabase Vault is preferred.</CardDescription>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-5">
          <motion.div variants={itemVariants} className="p-3.5 border border-yellow-500/30 bg-yellow-500/10 rounded-md flex items-start gap-2.5">
          <Info className="h-4 w-4 text-yellow-600 mt-0.5 shrink-0" />
          <p className="text-xs text-yellow-700">
            <strong>Security Notice:</strong> API key stored in local storage. Use Supabase Vault for production.
          </p>
        </motion.div>
        <div className="grid grid-cols-1 gap-5">
          <motion.div variants={itemVariants} className="space-y-1.5">
            <Label htmlFor="apiKey" className="text-sm font-medium">OpenAI API Key</Label>
            <Input id="apiKey" name="apiKey" type="password" value={credentials.apiKey} onChange={onChange} placeholder="sk-••••••••••••••••••••••••••••••••" className="shadcn-input" />
          </motion.div>
        </div>
        <motion.div variants={itemVariants} className="pt-2">
          <Button onClick={() => onSave('openAiCredentials', credentials)} className="shadcn-button">
            <Save className="h-4 w-4 mr-2" /> Save Local OpenAI Key
          </Button>
        </motion.div>
      </CardContent>
    </Card>
  );
}
