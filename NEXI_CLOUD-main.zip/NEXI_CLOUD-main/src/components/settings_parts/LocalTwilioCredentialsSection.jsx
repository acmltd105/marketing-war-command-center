
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { KeyRound, Lock, Info } from 'lucide-react';

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

export function LocalTwilioCredentialsSection({ credentials, onChange, onSave }) {
  return (
    <Card className="frosty-glass p-0.5">
      <CardHeader className="pb-4 pt-5 px-5">
        <div className="flex items-center gap-2.5">
          <KeyRound className="h-6 w-6 text-primary opacity-90" />
          <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Twilio API Credentials (Local Fallback)</CardTitle>
        </div>
        <CardDescription className="text-sm md:text-base">Manage Twilio credentials stored locally in your browser. Supabase Vault is preferred for production.</CardDescription>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-5">
         <motion.div variants={itemVariants} className="p-3.5 border border-yellow-500/30 bg-yellow-500/10 rounded-md flex items-start gap-2.5">
          <Info className="h-4 w-4 text-yellow-600 mt-0.5 shrink-0" />
          <p className="text-xs text-yellow-700">
            <strong>Security Notice:</strong> Credentials entered here are stored in your browser's local storage. This is less secure than Supabase Vault. Use Vault for production keys.
          </p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <motion.div variants={itemVariants} className="space-y-1.5">
            <Label htmlFor="accountSid" className="text-sm font-medium">Account SID</Label>
            <Input id="accountSid" name="accountSid" value={credentials.accountSid} onChange={onChange} placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" className="shadcn-input" />
          </motion.div>
          <motion.div variants={itemVariants} className="space-y-1.5">
            <Label htmlFor="authToken" className="text-sm font-medium">Auth Token</Label>
            <Input id="authToken" name="authToken" type="password" value={credentials.authToken} onChange={onChange} placeholder="••••••••••••••••••••••••••••••••" className="shadcn-input" />
          </motion.div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <motion.div variants={itemVariants} className="space-y-1.5">
            <Label htmlFor="messagingServiceSid" className="text-sm font-medium">Default Messaging Service SID <span className="text-muted-foreground/80 text-xs">(Optional)</span></Label>
            <Input id="messagingServiceSid" name="messagingServiceSid" value={credentials.messagingServiceSid} onChange={onChange} placeholder="MGxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" className="shadcn-input" />
          </motion.div>
          <motion.div variants={itemVariants} className="space-y-1.5">
            <Label htmlFor="phoneNumberSid" className="text-sm font-medium">Default Phone Number SID <span className="text-muted-foreground/80 text-xs">(Optional)</span></Label>
            <Input id="phoneNumberSid" name="phoneNumberSid" value={credentials.phoneNumberSid} onChange={onChange} placeholder="PNxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" className="shadcn-input" />
          </motion.div>
        </div>
        <motion.div variants={itemVariants} className="pt-2">
          <Button onClick={() => onSave('twilioCredentials', credentials)} className="shadcn-button">
            <Lock className="h-4 w-4 mr-2" /> Save Local Twilio Credentials
          </Button>
        </motion.div>
      </CardContent>
    </Card>
  );
}
