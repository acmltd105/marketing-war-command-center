
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ServerOff as ServerIcon, Eye, EyeOff, Info } from 'lucide-react';

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

export function SupabaseSecretsSection({ secrets, isLoading, showSecrets, onToggleShowSecret }) {
  return (
    <Card className="frosty-glass p-0.5">
      <CardHeader className="pb-4 pt-5 px-5">
        <div className="flex items-center gap-2.5">
          <ServerIcon className="h-6 w-6 text-primary opacity-90" />
          <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Supabase Vault Secrets</CardTitle>
        </div>
        <CardDescription className="text-sm md:text-base">View API keys and service identifiers stored securely in Supabase.</CardDescription>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-3">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <svg className="animate-spin h-6 w-6 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="ml-2 text-muted-foreground">Loading secrets...</p>
          </div>
        ) : secrets.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 max-h-[400px] overflow-y-auto pr-2">
            {secrets.map(secret => (
              <motion.div variants={itemVariants} key={secret.name} className="p-3 border border-border/60 rounded-md bg-card/40">
                <Label htmlFor={secret.name} className="text-xs font-medium text-muted-foreground block mb-0.5">{secret.name}</Label>
                <div className="flex items-center">
                  <Input 
                    id={secret.name} 
                    type={showSecrets[secret.name] ? "text" : "password"} 
                    value={secret.decrypted_secret || 'Error decrypting'} 
                    readOnly 
                    className="shadcn-input text-sm !pr-8" 
                  />
                  <Button variant="ghost" size="icon" onClick={() => onToggleShowSecret(secret.name)} className="ml-1 h-7 w-7">
                    {showSecrets[secret.name] ? <EyeOff className="h-3.5 w-3.5 text-muted-foreground" /> : <Eye className="h-3.5 w-3.5 text-muted-foreground" />}
                  </Button>
                </div>
                {secret.description && <p className="text-[10px] text-muted-foreground/70 mt-1">{secret.description}</p>}
              </motion.div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-sm py-4 text-center">No custom secrets found in Supabase Vault.</p>
        )}
         <motion.div variants={itemVariants} className="p-3.5 border border-blue-500/30 bg-blue-500/10 rounded-md flex items-start gap-2.5 mt-4">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
          <p className="text-xs text-blue-700">
            <strong>Note:</strong> To add or update secrets, please use the Supabase dashboard or CLI. These values are read-only for security.
          </p>
        </motion.div>
      </CardContent>
    </Card>
  );
}
