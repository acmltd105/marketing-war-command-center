
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch'; 
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, Save } from 'lucide-react';

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

export function BillingSettingsSection({ billing, onInputChange, onSelectChange, onSwitchChange, onSave }) {
  return (
    <Card className="frosty-glass p-0.5">
      <CardHeader className="pb-4 pt-5 px-5">
        <div className="flex items-center gap-2.5">
          <CreditCard className="h-6 w-6 text-primary opacity-90" />
          <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Usage & Billing</CardTitle>
        </div>
        <CardDescription className="text-sm md:text-base">Manage payment methods, review spending, and set budget controls.</CardDescription>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-6">
        <motion.div variants={itemVariants} className="space-y-2">
          <Label htmlFor="paymentMethod" className="text-sm font-medium">Payment Method</Label>
          <Input id="paymentMethod" name="paymentMethod" value={billing.paymentMethod} onChange={onInputChange} placeholder="e.g. Visa **** 1234" className="shadcn-input" />
        </motion.div>
        
        <motion.div variants={itemVariants} className="space-y-2">
          <Label htmlFor="currency" className="text-sm font-medium">Preferred Currency</Label>
          <Select value={billing.currency} onValueChange={(value) => onSelectChange('currency', value)}>
            <SelectTrigger id="currency" className="w-full md:w-[200px] shadcn-input">
              <SelectValue placeholder="Select currency" />
            </SelectTrigger>
            <SelectContent className="shadcn-select-content">
              <SelectItem value="USD" className="shadcn-select-item">USD - US Dollar</SelectItem>
              <SelectItem value="EUR" className="shadcn-select-item">EUR - Euro</SelectItem>
              <SelectItem value="GBP" className="shadcn-select-item">GBP - British Pound</SelectItem>
            </SelectContent>
          </Select>
        </motion.div>

        <motion.div variants={itemVariants} className="flex items-center justify-between space-x-3 p-3 border border-border/70 rounded-md bg-card/30">
          <div>
            <Label htmlFor="autoRefillEnabled" className="text-sm font-medium">Auto-Refill Credits</Label>
            <p className="text-xs text-muted-foreground">Automatically add funds when balance is low.</p>
          </div>
          <Switch id="autoRefillEnabled" name="autoRefillEnabled" checked={billing.autoRefillEnabled} onCheckedChange={(checked) => onSwitchChange('autoRefillEnabled', checked)} />
        </motion.div>
        {billing.autoRefillEnabled && (
          <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} className="pl-4 space-y-2">
            <Label htmlFor="autoRefillAmount" className="text-sm font-medium">Auto-Refill Amount ($)</Label>
            <Input id="autoRefillAmount" name="autoRefillAmount" type="number" value={billing.autoRefillAmount} onChange={onInputChange} placeholder="e.g. 50" className="shadcn-input w-full md:w-[200px]" />
          </motion.div>
        )}

        <motion.div variants={itemVariants} className="flex items-center justify-between space-x-3 p-3 border border-border/70 rounded-md bg-card/30">
          <div>
            <Label htmlFor="spendingLimitEnabled" className="text-sm font-medium">Monthly Spending Limit</Label>
             <p className="text-xs text-muted-foreground">Set a cap on monthly platform spend.</p>
          </div>
          <Switch id="spendingLimitEnabled" name="spendingLimitEnabled" checked={billing.spendingLimitEnabled} onCheckedChange={(checked) => onSwitchChange('spendingLimitEnabled', checked)} />
        </motion.div>
        {billing.spendingLimitEnabled && (
          <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} className="pl-4 space-y-2">
            <Label htmlFor="spendingLimitAmount" className="text-sm font-medium">Limit Amount ($)</Label>
            <Input id="spendingLimitAmount" name="spendingLimitAmount" type="number" value={billing.spendingLimitAmount} onChange={onInputChange} placeholder="e.g. 1000" className="shadcn-input w-full md:w-[200px]" />
          </motion.div>
        )}
        <motion.div variants={itemVariants} className="pt-3">
          <Button onClick={() => onSave('billing', billing)} className="shadcn-button">
            <Save className="h-4 w-4 mr-2" /> Save Billing Settings
          </Button>
        </motion.div>
      </CardContent>
    </Card>
  );
}
