
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch'; 
import { Bell, Save } from 'lucide-react';

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

const notificationItems = [
  { key: 'lowBalanceAlert', label: 'Low Balance Alerts', desc: 'Notify when account balance is low.' },
  { key: 'campaignCompletion', label: 'Campaign Completion', desc: 'Receive alerts when campaigns finish.' },
  { key: 'apiErrors', label: 'Critical API Errors', desc: 'Get notified about significant API issues.' }
];

export function NotificationSettingsSection({ notifications, onSwitchChange, onSave }) {
  return (
    <Card className="frosty-glass p-0.5">
      <CardHeader className="pb-4 pt-5 px-5">
        <div className="flex items-center gap-2.5">
            <Bell className="h-6 w-6 text-primary opacity-90" />
            <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Notification Preferences</CardTitle>
        </div>
        <CardDescription className="text-sm md:text-base">Choose how you receive updates and alerts.</CardDescription>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-5">
        {notificationItems.map(item => (
          <motion.div key={item.key} variants={itemVariants} className="flex items-center justify-between space-x-3 p-3 border border-border/70 rounded-md bg-card/30">
            <div>
              <Label htmlFor={item.key} className="text-sm font-medium">{item.label}</Label>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
            <Switch 
              id={item.key} 
              checked={notifications[item.key]} 
              onCheckedChange={(checked) => onSwitchChange(item.key, checked)} 
            />
          </motion.div>
        ))}
        <motion.div variants={itemVariants} className="pt-3">
          <Button onClick={() => onSave('notifications', notifications)} className="shadcn-button">
            <Save className="h-4 w-4 mr-2" /> Save Notification Settings
          </Button>
        </motion.div>
      </CardContent>
    </Card>
  );
}
