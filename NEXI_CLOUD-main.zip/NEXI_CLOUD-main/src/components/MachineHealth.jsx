import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { HeartPulse, Gauge, Server, Zap, AlertTriangle, Wifi, Activity, Clock } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const CircularProgress = ({ value, size = 180, strokeWidth = 14 }) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (value / 100) * circumference;

  let color = 'stroke-green-500';
  if (value < 70) color = 'stroke-yellow-500';
  if (value < 40) color = 'stroke-red-500';

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle
          className="text-muted/30"
          strokeWidth={strokeWidth}
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        <motion.circle
          className={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.span 
          className="text-4xl font-bold text-foreground"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "circOut", delay: 0.5 }}
        >
          {Math.round(value)}
          <span className="text-xl font-medium text-muted-foreground">%</span>
        </motion.span>
      </div>
    </div>
  );
};


export function MachineHealth() {
  const [healthScore, setHealthScore] = useState(0);
  const [apiLatency, setApiLatency] = useState(0);
  const [errorRate, setErrorRate] = useState(0);

  useEffect(() => {
    // Simulate fetching data
    const timer = setTimeout(() => {
      setHealthScore(97.8); // Example score
      setApiLatency(65); // ms
      setErrorRate(0.12); // %
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const healthMetrics = [
    { title: "API Avg. Latency", value: `${apiLatency}ms`, icon: Clock, status: apiLatency < 100 ? 'Good' : apiLatency < 300 ? 'Fair' : 'Poor', color: apiLatency < 100 ? 'text-green-500' : apiLatency < 300 ? 'text-yellow-500' : 'text-red-500' },
    { title: "Critical Error Rate", value: `${errorRate}%`, icon: AlertTriangle, status: errorRate < 0.5 ? 'Low' : errorRate < 2 ? 'Moderate' : 'High', color: errorRate < 0.5 ? 'text-green-500' : errorRate < 2 ? 'text-yellow-500' : 'text-red-500' },
    { title: "Twilio Service Status", value: "All Operational", icon: Wifi, status: 'Nominal', color: 'text-green-500' },
    { title: "Queue Depth (SMS Out)", value: "12 items", icon: Server, status: 'Normal', color: 'text-sky-500' },
  ];

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <HeartPulse className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              System Health Monitor
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Real-time overview of operational status and performance metrics. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="flex-grow"
      >
        <Card className="frosty-glass p-0.5 mb-6 md:mb-8">
          <CardHeader className="text-center pt-6 pb-2">
            <CardTitle className="text-lg font-semibold text-foreground">Overall System Health Score</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center p-6 pt-2">
            <CircularProgress value={healthScore} />
            <motion.p 
              initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} transition={{delay:1.2, duration:0.5}}
              className="mt-4 text-sm text-muted-foreground"
            >
              {healthScore > 90 ? "System operating optimally." : healthScore > 70 ? "Minor issues detected, performance stable." : "Attention required, potential performance degradation."}
            </motion.p>
          </CardContent>
        </Card>

        <motion.div 
          variants={sectionVariants} 
          initial="hidden" 
          animate="visible" 
          custom={1}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6"
        >
          {healthMetrics.map((metric, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="frosty-glass p-0.5 h-full">
                <CardHeader className="pb-1.5 pt-4 px-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xs font-medium text-muted-foreground">{metric.title}</CardTitle>
                    <metric.icon className={`h-4 w-4 ${metric.color} opacity-80`} />
                  </div>
                </CardHeader>
                <CardContent className="px-4 pb-4">
                  <p className="text-2xl font-semibold text-foreground">{metric.value}</p>
                  <p className={`text-[11px] font-medium mt-0.5 ${metric.color}`}>{metric.status}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={3} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">System Monitoring Note</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This Machine Health dashboard is a conceptual representation. Real-time monitoring requires integration with backend monitoring tools, API health checks, and potentially log aggregation services. Metrics shown are illustrative.
            </p>
        </div>
      </motion.div>
    </div>
  );
}