import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GripVertical, PlusCircle, Rows, Columns, Text, BarChartBig, PieChart, LineChart, AlertTriangle, LayoutDashboard, Settings2, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const widgetOptions = [
  { name: 'Text Block', icon: Text, type: 'text', defaultContent: "Editable text content..." },
  { name: 'Key Metric', icon: Rows, type: 'metric', defaultContent: { title: "Total Sales", value: "$12,345", change: "+5%" } },
  { name: 'Bar Chart', icon: BarChartBig, type: 'barChart', defaultContent: { labels: ['Jan', 'Feb', 'Mar'], data: [65, 59, 80] } },
  { name: 'Line Graph', icon: LineChart, type: 'lineGraph', defaultContent: { labels: ['Mon', 'Tue', 'Wed'], data: [12, 19, 3] } },
  { name: 'Pie Chart', icon: PieChart, type: 'pieChart', defaultContent: { labels: ['Red', 'Blue', 'Yellow'], data: [300, 50, 100] } },
];

const MockBarChart = () => (
  <svg viewBox="0 0 100 50" className="w-full h-auto opacity-70">
    <rect x="10" y="20" width="15" height="30" fill="currentColor" className="text-primary/60"/>
    <rect x="30" y="10" width="15" height="40" fill="currentColor" className="text-primary/80"/>
    <rect x="50" y="25" width="15" height="25" fill="currentColor" className="text-primary/50"/>
    <rect x="70" y="5" width="15" height="45" fill="currentColor" className="text-primary"/>
  </svg>
);

const MockLineGraph = () => (
  <svg viewBox="0 0 100 50" className="w-full h-auto opacity-70">
    <polyline points="10,40 30,20 50,30 70,10 90,25" fill="none" stroke="currentColor" strokeWidth="2" className="text-primary"/>
  </svg>
);

const MockPieChart = () => (
  <svg viewBox="0 0 50 50" className="w-20 h-20 mx-auto opacity-70">
    <circle cx="25" cy="25" r="20" fill="currentColor" className="text-primary/30"/>
    <path d="M25 25 L25 5 A20 20 0 0 1 43.3 15.5 Z" fill="currentColor" className="text-primary/70"/>
    <path d="M25 25 L43.3 15.5 A20 20 0 0 1 34.5 43.3 Z" fill="currentColor" className="text-primary"/>
  </svg>
);


const DashboardBuilder = () => {
  const [widgets, setWidgets] = React.useState([]);
  const { toast } = useToast();

  const addWidget = (type) => {
    const widgetConfig = widgetOptions.find(w => w.type === type);
    const newWidget = {
      id: `widget-${Date.now()}`,
      type,
      name: widgetConfig?.name || 'New Widget',
      content: widgetConfig?.defaultContent || {},
      icon: widgetConfig?.icon || LayoutDashboard,
      gridSpan: type === 'barChart' || type === 'lineGraph' ? 2 : 1, // Example: charts take more space
    };
    setWidgets(prev => [...prev, newWidget]);
    toast({ title: `${newWidget.name} Added`, description: "Configure it in the main panel.", variant: "default" });
  };

  const removeWidget = (widgetId) => {
    setWidgets(prev => prev.filter(w => w.id !== widgetId));
    toast({ title: "Widget Removed", variant: "destructive" });
  };
  
  const getWidgetContent = (widget) => {
    switch(widget.type) {
      case 'text': return <p className="text-xs p-1">{widget.content}</p>;
      case 'metric': return (
        <div className="text-center p-1">
          <h4 className="text-[10px] uppercase text-muted-foreground">{widget.content.title}</h4>
          <p className="text-lg font-bold text-foreground">{widget.content.value}</p>
          <p className="text-[10px] text-green-500">{widget.content.change}</p>
        </div>
      );
      case 'barChart': return <MockBarChart />;
      case 'lineGraph': return <MockLineGraph />;
      case 'pieChart': return <MockPieChart />;
      default: return <p className="text-xs p-1">Placeholder for {widget.name}</p>;
    }
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <LayoutDashboard className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Dashboard Builder (Conceptual)
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Drag, drop, and configure widgets to create custom operational dashboards.
          </p>
        </div>
      </motion.header>

      <div className="flex-grow grid grid-cols-12 gap-4 md:gap-6">
        <motion.aside 
            initial={{ opacity:0, x: -40 }}
            animate={{ opacity:1, x: 0 }}
            transition={{ duration:0.45, delay: 0.1, type: "spring", stiffness:100, damping:15 }}
            className="col-span-12 md:col-span-3 lg:col-span-2"
        >
          <Card className="frosty-glass p-0.5 h-full">
            <CardHeader className="px-3 py-3 md:px-4 md:py-4">
              <CardTitle className="text-base md:text-lg font-semibold text-foreground">Widgets</CardTitle>
              <CardDescription className="text-xs">Click to add to dashboard</CardDescription>
            </CardHeader>
            <CardContent className="px-3 pb-3 md:px-4 md:pb-4 space-y-2">
              {widgetOptions.map(widget => (
                <motion.div
                  key={widget.type}
                  className="p-2 border border-border/40 rounded-md cursor-pointer flex items-center gap-2 hover:bg-primary/5 bg-background/20 transition-colors"
                  onClick={() => addWidget(widget.type)} 
                  whileHover={{ scale: 1.03, x:2 }}
                  whileTap={{ scale: 0.97 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                >
                  <widget.icon className="h-3.5 w-3.5 text-primary opacity-75 flex-shrink-0" />
                  <span className="text-[11px] md:text-xs font-medium text-foreground truncate">{widget.name}</span>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.aside>

        <motion.main 
            initial={{ opacity:0, y: 40 }}
            animate={{ opacity:1, y: 0 }}
            transition={{ duration:0.45, delay: 0.15, type: "spring", stiffness:100, damping:15 }}
            className="col-span-12 md:col-span-9 lg:col-span-10 frosty-glass p-3 md:p-5 rounded-lg min-h-[400px] overflow-y-auto scrollbar-thin"
        >
          {widgets.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center border-2 border-dashed border-border/30 rounded-md py-10 min-h-[250px]">
              <LayoutDashboard className="h-12 w-12 md:h-14 md:w-14 text-muted-foreground opacity-40 mb-3" />
              <h3 className="text-lg md:text-xl font-semibold text-foreground">Your Dashboard is Empty</h3>
              <p className="text-xs md:text-sm text-muted-foreground mt-1 mb-3">Click widgets from the left panel to add them here.</p>
              <Button variant="outline" size="sm" className="shadcn-button text-xs" onClick={() => addWidget(widgetOptions[0].type)}>
                <PlusCircle className="h-3.5 w-3.5 mr-1.5"/> Add First Widget
              </Button>
            </div>
          )}
          <AnimatePresence>
            <motion.div 
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4"
                initial="hidden" animate="visible" variants={{ visible: { transition: { staggerChildren: 0.07 }}}}
            >
              {widgets.map((widget) => (
                <motion.div
                  key={widget.id}
                  layout
                  variants={{ hidden: { opacity: 0, y: 20, scale: 0.9 }, visible: { opacity: 1, y: 0, scale: 1 }}}
                  exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.2 } }}
                  transition={{ type: 'spring', stiffness: 260, damping: 20 }}
                  className={`frosty-glass p-2.5 rounded-md shadow-md relative min-h-[120px] md:min-h-[140px] flex flex-col col-span-1 ${widget.gridSpan > 1 ? `sm:col-span-${widget.gridSpan}` : ''}`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5">
                        <widget.icon className="h-3 w-3 text-primary opacity-70 flex-shrink-0"/>
                        <span className="text-[11px] md:text-xs font-semibold text-foreground truncate">{widget.name}</span>
                    </div>
                    <div className="flex items-center">
                        <Button variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-primary" onClick={() => toast({title: "Configure Widget (Placeholder)", description: "Widget configuration options would appear here."})}>
                            <Settings2 size={10}/>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-destructive" onClick={() => removeWidget(widget.id)}>
                            <Trash2 size={10}/>
                        </Button>
                    </div>
                  </div>
                  <div className="text-[10px] md:text-xs text-muted-foreground flex-grow flex items-center justify-center">
                    {getWidgetContent(widget)}
                  </div>
                  <p className="text-[9px] text-muted-foreground/50 mt-1 text-center">Drag to reorder (Conceptual)</p>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
           {widgets.length > 0 && (
             <div className="mt-6 text-center">
                <Button size="sm" className="shadcn-button text-xs" onClick={() => toast({title: "Dashboard Saved (Conceptual)", description: "Your dashboard layout has been conceptually saved."})}>
                    Save Dashboard
                </Button>
             </div>
           )}
        </motion.main>
      </div>
      <motion.div 
        initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.4, type: "spring"}}
        className="mt-auto pt-4"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Conceptual Builder</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This Dashboard Builder is a conceptual demonstration. Full drag & drop reordering, widget configuration, and data-binding require significant additional development and backend integration (Supabase).
            </p>
        </div>
      </motion.div>
    </div>
  );
};

export { DashboardBuilder };