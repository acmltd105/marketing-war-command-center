import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LayoutTemplate, PlusCircle, Edit3, Trash2, Eye, Link2, Database, Settings2, AlertTriangle, Palette } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialTemplate = {
  id: '',
  name: 'New Dynamic Page',
  baseUrl: 'yourdomain.com/lp/{lead_id}',
  dataSource: 'crm', // crm, uploaded_list
  dynamicFields: { firstName: true, lastName: false, productInterest: true, location: false, customField1: false },
  campaignGoal: 'lead_capture', // lead_capture, product_demo, sale
  status: 'Draft'
};

export function DynamicLandingPageGenerator() {
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [currentConfig, setCurrentConfig] = useState({...initialTemplate});

  const handleInputChange = (field, value) => {
    setCurrentConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleDynamicFieldChange = (field, checked) => {
    setCurrentConfig(prev => ({
      ...prev,
      dynamicFields: { ...prev.dynamicFields, [field]: checked }
    }));
  };
  
  const handleSaveTemplate = () => {
    let templateToSave = {...currentConfig};
    if (!templateToSave.id) templateToSave.id = `lp_${Date.now()}`;
    
    const existingIndex = templates.findIndex(t => t.id === templateToSave.id);
    if (existingIndex > -1) {
      setTemplates(templates.map(t => t.id === templateToSave.id ? templateToSave : t));
    } else {
      setTemplates([...templates, templateToSave]);
    }
    setSelectedTemplate(templateToSave);
    // Add toast notification for success
  };

  const handleNewTemplate = () => {
    setSelectedTemplate(null);
    setCurrentConfig({...initialTemplate, id: `lp_${Date.now()}`});
  };

  const handleSelectTemplate = (template) => {
    setSelectedTemplate(template);
    setCurrentConfig(template);
  };
  
  const handleDeleteTemplate = (templateId) => {
    setTemplates(prev => prev.filter(t => t.id !== templateId));
    if (selectedTemplate && selectedTemplate.id === templateId) {
      handleNewTemplate();
    }
    // Add toast notification for deletion
  };
  
  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <LayoutTemplate className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Dynamic Landing Page Generator
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Auto-build personalized landing pages from CRM data and campaign goals. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        <motion.div variants={itemVariants} className="lg:col-span-1 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3 flex flex-row justify-between items-center">
              <CardTitle className="text-lg font-semibold text-foreground">Page Templates</CardTitle>
              <Button size="sm" variant="outline" onClick={handleNewTemplate} className="shadcn-button"><PlusCircle className="h-4 w-4 mr-1.5" /> New</Button>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-2.5 max-h-[calc(100vh-350px)] overflow-y-auto scrollbar-hide">
              {templates.length === 0 ? <p className="text-xs text-muted-foreground text-center py-4">No templates created.</p> : templates.map(t => (
                <div key={t.id} className={`p-2.5 rounded-md border cursor-pointer ${selectedTemplate?.id === t.id ? 'bg-primary/10 border-primary/50' : 'bg-muted/30 hover:bg-muted/50 border-transparent'}`} onClick={() => handleSelectTemplate(t)}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-foreground">{t.name}</span>
                    <Button size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={(e) => {e.stopPropagation(); handleDeleteTemplate(t.id);}}><Trash2 size={12}/></Button>
                  </div>
                  <p className="text-[11px] text-muted-foreground">Goal: {t.campaignGoal.replace('_', ' ')} - Status: {t.status}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
             <CardHeader className="px-5 pt-5 pb-3">
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        {selectedTemplate ? <Edit3 className="h-5 w-5 text-primary" /> : <PlusCircle className="h-5 w-5 text-primary" />}
                        <CardTitle className="text-lg font-semibold text-foreground">{selectedTemplate ? `Edit: ${currentConfig.name}` : 'Create New Dynamic Page Template'}</CardTitle>
                    </div>
                    <Button onClick={handleSaveTemplate} className="shadcn-button" size="sm"><Settings2 className="h-4 w-4 mr-1.5"/> Save Template</Button>
                </div>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
              <div>
                <Label htmlFor="lpName" className="text-xs">Template Name</Label>
                <Input id="lpName" value={currentConfig.name} onChange={e => handleInputChange('name', e.target.value)} className="shadcn-input mt-1 text-sm" />
              </div>
              <div>
                <Label htmlFor="lpBaseUrl" className="text-xs">Base URL Structure</Label>
                <Input id="lpBaseUrl" value={currentConfig.baseUrl} onChange={e => handleInputChange('baseUrl', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="e.g., yourdomain.com/offer/{lead_id}"/>
                <p className="text-[11px] text-muted-foreground mt-0.5">Use `{"{lead_id}"}` or other unique identifiers.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                    <Label htmlFor="lpDataSource" className="text-xs">Data Source (for personalization)</Label>
                    <Select value={currentConfig.dataSource} onValueChange={val => handleInputChange('dataSource', val)}>
                        <SelectTrigger id="lpDataSource" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent className="shadcn-select-content">
                        <SelectItem value="crm" className="shadcn-select-item">CRM / CDP</SelectItem>
                        <SelectItem value="uploaded_list" className="shadcn-select-item">Uploaded Lead List</SelectItem>
                        <SelectItem value="api_feed" className="shadcn-select-item">Real-time API Feed</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="lpCampaignGoal" className="text-xs">Campaign Goal</Label>
                    <Select value={currentConfig.campaignGoal} onValueChange={val => handleInputChange('campaignGoal', val)}>
                        <SelectTrigger id="lpCampaignGoal" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent className="shadcn-select-content">
                        <SelectItem value="lead_capture" className="shadcn-select-item">Lead Capture</SelectItem>
                        <SelectItem value="product_demo" className="shadcn-select-item">Product Demo Request</SelectItem>
                        <SelectItem value="sale" className="shadcn-select-item">Direct Sale / Conversion</SelectItem>
                        <SelectItem value="info_engagement" className="shadcn-select-item">Information / Engagement</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
              </div>
               <div>
                    <Label className="text-xs block mb-1.5">Dynamic Fields (Select to include):</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {Object.keys(currentConfig.dynamicFields).map(field => (
                           <div key={field} className="flex items-center space-x-1.5 p-1.5 bg-muted/20 rounded">
                                <Checkbox id={`df-${field}`} checked={currentConfig.dynamicFields[field]} onCheckedChange={checked => handleDynamicFieldChange(field, checked)}/>
                                <Label htmlFor={`df-${field}`} className="text-xs font-normal capitalize">{field.replace(/([A-Z])/g, ' $1')}</Label>
                           </div> 
                        ))}
                    </div>
                </div>
                <Button variant="outline" className="w-full shadcn-button text-xs" onClick={() => alert("Conceptual: Open Visual Page Editor")}>
                    <Palette size={14} className="mr-2"/> Open Visual Editor (Mock)
                </Button>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      {/* Conceptual Preview Area */}
        <motion.div variants={itemVariants} className="lg:col-span-3 mt-6">
            <Card className="frosty-glass p-0.5">
                <CardHeader className="px-5 pt-5 pb-3">
                    <div className="flex items-center gap-2">
                        <Eye className="h-5 w-5 text-primary"/>
                        <CardTitle className="text-lg font-semibold">Conceptual Page Preview</CardTitle>
                    </div>
                    <CardDescription className="text-sm">A rough idea of how dynamic content might appear.</CardDescription>
                </CardHeader>
                <CardContent className="px-5 pb-5">
                    <div className="p-6 border border-dashed border-border/50 rounded-md bg-muted/20 min-h-[200px] flex flex-col items-center justify-center">
                        {currentConfig.dynamicFields.firstName && <h2 className="text-xl font-bold text-center mb-2">Hi, `{"{{FirstName}}"}`, special offer for you!</h2>}
                        <p className="text-sm text-center text-muted-foreground mb-1">
                           Based on your interest in `{"{{ProductInterest ? ProductInterest : 'our services'}}"}`,
                           {currentConfig.dynamicFields.location && ` we have tailored deals for ` + "`{{Location}}`" + `.`}
                        </p>
                        <p className="text-xs text-center text-muted-foreground mb-3">
                            This is a mock preview. Dynamic content like `{"{{CustomField1}}"}}` would be populated from your '{currentConfig.dataSource}' source.
                        </p>
                        <Button variant="default" className="shadcn-button" size="sm">
                            {currentConfig.campaignGoal === 'lead_capture' ? 'Sign Up Now' : currentConfig.campaignGoal === 'product_demo' ? 'Request Demo' : 'Learn More'}
                        </Button>
                        <p className="text-[10px] mt-3 text-muted-foreground/70">Generated for: `{"{lead_id}"}`</p>
                    </div>
                </CardContent>
            </Card>
        </motion.div>

      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Personalization Engine</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                The Dynamic Landing Page Generator conceptualizes automatic page creation. Realization involves a robust templating engine, secure data fetching (from CRM/API), and potentially a visual editor for page layouts.
            </p>
        </div>
      </motion.div>
    </div>
  );
}