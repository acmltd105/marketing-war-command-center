import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TestTube2, PlusCircle, Edit3, Trash2, ListFilter, Percent, PlayCircle, PauseCircle, BarChart3, AlertTriangle, Info } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialTest = {
  id: '',
  name: 'New A/B/N Test',
  testElement: 'sms_copy', // email_subject, cta_button, lp_headline, image_used
  variants: [{ id: 'v1', content: '', trafficSplit: 50 }, { id: 'v2', content: '', trafficSplit: 50 }],
  keyMetric: 'ctr', // open_rate, conversion_rate
  status: 'Draft', // Draft, Active, Paused, Completed
  results: null, // Will store mock results
};

const testElementOptions = [
    { value: 'sms_copy', label: 'SMS Copy' }, { value: 'email_subject', label: 'Email Subject Line' },
    { value: 'cta_button_text', label: 'CTA Button Text' }, { value: 'cta_button_color', label: 'CTA Button Color (Hex)' },
    { value: 'landing_page_headline', label: 'Landing Page Headline' }, { value: 'image_used', label: 'Image/Visual (URL)' },
    { value: 'emoji_use', label: 'Emoji Usage Pattern' }, { value: 'agent_follow_up_timing', label: 'Agent Follow-up Timing (Hours)' },
];

const keyMetricOptions = [
    { value: 'open_rate', label: 'Open Rate' }, { value: 'click_through_rate', label: 'Click-Through Rate (CTR)' },
    { value: 'conversion_rate', label: 'Conversion Rate' }, { value: 'reply_rate', label: 'Reply Rate' },
    { value: 'cost_per_conversion', label: 'Cost Per Conversion' },
];

export function AdvancedTestingModule() {
  const [tests, setTests] = useState([]);
  const [selectedTest, setSelectedTest] = useState(null);
  const [currentConfig, setCurrentConfig] = useState({...initialTest, variants: initialTest.variants.map(v => ({...v}))});

  const handleInputChange = (field, value, variantId) => {
    if (variantId) {
      setCurrentConfig(prev => ({
        ...prev,
        variants: prev.variants.map(v => v.id === variantId ? { ...v, [field]: value } : v)
      }));
    } else {
      setCurrentConfig(prev => ({ ...prev, [field]: value }));
    }
  };

  const addVariant = () => {
    const newVariantId = `v${currentConfig.variants.length + 1}`;
    setCurrentConfig(prev => ({
      ...prev,
      variants: [...prev.variants, { id: newVariantId, content: '', trafficSplit: 0 }]
    }));
    // Rebalance traffic (simple for now)
    rebalanceTraffic();
  };

  const removeVariant = (variantId) => {
    if (currentConfig.variants.length <= 2) return; // Keep at least 2 variants
    setCurrentConfig(prev => ({
      ...prev,
      variants: prev.variants.filter(v => v.id !== variantId)
    }));
    rebalanceTraffic();
  };

  const rebalanceTraffic = () => {
    setCurrentConfig(prev => {
        const numVariants = prev.variants.length;
        if (numVariants === 0) return prev;
        const equalSplit = Math.floor(100 / numVariants);
        let remainder = 100 % numVariants;
        const newVariants = prev.variants.map((v, index) => {
            let split = equalSplit;
            if (remainder > 0) {
                split++;
                remainder--;
            }
            return { ...v, trafficSplit: split };
        });
        return { ...prev, variants: newVariants };
    });
  };
  
  const handleSaveTest = () => {
    let testToSave = {...currentConfig};
    if (!testToSave.id) testToSave.id = `test_${Date.now()}`;
    
    // Ensure traffic splits add up to 100
    const totalSplit = testToSave.variants.reduce((sum, v) => sum + (parseInt(v.trafficSplit, 10) || 0), 0);
    if (totalSplit !== 100) {
        alert("Traffic splits must add up to 100%. Please adjust."); // Replace with toast
        return;
    }

    const existingIndex = tests.findIndex(t => t.id === testToSave.id);
    if (existingIndex > -1) {
      setTests(tests.map(t => t.id === testToSave.id ? testToSave : t));
    } else {
      setTests([...tests, testToSave]);
    }
    setSelectedTest(testToSave);
  };

  const handleNewTest = () => {
    setSelectedTest(null);
    const newTestSetup = {...initialTest, id: `test_${Date.now()}`, variants: initialTest.variants.map(v => ({...v}))};
    setCurrentConfig(newTestSetup);
  };

  const handleSelectTest = (test) => {
    setSelectedTest(test);
    setCurrentConfig({...test, variants: test.variants.map(v => ({...v}))}); // Deep copy variants
  };
  
  const handleDeleteTest = (testId) => {
    setTests(prev => prev.filter(t => t.id !== testId));
    if (selectedTest && selectedTest.id === testId) {
      handleNewTest();
    }
  };

  const toggleTestStatus = (testId, currentStatus) => {
    let newStatus = currentStatus;
    if (currentStatus === 'Draft') newStatus = 'Active';
    else if (currentStatus === 'Active') newStatus = 'Paused';
    else if (currentStatus === 'Paused') newStatus = 'Active';
    else if (currentStatus === 'Completed') newStatus = 'Draft'; // Allow re-drafting completed

    setTests(prev => prev.map(t => t.id === testId ? { ...t, status: newStatus, results: newStatus === 'Active' && !t.results ? generateMockResults(t.variants.length) : t.results } : t));
    if (selectedTest && selectedTest.id === testId) {
        setCurrentConfig(prev => ({...prev, status:newStatus, results: newStatus === 'Active' && !prev.results ? generateMockResults(prev.variants.length) : prev.results}));
    }
  };

  const generateMockResults = (numVariants) => {
    return Array(numVariants).fill(null).map((_, i) => ({
        variantId: `v${i+1}`,
        conversions: Math.floor(Math.random() * 100) + 10,
        metricValue: (Math.random() * 10 + 5).toFixed(2)
    }));
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <TestTube2 className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              A/B/C/Z Testing Engine
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Auto-test every variable to optimize campaign performance. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        <motion.div variants={itemVariants} className="lg:col-span-1 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3 flex flex-row justify-between items-center">
              <CardTitle className="text-lg font-semibold text-foreground">Active Tests</CardTitle>
              <Button size="sm" variant="outline" onClick={handleNewTest} className="shadcn-button"><PlusCircle className="h-4 w-4 mr-1.5" /> New Test</Button>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-2.5 max-h-[calc(100vh-350px)] overflow-y-auto scrollbar-hide">
              {tests.length === 0 ? <p className="text-xs text-muted-foreground text-center py-4">No A/B tests configured.</p> : tests.map(t => (
                <div key={t.id} className={`p-2.5 rounded-md border cursor-pointer ${selectedTest?.id === t.id ? 'bg-primary/10 border-primary/50' : 'bg-muted/30 hover:bg-muted/50 border-transparent'}`} onClick={() => handleSelectTest(t)}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-foreground">{t.name}</span>
                    <Badge variant={t.status === 'Active' ? 'default' : (t.status === 'Completed' ? 'secondary' : 'outline')} className="shadcn-badge capitalize text-[10px]">{t.status}</Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground">Testing: {testElementOptions.find(opt => opt.value === t.testElement)?.label || 'N/A'}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
             <CardHeader className="px-5 pt-5 pb-3">
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        {selectedTest ? <Edit3 className="h-5 w-5 text-primary" /> : <PlusCircle className="h-5 w-5 text-primary" />}
                        <CardTitle className="text-lg font-semibold text-foreground">{selectedTest ? `Edit: ${currentConfig.name}` : 'Configure New A/B/N Test'}</CardTitle>
                    </div>
                    <Button onClick={handleSaveTest} className="shadcn-button" size="sm"><ListFilter className="h-4 w-4 mr-1.5"/> Save Test</Button>
                </div>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
              <div>
                <Label htmlFor="testName" className="text-xs">Test Name</Label>
                <Input id="testName" value={currentConfig.name} onChange={e => handleInputChange('name', e.target.value)} className="shadcn-input mt-1 text-sm" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                    <Label htmlFor="testElement" className="text-xs">Element to Test</Label>
                    <Select value={currentConfig.testElement} onValueChange={val => handleInputChange('testElement', val)}>
                        <SelectTrigger id="testElement" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent className="shadcn-select-content">{testElementOptions.map(opt => <SelectItem key={opt.value} value={opt.value} className="shadcn-select-item text-xs">{opt.label}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
                 <div>
                    <Label htmlFor="keyMetric" className="text-xs">Key Metric for Success</Label>
                    <Select value={currentConfig.keyMetric} onValueChange={val => handleInputChange('keyMetric', val)}>
                        <SelectTrigger id="keyMetric" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent className="shadcn-select-content">{keyMetricOptions.map(opt => <SelectItem key={opt.value} value={opt.value} className="shadcn-select-item text-xs">{opt.label}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
              </div>
              <div>
                <Label className="text-xs mb-1 block">Variants:</Label>
                {currentConfig.variants.map((variant, index) => (
                    <div key={variant.id} className="mb-2 p-2 border border-border/30 rounded bg-muted/20 space-y-1.5">
                        <div className="flex justify-between items-center">
                            <Label className="text-xs font-medium">Variant {String.fromCharCode(65 + index)}</Label>
                            {currentConfig.variants.length > 2 && <Button variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-destructive" onClick={() => removeVariant(variant.id)}><Trash2 size={10}/></Button>}
                        </div>
                        <Textarea value={variant.content} onChange={e => handleInputChange('content', e.target.value, variant.id)} className="shadcn-input text-xs min-h-[40px]" placeholder={`Content for Variant ${String.fromCharCode(65 + index)}`}/>
                        <div className="flex items-center gap-2">
                            <Label htmlFor={`traffic-${variant.id}`} className="text-[10px] whitespace-nowrap">Traffic Split (%):</Label>
                            <Input id={`traffic-${variant.id}`} type="number" value={variant.trafficSplit} onChange={e => handleInputChange('trafficSplit', parseInt(e.target.value, 10) || 0, variant.id)} className="shadcn-input text-xs h-7 w-16"/>
                            <Progress value={variant.trafficSplit} className="h-1.5 flex-grow bg-primary/10" indicatorClassName="bg-primary/70"/>
                        </div>
                    </div>
                ))}
                <Button variant="outline" size="xs" onClick={addVariant} className="shadcn-button text-[11px]"><PlusCircle size={12} className="mr-1"/> Add Variant</Button>
              </div>
               {selectedTest && selectedTest.status !== 'Draft' && selectedTest.results && (
                  <div className="pt-2">
                    <Label className="text-xs mb-1 block">Mock Results:</Label>
                    <div className="p-2 border border-border/30 rounded bg-muted/20 space-y-1">
                        {selectedTest.results.map((res, idx) => (
                             <p key={idx} className="text-xs text-muted-foreground">
                                Variant {String.fromCharCode(65 + idx)}: {res.metricValue} {keyMetricOptions.find(k=>k.value === selectedTest.keyMetric)?.label || 'Metric'} ({res.conversions} conversions)
                                {selectedTest.results.reduce((max, r) => parseFloat(r.metricValue) > parseFloat(max.metricValue) ? r : max, {metricValue: "0"}).variantId === res.variantId && <Badge className="ml-2 text-[9px] shadcn-badge bg-green-500/20 text-green-700">Winning</Badge>}
                             </p>
                        ))}
                    </div>
                  </div>  
               )}
              
               <div className="flex gap-2 pt-2">
                <Button variant="default" className="w-full shadcn-button text-xs" onClick={() => toggleTestStatus(currentConfig.id, currentConfig.status)} disabled={!selectedTest}>
                   {currentConfig.status === 'Active' ? <PauseCircle size={14} className="mr-2"/> : <PlayCircle size={14} className="mr-2"/>}
                   {currentConfig.status === 'Draft' ? 'Start Test' : currentConfig.status === 'Active' ? 'Pause Test' : 'Reactivate Test'}
                </Button>
                 <Button variant="outline" className="w-full shadcn-button text-xs" onClick={() => { if(selectedTest) handleDeleteTest(selectedTest.id) }} disabled={!selectedTest}>
                    <Trash2 size={14} className="mr-2"/> Delete Test
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Optimization Powerhouse</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                The A/B/N Testing Engine is for systematically comparing variations of campaign elements. Full implementation requires robust tracking infrastructure, statistical significance calculation, and automated winner deployment.
            </p>
        </div>
      </motion.div>
    </div>
  );
}