import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { MessageCircle, Zap, AlertTriangle, Info, Bot, Send } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const mockNlpResponses = {
  "text me the cheapest plan": {
    intent: "request_quote_basic_plan",
    entities: [{ type: "plan_tier", value: "cheapest" }],
    response: "Our Basic Plan starts at $29/month and includes core features X, Y, and Z. Would you like a detailed quote or to compare plans?",
  },
  "what are your business hours?": {
    intent: "query_business_hours",
    entities: [],
    response: "We're open Monday to Friday, 9 AM to 6 PM EST. Our support team is available 24/7 via chat!",
  },
  "i need help with my bill": {
    intent: "billing_support_request",
    entities: [{ type: "issue_category", value: "billing" }],
    response: "I can help with that. To connect you to the right department, could you please provide your account number or the email address associated with your account?",
  },
  "tell me about the premium package": {
    intent: "request_product_info_premium",
    entities: [{ type: "product_tier", value: "premium" }],
    response: "The Premium Package is $99/month and includes advanced features like A, B, C, plus dedicated support and higher usage limits. What specific aspect are you interested in?",
  }
};

export function NaturalLanguageProcessor() {
  const [leadInput, setLeadInput] = useState('');
  const [nlpOutput, setNlpOutput] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleProcessInput = () => {
    if (!leadInput.trim()) {
      setNlpOutput({ error: "Please enter some text to process." });
      return;
    }
    setIsLoading(true);
    setNlpOutput(null);

    setTimeout(() => {
      const matchedResponse = mockNlpResponses[leadInput.trim().toLowerCase()];
      if (matchedResponse) {
        setNlpOutput(matchedResponse);
      } else {
        setNlpOutput({ 
            intent: "unknown_intent", 
            entities: [],
            response: "I'm not sure how to help with that. Could you try rephrasing, or would you like to speak to a human agent?" 
        });
      }
      setIsLoading(false);
    }, 1200); // Simulate API call
  };

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <MessageCircle className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Natural Language Processor
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Simulate how the system parses and responds to natural language queries from leads. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="flex-grow"
      >
        <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 pt-5 pb-3">
                <CardTitle className="text-lg font-semibold flex items-center gap-2"><Bot size={18} className="text-primary"/>NLP Interaction Simulator</CardTitle>
                <CardDescription className="text-sm">Enter a lead's query to see a mock AI interpretation and response.</CardDescription>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-4">
                <motion.div variants={itemVariants}>
                    <Label htmlFor="leadQuery" className="text-xs">Simulate Lead Input (e.g., "Text me the cheapest plan")</Label>
                    <Textarea 
                        id="leadQuery"
                        value={leadInput}
                        onChange={e => setLeadInput(e.target.value)}
                        className="shadcn-input mt-1 text-sm min-h-[60px]"
                        placeholder="Type a lead's message here..."
                    />
                </motion.div>
                <motion.div variants={itemVariants}>
                    <Button onClick={handleProcessInput} className="w-full shadcn-button" disabled={isLoading}>
                        {isLoading ? <Zap className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2"/>}
                        {isLoading ? 'Processing...' : 'Parse & Respond (Mock)'}
                    </Button>
                </motion.div>

                {nlpOutput && (
                    <motion.div 
                        variants={itemVariants} 
                        initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}}
                        className="mt-4 p-4 border border-border/40 rounded-md bg-muted/20 space-y-2.5"
                    >
                        {nlpOutput.error && <p className="text-sm text-destructive">{nlpOutput.error}</p>}
                        {nlpOutput.intent && (
                            <div>
                                <Label className="text-[11px] font-medium text-primary">Parsed Intent:</Label>
                                <p className="text-xs text-foreground bg-primary/10 px-1.5 py-0.5 rounded inline-block">{nlpOutput.intent}</p>
                            </div>
                        )}
                        {nlpOutput.entities && nlpOutput.entities.length > 0 && (
                            <div>
                                <Label className="text-[11px] font-medium text-primary">Detected Entities:</Label>
                                <ul className="list-disc list-inside pl-1">
                                {nlpOutput.entities.map((entity, index) => (
                                    <li key={index} className="text-xs text-foreground">
                                        <span className="font-semibold">{entity.type}:</span> {entity.value}
                                    </li>
                                ))}
                                </ul>
                            </div>
                        )}
                        {nlpOutput.response && (
                            <div>
                                <Label className="text-[11px] font-medium text-primary">System Response (Mock):</Label>
                                <p className="text-xs text-foreground p-2 bg-background/50 rounded border border-border/20">{nlpOutput.response}</p>
                            </div>
                        )}
                    </motion.div>
                )}
            </CardContent>
        </Card>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Conversational AI Core</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
               This NLP simulator demonstrates intent recognition and automated responses. A real system requires sophisticated NLP models (like GPT), intent/entity training, and integration with knowledge bases and CRM systems.
            </p>
        </div>
      </motion.div>
    </div>
  );
}