import React from 'react';
import { motion } from 'framer-motion';

export function HeroVideo({ onVideoEnd }) {
  const handleVideoError = () => {
    console.error("Hero video failed to load. Skipping to next screen.");
    onVideoEnd(); // Call onVideoEnd immediately if there's an error
  };

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden bg-black"> {/* Increased z-index to ensure it's on top */}
      <motion.video
        autoPlay
        muted
        loop={false} 
        playsInline
        className="absolute top-1/2 left-1/2 min-w-full min-h-full w-auto h-auto object-cover transform -translate-x-1/2 -translate-y-1/2"
        onEnded={onVideoEnd}
        onError={handleVideoError} // Added error handler
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <source src="/assets/hero.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </motion.video>
      {/* Optional overlay for text contrast - can be removed if video has good contrast or if we want pure black */}
      {/* <div className="absolute inset-0 bg-black/30"></div> */}
    </div>
  );
}