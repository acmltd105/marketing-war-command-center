import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Workflow, Puzzle, AlertTriangle, Settings2, PlayCircle, Eye } from 'lucide-react';

export function StudioBuilder() {
  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Workflow className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Twilio Studio Flow Builder
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Visually design and deploy communication workflows. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay:0.1, ease: "circOut" }}
        className="flex-grow flex flex-col items-center justify-center"
      >
        <Card className="frosty-glass w-full max-w-3xl p-0.5">
          <CardHeader className="text-center px-5 pt-8 pb-4">
            <Puzzle className="h-16 w-16 text-primary mx-auto mb-5 opacity-70" />
            <CardTitle className="text-2xl font-semibold text-foreground">Studio Flow Builder Interface</CardTitle>
            <CardDescription className="text-base text-muted-foreground mt-1.5">
              This area will host an interactive drag-and-drop interface for building Twilio Studio flows, similar to the official Twilio console experience.
            </CardDescription>
          </CardHeader>
          <CardContent className="px-5 pb-8 text-center">
            <p className="text-sm text-muted-foreground mb-6">
              Key features would include:
            </p>
            <ul className="list-disc list-inside text-left text-sm text-muted-foreground space-y-1.5 max-w-md mx-auto mb-8">
              <li>Widget library (Send Message, Make Call, HTTP Request, etc.)</li>
              <li>Canvas for arranging widgets and connecting transitions</li>
              <li>Configuration panel for selected widgets</li>
              <li>Flow validation and debugging tools</li>
              <li>Publishing and version control</li>
            </ul>
            <div className="flex gap-3 justify-center">
                <Button className="shadcn-button">
                    <PlayCircle className="h-4 w-4 mr-2" /> Create New Flow (Mock)
                </Button>
                <Button variant="outline" className="shadcn-button">
                    <Eye className="h-4 w-4 mr-2" /> View Existing Flows (Mock)
                </Button>
            </div>
          </CardContent>
        </Card>
        
        <div className="mt-8 p-3 frosty-glass rounded-md max-w-3xl w-full">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Feature Under Construction</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                The Twilio Studio Builder is a complex component. This is a placeholder representing where the visual builder interface will be integrated.
                Development of a full-fledged Studio-like experience is a significant undertaking.
            </p>
        </div>
      </motion.div>
    </div>
  );
}