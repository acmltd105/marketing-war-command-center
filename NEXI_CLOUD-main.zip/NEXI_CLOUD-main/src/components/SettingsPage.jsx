
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { AlertTriangle, SlidersHorizontal } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useTwilioData } from '@/hooks/useTwilioData';

import { SupabaseSecretsSection } from '@/components/settings_parts/SupabaseSecretsSection';
import { LocalTwilioCredentialsSection } from '@/components/settings_parts/LocalTwilioCredentialsSection';
import { LocalOpenAICredentialsSection } from '@/components/settings_parts/LocalOpenAICredentialsSection';
import { BillingSettingsSection } from '@/components/settings_parts/BillingSettingsSection';
import { NotificationSettingsSection } from '@/components/settings_parts/NotificationSettingsSection';
import { TwilioConnectionStatusIndicator } from '@/components/TwilioConnectionStatusIndicator';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

const initialNotificationsState = {
  lowBalanceAlert: false,
  campaignCompletion: false,
  apiErrors: false,
};

const initialBillingState = {
  currency: 'USD',
  paymentMethod: '',
  autoRefillEnabled: false,
  autoRefillAmount: 50,
  spendingLimitEnabled: false,
  spendingLimitAmount: 1000,
};

const initialTwilioCredentialsState = {
  accountSid: '',
  authToken: '',
  messagingServiceSid: '',
  phoneNumberSid: ''
};

const initialOpenAiCredentialsState = {
  apiKey: '',
};

export function SettingsPage() {
  const { settings: propSettingsData, updateSettings } = useTwilioData();

  const [notifications, setNotifications] = useState(initialNotificationsState);
  const [billing, setBilling] = useState(initialBillingState);
  const [twilioCredentials, setTwilioCredentials] = useState(initialTwilioCredentialsState);
  const [openAiCredentials, setOpenAiCredentials] = useState(initialOpenAiCredentialsState);
  const [supabaseSecrets, setSupabaseSecrets] = useState([]);
  const [isLoadingSecrets, setIsLoadingSecrets] = useState(true);
  const [showSecrets, setShowSecrets] = useState({});

  useEffect(() => {
    if (propSettingsData) {
      setNotifications(propSettingsData.notifications || initialNotificationsState);
      setBilling(propSettingsData.billing || initialBillingState);
      setTwilioCredentials(propSettingsData.twilioCredentials || initialTwilioCredentialsState);
      setOpenAiCredentials(propSettingsData.openAiCredentials || initialOpenAiCredentialsState);
    }
  }, [propSettingsData]);

  useEffect(() => {
    const fetchSupabaseSecrets = async () => {
      setIsLoadingSecrets(true);
      try {
        const { data, error } = await supabase.rpc('get_decrypted_secrets');
        if (error) {
          console.error("Error fetching Supabase secrets:", error);
          toast({ title: "Error Fetching Secrets", description: "Could not load secrets from Supabase Vault.", variant: "destructive" });
          setSupabaseSecrets([]);
        } else {
          const relevantSecrets = data.filter(secret => 
            !['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_DB_URL'].includes(secret.name)
          );
          setSupabaseSecrets(relevantSecrets || []);
        }
      } catch (e) {
        console.error("Exception fetching Supabase secrets:", e);
        toast({ title: "Exception Fetching Secrets", description: "An unexpected error occurred.", variant: "destructive" });
        setSupabaseSecrets([]);
      } finally {
        setIsLoadingSecrets(false);
      }
    };
    fetchSupabaseSecrets();
  }, []);

  const toggleShowSecret = (secretName) => {
    setShowSecrets(prev => ({ ...prev, [secretName]: !prev[secretName] }));
  };

  if (!propSettingsData && !isLoadingSecrets) {
     return (
      <div className="p-4 sm:p-6 md:p-8 h-full flex items-center justify-center">
        <Card className="frosty-glass w-full max-w-lg text-center p-0.5">
          <CardHeader>
            <AlertTriangle className="h-16 w-16 text-destructive mx-auto mb-4" />
            <CardTitle className="text-2xl">Settings Data Not Available</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              There was an issue loading initial settings. Please try again later or contact support.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleNotificationSwitchChange = (key, value) => {
    setNotifications(prev => ({ ...prev, [key]: value }));
  };

  const handleBillingInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setBilling(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) || 0 : value) }));
  };

  const handleBillingSelectChange = (key, value) => {
    setBilling(prev => ({ ...prev, [key]: value }));
  };
  
  const handleBillingSwitchChange = (key, value) => {
    setBilling(prev => ({ ...prev, [key]: value }));
  };

  const handleTwilioCredentialsChange = (e) => {
    const { name, value } = e.target;
    setTwilioCredentials(prev => ({ ...prev, [name]: value }));
  };

  const handleOpenAiCredentialsChange = (e) => {
    const { name, value } = e.target;
    setOpenAiCredentials(prev => ({ ...prev, [name]: value }));
  };

  const saveSettings = (category, data) => {
    if (typeof updateSettings === 'function') {
      updateSettings(category, data);
      toast({
        title: `${category.charAt(0).toUpperCase() + category.slice(1).replace(/([A-Z])/g, ' $1')} Settings Updated`,
        description: `Your ${category.replace(/([A-Z])/g, ' $1').toLowerCase()} preferences have been saved.`,
        duration: 3000,
      });
    } else {
       toast({
        title: "Error Saving Settings",
        description: "Could not save settings. Update function is missing.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  return (
    <motion.div 
      className="p-4 sm:p-6 md:p-8 space-y-8 md:space-y-10 h-full overflow-y-auto selection:bg-primary/20"
      variants={sectionVariants}
      initial="hidden"
      animate="visible"
      exit="hidden"
    >
      <motion.div variants={itemVariants}>
        <div className="flex items-center justify-start">
          <SlidersHorizontal className="h-8 w-8 md:h-9 md:w-9 text-primary mr-2.5 md:mr-3 opacity-85" />
          <div>
            <h1 className="text-3xl md:text-4xl font-semibold text-foreground tracking-tight">Platform Settings</h1>
            <p className="text-base md:text-lg text-muted-foreground mt-1">
              Manage your account, billing, notifications, and API credentials.
            </p>
          </div>
        </div>
      </motion.div>
      
      <motion.div variants={sectionVariants} custom={1}>
         <TwilioConnectionStatusIndicator />
      </motion.div>

      <motion.div variants={sectionVariants} custom={1.25}>
        <SupabaseSecretsSection 
          secrets={supabaseSecrets}
          isLoading={isLoadingSecrets}
          showSecrets={showSecrets}
          onToggleShowSecret={toggleShowSecret}
        />
      </motion.div>

      <motion.div variants={sectionVariants} custom={1.5}>
        <LocalTwilioCredentialsSection
          credentials={twilioCredentials}
          onChange={handleTwilioCredentialsChange}
          onSave={saveSettings}
        />
      </motion.div>

      <motion.div variants={sectionVariants} custom={1.75}>
        <LocalOpenAICredentialsSection
          credentials={openAiCredentials}
          onChange={handleOpenAiCredentialsChange}
          onSave={saveSettings}
        />
      </motion.div>

      <motion.div variants={sectionVariants} custom={2}>
        <BillingSettingsSection
          billing={billing}
          onInputChange={handleBillingInputChange}
          onSelectChange={handleBillingSelectChange}
          onSwitchChange={handleBillingSwitchChange}
          onSave={saveSettings}
        />
      </motion.div>

      <motion.div variants={sectionVariants} custom={3}>
        <NotificationSettingsSection
          notifications={notifications}
          onSwitchChange={handleNotificationSwitchChange}
          onSave={saveSettings}
        />
      </motion.div>
      
      <motion.p variants={itemVariants} className="text-center text-xs text-muted-foreground mt-8 pb-4">
        Team Management and advanced security settings will be available in future updates.
      </motion.p>
    </motion.div>
  );
}
