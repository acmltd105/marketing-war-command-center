import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Film, PlusCircle, Image as ImageIcon, Music, Sparkles, Play, MessageSquare, AlertTriangle, MousePointerSquare, BarChartHorizontal, Trash2, Clock, LayoutGrid, Send } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const animationElements = [
  { id: 'logoBounce', name: 'Logo Bounce', icon: Sparkles },
  { id: 'confetti', name: 'Confetti Drop', icon: Sparkles },
  { id: 'loadingBar', name: 'Progress Bar', icon: BarChartHorizontal },
];

const rcsButtonTypes = [
    { value: 'url', label: 'Open URL' },
    { value: 'dial', label: 'Dial Number' },
    { value: 'reply', label: 'Send Reply' },
    { value: 'calendar', label: 'Add to Calendar' }
];

const prebuiltTemplates = [
    { id: 'none', name: 'None (Start Fresh)' },
    { 
      id: 'flash_sale', 
      name: 'Flash Sale Alert', 
      text: "🚨 FLASH SALE! 🚨 Get 50% OFF all items for the next 24 hours ONLY! Don't miss out!",
      elements: [
        { type: 'animation', animationType: 'confetti', name: 'Confetti Drop' },
        { type: 'countdown', duration: '24:00:00' },
        { type: 'rcs_button', text: 'Shop Now', actionType: 'url', actionValue: 'https://yourstore.com/sale' }
      ]
    },
    { 
      id: 'holiday_greeting', 
      name: 'Holiday Special',
      text: "🎄 Happy Holidays from Our Team! 🎁 Wishing you joy and peace this season. Check out our special holiday offers!",
      elements: [
        { type: 'image', url: 'holiday_banner.gif' },
        { type: 'audio', url: 'jingle_bells.mp3', autoplay: false },
        { type: 'rcs_button', text: 'View Offers', actionType: 'url', actionValue: 'https://yourstore.com/holiday' }
      ]
    },
     { 
      id: 'new_product', 
      name: 'New Product Launch',
      text: "🚀 IT'S HERE! Our brand new {{ProductName}} just dropped! Be the first to experience the innovation.",
      elements: [
        { type: 'animation', animationType: 'logoBounce', name: 'Logo Bounce' },
        { type: 'rcs_button', text: 'Learn More', actionType: 'url', actionValue: 'https://yourstore.com/new-product' }
      ]
    }
];


export function AnimatedMessageBuilder() {
  const [messageText, setMessageText] = useState('');
  const [selectedChannel, setSelectedChannel] = useState('rcs'); // sms, rcs, mms
  const [addedElements, setAddedElements] = useState([]); 
  const [showButtonModal, setShowButtonModal] = useState(false);
  const [currentButton, setCurrentButton] = useState({ text: '', actionType: 'url', actionValue: '' });
  const { toast } = useToast();

  const addElement = (elementType, data = {}) => {
    const newElement = { id: `${elementType}_${Date.now()}`, type: elementType, ...data };
    setAddedElements(prev => [...prev, newElement]);
    toast({ title: "Element Added", description: `${data.name || elementType} added to message.`, variant: "default" });
  };
  
  const removeElement = (id) => {
    setAddedElements(prev => prev.filter(el => el.id !== id));
    toast({ title: "Element Removed", description: `Element has been removed.`, variant: "destructive" });
  };

  const handleAddRcsButton = () => {
    if (!currentButton.text || !currentButton.actionValue) {
        toast({ title: "Button Incomplete", description: "Please provide text and action value for the button.", variant: "destructive"});
        return;
    }
    addElement('rcs_button', { ...currentButton });
    setShowButtonModal(false);
    setCurrentButton({ text: '', actionType: 'url', actionValue: '' });
  };

  const loadTemplate = (templateId) => {
    if (templateId === 'none') {
        setMessageText('');
        setAddedElements([]);
        return;
    }
    const template = prebuiltTemplates.find(t => t.id === templateId);
    if (template) {
        setMessageText(template.text);
        const templateElements = template.elements.map(el => ({...el, id: `${el.type}_${Date.now()}_${Math.random()}`}));
        setAddedElements(templateElements);
        toast({ title: "Template Loaded", description: `"${template.name}" applied.`, variant: "default" });
    }
  };

  const getPreviewText = () => {
    let preview = messageText || "Your message text will appear here.";
    addedElements.forEach(el => {
        switch(el.type) {
            case 'image': preview += `\n[Image: ${el.url || 'placeholder.jpg'}]`; break;
            case 'audio': preview += `\n[Audio: ${el.url || 'sound.mp3'}${el.autoplay ? ' (Autoplay)' : ''}]`; break;
            case 'animation': preview += `\n[Animation: ${el.name}]`; break;
            case 'countdown': preview += `\n[Countdown: ${el.duration || '00:00:00'}]`; break;
            case 'rcs_button': preview += `\n[Button: "${el.text}" -> ${el.actionType}: ${el.actionValue}]`; break;
            default: preview += `\n[${el.type} element]`;
        }
    });
    return preview;
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Film className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Animation-Rich SMS & RCS Builder
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            "Turn boring texts into unforgettable experiences." Craft interactive messages without coding.
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        <motion.div variants={itemVariants} className="lg:col-span-1 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3">
              <CardTitle className="text-lg font-semibold text-foreground">Message Elements</CardTitle>
              <CardDescription className="text-sm">Drag-and-drop (conceptually) to build your message.</CardDescription>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-2 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
              <div>
                <Label className="text-xs">Channel</Label>
                <Select value={selectedChannel} onValueChange={setSelectedChannel}>
                  <SelectTrigger className="shadcn-input mt-1 text-sm"><SelectValue/></SelectTrigger>
                  <SelectContent className="shadcn-select-content">
                    <SelectItem value="sms" className="shadcn-select-item">SMS (Text Only)</SelectItem>
                    <SelectItem value="rcs" className="shadcn-select-item">RCS (Rich Content)</SelectItem>
                    <SelectItem value="mms" className="shadcn-select-item">MMS (Media Message)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Load Template (Mock)</Label>
                <Select onValueChange={loadTemplate}>
                  <SelectTrigger className="shadcn-input mt-1 text-sm"><SelectValue placeholder="Select a template..."/></SelectTrigger>
                  <SelectContent className="shadcn-select-content">
                    {prebuiltTemplates.map(template => (
                        <SelectItem key={template.id} value={template.id} className="shadcn-select-item">{template.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <p className="text-xs text-muted-foreground pt-1">Add Content:</p>
              {(selectedChannel === 'rcs' || selectedChannel === 'mms') && (
                <>
                  <Button variant="outline" className="w-full shadcn-button text-xs justify-start" onClick={() => addElement('image', {url: 'your_image.gif'})}>
                    <ImageIcon size={14} className="mr-2"/> Add Image/GIF
                  </Button>
                  <Button variant="outline" className="w-full shadcn-button text-xs justify-start" onClick={() => addElement('audio', {url: 'your_audio.mp3', autoplay: false})}>
                    <Music size={14} className="mr-2"/> Add Background Audio / Sound Effect
                  </Button>
                </>
              )}
              {selectedChannel === 'rcs' && (
                <>
                  {animationElements.map(anim => (
                    <Button key={anim.id} variant="outline" className="w-full shadcn-button text-xs justify-start" onClick={() => addElement('animation', { animationType: anim.id, name: anim.name })}>
                      <anim.icon size={14} className="mr-2"/> Add {anim.name}
                    </Button>
                  ))}
                  <Button variant="outline" className="w-full shadcn-button text-xs justify-start" onClick={() => addElement('countdown', {duration: '01:00:00'})}>
                    <Clock size={14} className="mr-2"/> Add Countdown Timer
                  </Button>
                  <Button variant="outline" className="w-full shadcn-button text-xs justify-start" onClick={() => setShowButtonModal(true)}>
                    <MousePointerSquare size={14} className="mr-2"/> Add RCS Button
                  </Button>
                </>
              )}

              {addedElements.length > 0 && (
                <div className="pt-2">
                    <Label className="text-xs">Added Elements:</Label>
                    <ul className="mt-1 space-y-1 text-xs">
                        {addedElements.map(el => (
                            <li key={el.id} className="flex justify-between items-center p-1.5 bg-muted/30 rounded text-muted-foreground">
                                <span className="truncate pr-1">{el.type === 'animation' ? el.name : el.type === 'rcs_button' ? `Button: "${el.text}"` : el.type.charAt(0).toUpperCase() + el.type.slice(1)}</span>
                                <Button variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-destructive flex-shrink-0" onClick={() => removeElement(el.id)}><Trash2 size={10}/></Button>
                            </li>
                        ))}
                    </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
             <CardHeader className="px-5 pt-5 pb-3">
                <CardTitle className="text-lg font-semibold text-foreground">Message Composer & Preview</CardTitle>
                <CardDescription className="text-sm">Type your message and see a conceptual preview below.</CardDescription>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3 flex flex-col flex-grow">
              <div>
                <Label htmlFor="messageText" className="text-xs">Message Body</Label>
                <Textarea 
                  id="messageText" 
                  value={messageText} 
                  onChange={e => setMessageText(e.target.value)} 
                  className="shadcn-input mt-1 text-sm min-h-[120px]"
                  placeholder="Example: 🚨 24hr FLASH SALE ends at midnight 🕛 — tap below to save your spot. 🎶 [music playing]"
                />
              </div>
              <div className="flex-grow mt-3 p-4 border border-dashed border-border/50 rounded-md bg-muted/20 flex flex-col items-center justify-center min-h-[150px]">
                <MessageSquare className="h-10 w-10 text-muted-foreground opacity-30 mb-2"/>
                <p className="text-xs font-medium text-muted-foreground mb-1">Conceptual Message Preview</p>
                <pre className="text-[10px] text-muted-foreground/80 text-center max-w-full whitespace-pre-wrap break-words">
                  {getPreviewText()}
                </pre>
                 <p className="text-[10px] text-muted-foreground/60 mt-2">Channel: {selectedChannel.toUpperCase()}</p>
              </div>
              <Button className="w-full shadcn-button mt-3" onClick={() => toast({title: "Launch Simulated", description: "Message sent to Twilio campaign flow (conceptual).", variant: "default"})}>
                <Send size={14} className="mr-2"/> Preview & Launch (Mock)
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      {showButtonModal && (
        <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowButtonModal(false)}
        >
            <motion.div 
                initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                className="frosty-glass p-6 rounded-lg w-full max-w-md"
                onClick={e => e.stopPropagation()}
            >
                <h3 className="text-lg font-semibold text-foreground mb-1">Configure RCS Button</h3>
                <p className="text-xs text-muted-foreground mb-3">Define the text and action for your button.</p>
                <div className="space-y-3">
                    <div>
                        <Label htmlFor="buttonText" className="text-xs">Button Text</Label>
                        <Input id="buttonText" value={currentButton.text} onChange={e => setCurrentButton(p => ({...p, text: e.target.value}))} className="shadcn-input mt-1 text-sm" placeholder="e.g., Learn More"/>
                    </div>
                    <div>
                        <Label htmlFor="buttonActionType" className="text-xs">Action Type</Label>
                        <Select value={currentButton.actionType} onValueChange={val => setCurrentButton(p => ({...p, actionType: val}))}>
                            <SelectTrigger id="buttonActionType" className="shadcn-input mt-1 text-sm"><SelectValue/></SelectTrigger>
                            <SelectContent className="shadcn-select-content">
                                {rcsButtonTypes.map(type => <SelectItem key={type.value} value={type.value} className="shadcn-select-item">{type.label}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label htmlFor="buttonActionValue" className="text-xs">Action Value</Label>
                        <Input id="buttonActionValue" value={currentButton.actionValue} onChange={e => setCurrentButton(p => ({...p, actionValue: e.target.value}))} className="shadcn-input mt-1 text-sm" placeholder={currentButton.actionType === 'url' ? 'https://example.com' : currentButton.actionType === 'dial' ? '+1234567890' : 'YES'}/>
                    </div>
                </div>
                <div className="flex gap-2 mt-4">
                    <Button variant="outline" className="w-full shadcn-button" onClick={() => setShowButtonModal(false)}>Cancel</Button>
                    <Button className="w-full shadcn-button" onClick={handleAddRcsButton}>Add Button</Button>
                </div>
            </motion.div>
        </motion.div>
      )}

      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Rich Messaging Capabilities</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This builder conceptualizes creating messages with animations, audio, and interactive RCS elements. Actual implementation requires specific carrier support for RCS features, robust handling of MMS content types, and integration with messaging APIs like Twilio.
            </p>
        </div>
      </motion.div>
    </div>
  );
}