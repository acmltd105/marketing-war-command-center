
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Send, Loader2, AlertTriangle, CheckCircle, MessageSquare, CornerDownLeft } from 'lucide-react';
import { cn } from '@/lib/utils';

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "circOut" } }
};

const ChatBubble = ({ message, type, isUser }) => {
  const bubbleClass = isUser
    ? "bg-primary text-primary-foreground self-end"
    : type === "success"
    ? "bg-green-500/20 text-green-700 dark:bg-green-500/30 dark:text-green-300 self-start"
    : type === "error"
    ? "bg-red-500/20 text-red-700 dark:bg-red-500/30 dark:text-red-300 self-start"
    : "bg-muted text-muted-foreground self-start";
  
  const icon = isUser 
    ? <Send className="h-4 w-4 shrink-0" /> 
    : type === "success" 
    ? <CheckCircle className="h-4 w-4 shrink-0" /> 
    : type === "error"
    ? <AlertTriangle className="h-4 w-4 shrink-0" />
    : <MessageSquare className="h-4 w-4 shrink-0" />;


  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={cn(
        "p-3 rounded-xl max-w-[80%] text-sm flex items-start gap-2.5 shadow-md",
        bubbleClass
      )}
    >
      {icon}
      <div className="flex-grow">
        <p className="font-semibold text-xs mb-0.5">{isUser ? "You Sent:" : "Function Replied:"}</p>
        <pre className="whitespace-pre-wrap break-all text-xs bg-transparent p-0">{message}</pre>
      </div>
    </motion.div>
  );
};


export function SmsTestSender() {
  const [to, setTo] = useState('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatLog, setChatLog] = useState([]); 

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!to || !message) {
      const errorText = "⚠️ Please fill in both phone number and message.";
      toast({
        title: "Missing Fields",
        description: "Please fill in both phone number and message.",
        variant: "destructive",
      });
      setChatLog(prev => [...prev, { id: Date.now(), text: errorText, type: 'error', isUser: false }]);
      return;
    }

    setIsLoading(true);
    const sentMessageEntry = { id: Date.now(), text: `To: ${to}\nMessage: ${message}`, type: 'info', isUser: true };
    setChatLog(prev => [...prev, sentMessageEntry]);

    try {
      const { data, error: functionError } = await supabase.functions.invoke('sendSMS', {
        body: JSON.stringify({ to, message }),
      });

      if (functionError) {
        let detailedErrorMessage = `Function Invocation Error: ${functionError.message || "Failed to send request to the Edge Function."}`;
        if (functionError.message && (functionError.message.toLowerCase().includes('failed to fetch') || functionError.message.toLowerCase().includes('networkerror') || functionError.message.toLowerCase().includes('failed to send a request'))) {
            detailedErrorMessage += "\n\nThis often indicates a CORS issue or network problem. Please check:\n1. The Edge Function ('sendSMS') must correctly handle OPTIONS preflight requests and return appropriate CORS headers.\n2. Open your browser's Developer Console (usually F12), go to the 'Network' tab, resend the SMS, and inspect the failed request for specific CORS error messages.\n3. Ensure your Supabase function URL is correct and the 'sendSMS' function is deployed and running without errors (check Supabase function logs).";
        }
        throw new Error(detailedErrorMessage);
      }
      
      if (data && data.error) { 
         throw new Error(`Function Execution Error: ${data.error}${data.details ? '\nDetails: ' + data.details : ''}`);
      }

      if (data && data.sid) {
        const successText = `✅ Message sent successfully! SID: ${data.sid}`;
        toast({
          title: "SMS Sent Successfully!",
          description: `Message SID: ${data.sid}`,
          variant: "success",
        });
        setChatLog(prev => [...prev, { id: Date.now() + 1, text: successText, type: 'success', isUser: false }]);
      } else if (data && data.message) { 
        const infoText = `ℹ️ ${data.message}`;
        toast({
          title: "Function Response",
          description: data.message,
          variant: "default",
        });
        setChatLog(prev => [...prev, { id: Date.now() + 1, text: infoText, type: 'info', isUser: false }]);
      }
      else {
         // This case should ideally not be hit if the function returns consistent responses
         console.warn("SmsTestSender: Unexpected response format from function:", data);
         throw new Error("Unknown or unexpected response format from the sendSMS function. Check function logs.");
      }

    } catch (err) {
      console.error("SMS Test Send Error Details:", err);
      const errorText = `❌ Failed: ${err.message || "An unknown error occurred during the test."}`;
      toast({
        title: "SMS Send Test Failed",
        description: err.message || "An unknown error occurred. Check console for details.",
        variant: "destructive",
        duration: 9000,
      });
      setChatLog(prev => [...prev, { id: Date.now() + 1, text: errorText, type: 'error', isUser: false }]);
    } finally {
      setIsLoading(false);
    }
  };
  
  useEffect(() => {
    const chatContainer = document.getElementById('chat-log-container');
    if (chatContainer) {
      chatContainer.scrollTop = chatContainer.scrollHeight;
    }
  }, [chatLog]);


  return (
    <motion.div variants={itemVariants}>
      <Card className="frosty-glass">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-primary" />
            Test SMS Function (Chat Style)
          </CardTitle>
          <CardDescription>
            Invoke 'sendSMS' and see results like a chat conversation.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {chatLog.length > 0 && (
            <div id="chat-log-container" className="mb-6 p-4 h-64 overflow-y-auto space-y-3 rounded-lg border bg-background/50 flex flex-col">
              {chatLog.map(logEntry => (
                <ChatBubble key={logEntry.id} message={logEntry.text} type={logEntry.type} isUser={logEntry.isUser} />
              ))}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="testPhone">To Phone Number (E.164)</Label>
                <Input
                  id="testPhone"
                  type="tel"
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  placeholder="+12345678900"
                  required
                  className="shadcn-input"
                />
              </div>
               <div className="space-y-1.5">
                <Label htmlFor="testMessage">Message</Label>
                <Textarea
                  id="testMessage"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Your test message..."
                  required
                  className="shadcn-input min-h-[40px] sm:min-h-[40px] resize-none"
                  rows={2}
                />
              </div>
            </div>
            <Button type="submit" className="w-full shadcn-button" disabled={isLoading}>
              {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <CornerDownLeft className="mr-2 h-4 w-4" />
              )}
              Send Test & View Reply
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
}
