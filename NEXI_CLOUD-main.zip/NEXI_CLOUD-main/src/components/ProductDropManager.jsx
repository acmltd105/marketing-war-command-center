import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { PackageOpen, PlusCircle, Edit3, Trash2, CalendarClock, Sparkles, ListChecks, AlertTriangle, HelpCircle, Image as ImageIcon } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialProductDrop = {
  id: '',
  productName: 'New Awesome Product',
  launchDate: new Date().toISOString().split('T')[0],
  keyFeatures: '',
  faq: '',
  visualUrl: '', // Mock URL for image/animation
  status: 'Planning', // Planning, Scheduled, Launched, Completed
  targetAudience: 'all_subscribers',
  announcementMessage: '',
  followUpMessage: '',
};

export function ProductDropManager() {
  const [drops, setDrops] = useState([]);
  const [selectedDrop, setSelectedDrop] = useState(null);
  const [currentConfig, setCurrentConfig] = useState({...initialProductDrop});

  const handleInputChange = (field, value) => {
    setCurrentConfig(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSaveDrop = () => {
    let dropToSave = {...currentConfig};
    if (!dropToSave.id) dropToSave.id = `drop_${Date.now()}`;
    
    const existingIndex = drops.findIndex(d => d.id === dropToSave.id);
    if (existingIndex > -1) {
      setDrops(drops.map(d => d.id === dropToSave.id ? dropToSave : d));
    } else {
      setDrops([...drops, dropToSave]);
    }
    setSelectedDrop(dropToSave);
    // Add toast for success
  };

  const handleNewDrop = () => {
    setSelectedDrop(null);
    setCurrentConfig({...initialProductDrop, id: `drop_${Date.now()}`});
  };

  const handleSelectDrop = (drop) => {
    setSelectedDrop(drop);
    setCurrentConfig(drop);
  };
  
  const handleDeleteDrop = (dropId) => {
    setDrops(prev => prev.filter(d => d.id !== dropId));
    if (selectedDrop && selectedDrop.id === dropId) {
      handleNewDrop();
    }
    // Add toast for deletion
  };

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <PackageOpen className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Product Drop Campaign Manager
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Plan and execute exciting product launch campaigns. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        <motion.div variants={itemVariants} className="lg:col-span-1 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3 flex flex-row justify-between items-center">
              <CardTitle className="text-lg font-semibold text-foreground">Product Drops</CardTitle>
              <Button size="sm" variant="outline" onClick={handleNewDrop} className="shadcn-button"><PlusCircle className="h-4 w-4 mr-1.5" /> New Drop</Button>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-2.5 max-h-[calc(100vh-350px)] overflow-y-auto scrollbar-hide">
              {drops.length === 0 ? <p className="text-xs text-muted-foreground text-center py-4">No product drops planned.</p> : drops.map(d => (
                <div key={d.id} className={`p-2.5 rounded-md border cursor-pointer ${selectedDrop?.id === d.id ? 'bg-primary/10 border-primary/50' : 'bg-muted/30 hover:bg-muted/50 border-transparent'}`} onClick={() => handleSelectDrop(d)}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-foreground">{d.productName}</span>
                    <Badge variant={d.status === 'Launched' ? 'default' : 'outline'} className="shadcn-badge capitalize text-[10px]">{d.status}</Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground">Launch: {d.launchDate}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
             <CardHeader className="px-5 pt-5 pb-3">
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        {selectedDrop ? <Edit3 className="h-5 w-5 text-primary" /> : <PlusCircle className="h-5 w-5 text-primary" />}
                        <CardTitle className="text-lg font-semibold text-foreground">{selectedDrop ? `Edit: ${currentConfig.productName}` : 'Plan New Product Drop'}</CardTitle>
                    </div>
                    <Button onClick={handleSaveDrop} className="shadcn-button" size="sm"><ListChecks className="h-4 w-4 mr-1.5"/> Save Drop Plan</Button>
                </div>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                    <Label htmlFor="dropProductName" className="text-xs">Product Name</Label>
                    <Input id="dropProductName" value={currentConfig.productName} onChange={e => handleInputChange('productName', e.target.value)} className="shadcn-input mt-1 text-sm" />
                </div>
                <div>
                    <Label htmlFor="dropLaunchDate" className="text-xs">Target Launch Date</Label>
                    <Input id="dropLaunchDate" type="date" value={currentConfig.launchDate} onChange={e => handleInputChange('launchDate', e.target.value)} className="shadcn-input mt-1 text-sm" />
                </div>
              </div>
              <div>
                <Label htmlFor="dropKeyFeatures" className="text-xs">Key Features (bullet points)</Label>
                <Textarea id="dropKeyFeatures" value={currentConfig.keyFeatures} onChange={e => handleInputChange('keyFeatures', e.target.value)} className="shadcn-input mt-1 text-sm min-h-[60px]" placeholder="Feature 1&#10;Feature 2&#10;Feature 3"/>
              </div>
               <div>
                <Label htmlFor="dropFAQ" className="text-xs">Mini FAQ (Q&A format)</Label>
                <Textarea id="dropFAQ" value={currentConfig.faq} onChange={e => handleInputChange('faq', e.target.value)} className="shadcn-input mt-1 text-sm min-h-[60px]" placeholder="Q: What is X?&#10;A: It's amazing because..."/>
              </div>
              <div>
                <Label htmlFor="dropVisualUrl" className="text-xs">Visual URL (Image/Animation for RCS - Mock)</Label>
                <div className="flex items-center gap-2 mt-1">
                    <Input id="dropVisualUrl" value={currentConfig.visualUrl} onChange={e => handleInputChange('visualUrl', e.target.value)} className="shadcn-input text-sm flex-grow" placeholder="https://example.com/product_animation.gif"/>
                    <Button variant="outline" size="icon" className="shadcn-button h-9 w-9"><ImageIcon size={14}/></Button>
                </div>
              </div>
              <div>
                <Label htmlFor="dropAnnouncement" className="text-xs">Announcement Message (SMS/RCS)</Label>
                <Textarea id="dropAnnouncement" value={currentConfig.announcementMessage} onChange={e => handleInputChange('announcementMessage', e.target.value)} className="shadcn-input mt-1 text-sm min-h-[50px]" placeholder="It's here! [Product Name] just dropped!"/>
              </div>
               <div>
                <Label htmlFor="dropFollowUp" className="text-xs">Follow-up Message (Optional)</Label>
                <Textarea id="dropFollowUp" value={currentConfig.followUpMessage} onChange={e => handleInputChange('followUpMessage', e.target.value)} className="shadcn-input mt-1 text-sm min-h-[50px]" placeholder="Still thinking about [Product Name]? Check out the reviews..."/>
              </div>
               <div className="flex gap-2 pt-2">
                <Button variant="outline" className="w-full shadcn-button text-xs" onClick={() => handleInputChange('status', 'Scheduled')}>
                    <CalendarClock size={14} className="mr-2"/> Schedule Drop
                </Button>
                 <Button variant="default" className="w-full shadcn-button text-xs" onClick={() => handleInputChange('status', 'Launched')}>
                    <Sparkles size={14} className="mr-2"/> Launch Now (Mock)
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Launch Coordination Center</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
               Product Drop Manager conceptualizes creating hype campaigns. Real implementation involves messaging API integration for scheduled sends, dynamic content for product details, and possibly unique promo codes.
            </p>
        </div>
      </motion.div>
    </div>
  );
}