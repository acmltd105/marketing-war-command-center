import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bot, AlertTriangle, Edit3, PlusCircle, Save } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { BotList } from '@/components/bot_army_builder_parts/BotList';
import { BotConfigTabs } from '@/components/bot_army_builder_parts/BotConfigTabs';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.07, delayChildren: i * 0.07, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialBot = {
  id: '',
  name: '',
  description: '',
  type: 'chatbot',
  languageModel: 'gpt-4o',
  complianceProfile: 'standard',
  status: 'Draft',
  greetingMessages: ['Hello! How can I assist you today?', 'Hi there! What can I help you with?'],
  fallbackMessages: ["I'm sorry, I didn't quite understand that. Could you please rephrase?", "My apologies, I'm still learning. Can you try asking in a different way?"],
  humanHandoffTrigger: '3_failed_attempts',
  humanHandoffTarget: 'live_agent_queue_default',
  intents: [],
  entities: [],
  knowledgeBaseSources: [],
  fineTuningData: '',
  channels: { sms: false, webchat: true, voice: false, whatsapp: false },
};


export function BotArmyBuilder() {
  const [bots, setBots] = useState([]);
  const [selectedBot, setSelectedBot] = useState(null);
  const [currentBotConfig, setCurrentBotConfig] = useState({...initialBot});
  const [activeConfigTab, setActiveConfigTab] = useState("general");
  const [mockChat, setMockChat] = useState([]);
  const [userInput, setUserInput] = useState("");

  useEffect(() => {
    if (selectedBot) {
      setCurrentBotConfig(selectedBot);
      setActiveConfigTab("general");
      setMockChat([]);
    } else {
      setCurrentBotConfig({...initialBot, id: `bot_${Date.now()}`});
      setActiveConfigTab("general");
      setMockChat([]);
    }
  }, [selectedBot]);

  const handleInputChange = (field, value) => {
    setCurrentBotConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleNestedInputChange = (area, field, value) => {
    setCurrentBotConfig(prev => ({
      ...prev,
      [area]: {
        ...prev[area],
        [field]: value
      }
    }));
  };
  
  const handleGreetingChange = (index, value) => {
    const newGreetings = [...currentBotConfig.greetingMessages];
    newGreetings[index] = value;
    handleInputChange('greetingMessages', newGreetings);
  };

  const addGreeting = () => handleInputChange('greetingMessages', [...currentBotConfig.greetingMessages, '']);
  const removeGreeting = (index) => handleInputChange('greetingMessages', currentBotConfig.greetingMessages.filter((_, i) => i !== index));

  const handleCreateOrUpdateBot = () => {
    if (!currentBotConfig.name) {
      toast({ title: "Bot Name Required", description: "Please enter a name for your bot.", variant: "destructive" });
      return;
    }

    let botToSave = {...currentBotConfig};
    if (!botToSave.id) {
      botToSave.id = `bot_${Date.now()}`;
    }
    
    const existingBotIndex = bots.findIndex(b => b.id === botToSave.id);

    if (existingBotIndex > -1) {
      setBots(prevBots => prevBots.map(b => b.id === botToSave.id ? botToSave : b));
      toast({ title: "Bot Updated", description: `'${botToSave.name}' configuration saved.` });
    } else {
      setBots(prevBots => [...prevBots, botToSave]);
      toast({ title: "Bot Created", description: `'${botToSave.name}' has been added to your army.` });
    }
    setSelectedBot(botToSave); 
  };
  
  const updateBotStatusAndSave = (newStatus) => {
    const updatedConfig = { ...currentBotConfig, status: newStatus };
    setCurrentBotConfig(updatedConfig); // Update local state first

    // Then proceed to save it to the list
    if (!updatedConfig.name) {
      toast({ title: "Bot Name Required", description: "Please enter a name for your bot before changing status.", variant: "destructive" });
      return;
    }
    
    let botToSave = {...updatedConfig};
    if (!botToSave.id) {
      botToSave.id = `bot_${Date.now()}`;
    }
    
    const existingBotIndex = bots.findIndex(b => b.id === botToSave.id);

    if (existingBotIndex > -1) {
      setBots(prevBots => prevBots.map(b => b.id === botToSave.id ? botToSave : b));
    } else {
      setBots(prevBots => [...prevBots, botToSave]);
    }
    setSelectedBot(botToSave);
  };


  const handleSelectBot = (bot) => {
    setSelectedBot(bot);
  };

  const handleCreateNewBot = () => {
    setSelectedBot(null);
    setCurrentBotConfig({...initialBot, id: `bot_${Date.now()}`});
    setActiveConfigTab("general");
  };

  const handleDeleteBot = (botId) => {
    setBots(prevBots => prevBots.filter(b => b.id !== botId));
    if (selectedBot && selectedBot.id === botId) {
      handleCreateNewBot(); 
    }
    toast({ title: "Bot Deleted", description: "The bot has been removed from your army.", variant: "destructive" });
  };

  const handleMockChatSubmit = () => {
    if (!userInput.trim()) return;
    const newChat = [...mockChat, { sender: 'user', text: userInput }];
    const botResponse = currentBotConfig.greetingMessages[Math.floor(Math.random() * currentBotConfig.greetingMessages.length)] || "This is a mock response.";
    newChat.push({ sender: 'bot', text: botResponse});
    setMockChat(newChat);
    setUserInput("");
  };

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Bot className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              AI Bot Army Builder
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Design, configure, and deploy intelligent chatbots and voicebots. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        
        <motion.div variants={itemVariants} className="lg:col-span-1 space-y-6 flex flex-col">
          <BotList 
            bots={bots}
            selectedBot={selectedBot}
            onSelectBot={handleSelectBot}
            onCreateNewBot={handleCreateNewBot}
            onDeleteBot={handleDeleteBot}
          />
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow flex flex-col">
            <CardHeader className="px-5 pt-5 pb-1">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2.5">
                  {selectedBot ? <Edit3 className="h-5 w-5 text-primary opacity-90" /> : <PlusCircle className="h-5 w-5 text-primary opacity-90" />}
                  <CardTitle className="text-lg font-semibold text-foreground">
                    {selectedBot ? `Configure: ${selectedBot.name}` : "Create New Bot"}
                  </CardTitle>
                </div>
                 <Button onClick={handleCreateOrUpdateBot} className="shadcn-button" size="sm" disabled={!currentBotConfig.name}>
                    <Save className="h-4 w-4 mr-2"/> {selectedBot && bots.find(b => b.id === selectedBot.id) ? 'Save Changes' : 'Create & Save Bot'}
                  </Button>
              </div>
              <CardDescription className="text-sm mt-0.5">{selectedBot ? "Modify the bot's settings and behavior." : "Define the initial parameters for your new AI assistant."}</CardDescription>
            </CardHeader>
            <CardContent className="px-1 py-1 flex-grow flex flex-col">
              <BotConfigTabs
                activeTab={activeConfigTab}
                onTabChange={setActiveConfigTab}
                currentBotConfig={currentBotConfig}
                onInputChange={handleInputChange}
                onNestedInputChange={handleNestedInputChange}
                onGreetingChange={handleGreetingChange}
                onAddGreeting={addGreeting}
                onRemoveGreeting={removeGreeting}
                mockChat={mockChat}
                userInput={userInput}
                onUserInput={setUserInput}
                onMockChatSubmit={handleMockChatSubmit}
                onUpdateBotStatusAndSave={updateBotStatusAndSave}
              />
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6 md:pt-8"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Advanced AI Feature</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                The Bot Army Builder is a highly advanced module. This interface provides a conceptual overview. Full implementation requires robust backend services for NLP/NLU, state management, machine learning model hosting, and secure API integrations. Compliance settings are illustrative and need thorough legal and technical validation for real-world use.
            </p>
        </div>
      </motion.div>
    </div>
  );
}