import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button'; // Added Button import
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Phone, 
  Users, 
  DollarSign,
  Activity,
  Zap,
  Target,
  BarChart3,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Clock,
  ShieldAlert,
  Server
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { CountUp } from '@/components/ui/CountUp';


const cardVariants = {
  hidden: { opacity: 0, y: 25, scale: 0.96 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.07, 
      type: "spring",
      stiffness: 260,
      damping: 20,
    }
  })
};

const sectionVariants = {
  hidden: { opacity: 0 },
  visible: { 
    opacity: 1,
    transition: { 
      staggerChildren: 0.15, 
      delayChildren: 0.1,
    }
  }
};


export function Dashboard({ data, handleTabChange }) {
  const { analytics, campaigns, apiStatus } = data;
  const { toast } = useToast();
  const navigate = useNavigate();

  const metrics = [
    {
      title: 'Messages Sent (Today)',
      value: analytics.totalMessages || 0,
      icon: MessageSquare,
      change: '+12.5% vs Yesterday',
      color: 'text-primary'
    },
    {
      title: 'Active Voice Calls',
      value: analytics.totalCalls || 0,
      icon: Phone,
      change: '+8.2% vs Last Hour',
      color: 'text-green-600' 
    },
    {
      title: 'Delivery Rate (Last 24h)',
      value: analytics.deliveryRate || 0,
      suffix: '%',
      icon: Target,
      change: '+2.1% vs Avg.',
      color: 'text-sky-500' 
    },
    {
      title: 'Campaign Spend (Today)',
      value: analytics.totalSpent || 0,
      prefix: '$',
      icon: DollarSign,
      change: '+15.3% vs Yesterday',
      color: 'text-amber-500' 
    }
  ];

  const apiServices = [
    { name: 'Messaging API', status: apiStatus.messaging || 'operational', usage: 94, iconColor: 'bg-primary' },
    { name: 'Voice API', status: apiStatus.voice || 'operational', usage: 87, iconColor: 'bg-green-500' },
    { name: 'Authentication API', status: apiStatus.verify || 'error', usage: 88, iconColor: 'bg-destructive' },
    { name: 'Supabase Backend', status: 'operational', usage: 98, iconColor: 'bg-emerald-500' }
  ];
  
  const criticalAlerts = [
    // Example: { id: 1, message: "Low Twilio Balance: $5.30 remaining.", severity: "high", timestamp: "2 mins ago", action: () => navigate('/billing') },
    // Example: { id: 2, message: "OpenAI API Key quota nearing limit.", severity: "medium", timestamp: "1 hour ago", action: () => navigate('/settings') }
  ];
  if (apiStatus.verify === 'error') {
    criticalAlerts.push({
      id: 'authApiError',
      message: 'Authentication API (Twilio Verify) is experiencing issues. 2FA might be affected.',
      severity: 'high',
      timestamp: 'Now',
      action: () => handleTabChange ? handleTabChange('apis') : navigate('/twilio-apis')
    });
  }


  return (
    <motion.div 
      className="space-y-6 md:space-y-8"
      variants={sectionVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div
        custom={0}
        variants={cardVariants}
        className="mb-4 md:mb-6"
      >
        <h1 className="text-2xl md:text-3xl font-semibold text-foreground tracking-tight">
          Live Performance Dashboard
        </h1>
        <p className="text-sm md:text-base text-muted-foreground mt-1">
          Real-time KPIs, campaign status, and system health.
        </p>
      </motion.div>

      {criticalAlerts.length > 0 && (
        <motion.div variants={cardVariants} custom={0.5}>
          <Card className="border-red-500/50 bg-red-900/10 p-0.5 frosty-glass">
            <CardHeader className="px-4 pt-4 pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2 text-red-400">
                <ShieldAlert className="h-5 w-5" />
                Critical System Alerts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 px-4 pb-4">
              {criticalAlerts.map(alert => (
                <div key={alert.id} className="flex items-center justify-between p-2.5 bg-red-500/10 rounded-md border border-red-500/30">
                  <div>
                    <p className="text-xs font-medium text-red-300">{alert.message}</p>
                    <p className="text-[10px] text-red-400/80 flex items-center gap-1"><Clock size={10}/> {alert.timestamp}</p>
                  </div>
                  {alert.action && (
                    <Button variant="destructive" size="xs" className="text-[10px] h-6 px-2 shadcn-button" onClick={alert.action}>
                      View Details
                    </Button>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      )}

      <motion.div 
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5"
        variants={sectionVariants}
      >
        {metrics.map((metric, index) => (
          <motion.div
            key={metric.title}
            custom={index + 1}
            variants={cardVariants}
          >
            <Card className="metric-card p-0.5 frosty-glass">
              <CardHeader className="pb-2 pt-4 px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground">{metric.title}</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <div className="flex items-baseline justify-between">
                    <p className="text-2xl md:text-3xl font-bold text-foreground">
                      {metric.prefix}
                      <CountUp end={metric.value} duration={1.5} />
                      {metric.suffix}
                    </p>
                    <metric.icon className={`h-5 w-5 md:h-6 md:w-6 ${metric.color} opacity-70`} />
                </div>
                <div className="flex items-center text-[11px] text-muted-foreground pt-1.5">
                  <TrendingUp size={12} className="mr-1 text-green-500"/> 
                  {metric.change}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      <motion.div 
        className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-5"
        variants={sectionVariants}
      >
        <motion.div variants={cardVariants} custom={metrics.length + 1}>
          <Card className="api-card p-0.5 frosty-glass">
            <CardHeader className="px-4 pt-4 pb-3">
              <CardTitle className="text-base font-semibold flex items-center gap-2 text-foreground">
                <Server className="h-4 w-4 text-primary opacity-90" />
                Core Service Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 px-4 pb-4">
              {apiServices.map((service) => (
                <motion.div 
                  key={service.name} 
                  className="pt-0.5"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.1 * apiServices.indexOf(service) }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-foreground">{service.name}</span>
                    <Badge 
                      data-variant={service.status === 'operational' ? 'default' : service.status === 'error' ? 'destructive' : 'secondary'}
                      className={`shadcn-badge text-[10px] py-0.5 px-1.5 ${service.status === 'operational' ? 'bg-green-500/15 text-green-700 border-green-500/30' : service.status === 'error' ? 'bg-red-500/15 text-red-700 border-red-500/30' : 'bg-yellow-500/15 text-yellow-700 border-yellow-500/30'}`}
                    >
                      {service.status === 'operational' ? <CheckCircle className="h-2.5 w-2.5 mr-1 inline"/> : <AlertCircle className="h-2.5 w-2.5 mr-1 inline"/>}
                      {service.status.charAt(0).toUpperCase() + service.status.slice(1)}
                    </Badge>
                  </div>
                  <Progress value={service.usage} className="h-1.5 bg-muted/70" indicatorClassName={`${service.iconColor} opacity-90`} />
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} custom={metrics.length + 2}>
          <Card className="campaign-card p-0.5 frosty-glass">
            <CardHeader className="px-4 pt-4 pb-3">
              <CardTitle className="text-base font-semibold flex items-center gap-2 text-foreground">
                <BarChart3 className="h-4 w-4 text-primary opacity-90" />
                Ongoing Campaigns Snapshot
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 px-4 pb-4 max-h-[200px] overflow-y-auto scrollbar-thin">
              {campaigns.filter(c => c.status === 'active').slice(0, 3).map((campaign, idx) => (
                <motion.div 
                  key={campaign.id} 
                  className="p-3 rounded-md border border-border/70 bg-background/30 hover:bg-background/50 transition-colors cursor-pointer"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.1 * idx }}
                  onClick={() => handleTabChange ? handleTabChange('campaigns') : navigate('/')}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-foreground">{campaign.name}</span>
                    <Badge 
                      variant='outline'
                      className="shadcn-badge text-[10px] py-0.5 px-1.5 border-primary/50 text-primary"
                    >
                      {campaign.type.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5 text-[10px] text-muted-foreground">
                    <span>Recipients: {campaign.recipients?.toLocaleString()}</span>
                    <span>Delivered: {campaign.delivered?.toLocaleString()} ({((campaign.delivered/campaign.recipients)*100 || 0).toFixed(1)}%)</span>
                  </div>
                  <Progress value={(campaign.delivered / campaign.recipients) * 100 || 0} className="h-1 mt-2 bg-muted/70" indicatorClassName="bg-primary opacity-90" />
                </motion.div>
              ))}
              {campaigns.filter(c => c.status === 'active').length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-6">No active campaigns currently running.</p>
              )}
            </CardContent>
             {campaigns.filter(c => c.status === 'active').length > 0 && (
                <div className="px-4 pb-3 border-t border-border/30 pt-3">
                    <Button variant="outline" size="xs" className="w-full shadcn-button text-[10px]" onClick={() => handleTabChange ? handleTabChange('campaigns') : navigate('/')}>
                        View All Campaigns
                    </Button>
                </div>
            )}
          </Card>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}
