import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Circle, AlertCircle, KeyRound, PhoneCall, Users, FileText, ShieldCheck, Send, Rocket, ExternalLink, Settings2, Info } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialSteps = [
  { 
    id: 1, 
    title: "Connect API Credentials", 
    description: "Securely link your Twilio, OpenAI, and other essential service API keys.", 
    icon: KeyRound, 
    status: "pending", 
    actionLabel: "Configure APIs",
    details: "Navigate to Settings > API Credentials to input and verify your keys. This is crucial for all communication and AI features.",
    actionLink: "/settings#api-credentials" // Conceptual link
  },
  { 
    id: 2, 
    title: "Setup Phone Numbers & Messaging", 
    description: "Configure your sending phone numbers and Twilio Messaging Service SIDs.", 
    icon: PhoneCall, 
    status: "pending", 
    actionLabel: "Manage Numbers",
    details: "Go to Phone Services to add or verify your Twilio phone numbers and associate them with Messaging Services for campaign delivery.",
    actionLink: "/phone-services"
  },
  { 
    id: 3, 
    title: "Import Core Data", 
    description: "Upload initial contact lists or connect your primary data sources.", 
    icon: Users, 
    status: "pending", 
    actionLabel: "Import Data",
    details: "Use the Lead Intel Hub or Data Connections tab in the Operations Hub to bring in your customer data.",
    actionLink: "/lead-intel-hub"
  },
  { 
    id: 4, 
    title: "Review Compliance & Legal", 
    description: "Ensure A2P 10DLC registration (if applicable) and link privacy policies.", 
    icon: ShieldCheck, 
    status: "pending", 
    actionLabel: "View Compliance",
    details: "Visit the Compliance Center to check your A2P 10DLC status and add links to your Privacy Policy and Terms of Service.",
    actionLink: "/compliance-center"
  },
  { 
    id: 5, 
    title: "Create First Test Campaign", 
    description: "Set up a small test campaign to verify end-to-end functionality.", 
    icon: Send, 
    status: "pending", 
    actionLabel: "Create Campaign",
    details: "Go to the Campaigns tab in the Operations Hub to design and launch a small test campaign to a few internal numbers.",
    actionLink: "/#campaigns" // Navigates to Operations Hub, campaigns tab
  },
  { 
    id: 6, 
    title: "User & Team Setup (Conceptual)", 
    description: "Invite team members and configure user roles (future feature).", 
    icon: Users, 
    status: "pending", 
    actionLabel: "Manage Users (Soon)",
    details: "User management features are planned for a future update. For now, this step is informational.",
    isFuture: true
  },
  { 
    id: 7, 
    title: "Final System Check & Launch Readiness", 
    description: "Review all configurations and confirm system health before going live.", 
    icon: Rocket, 
    status: "pending", 
    actionLabel: "Perform Checks",
    details: "Double-check all previous steps. Monitor the Machine Health dashboard for any alerts. Ensure all API connections are stable.",
    actionLink: "/machine-health"
  },
];

export function IgnitionSequence() {
  const [steps, setSteps] = useState(initialSteps);
  const { toast } = useToast();
  const navigate = useNavigate();

  const completedSteps = steps.filter(step => step.status === 'completed').length;
  const progressPercentage = (completedSteps / steps.length) * 100;

  const handleStepAction = (step) => {
    if (step.isFuture) {
      toast({ title: "Coming Soon!", description: `${step.title} is planned for a future update.`, variant: "default" });
      return;
    }
    if (step.actionLink) {
      navigate(step.actionLink);
      toast({ title: `Navigating to ${step.title}`, description: `Please complete the required actions.`, variant: "default" });
    } else {
      toast({ title: "🚧 Action Placeholder", description: `Functionality for "${step.actionLabel}" is conceptual.`, duration: 3000 });
    }
    // For demo, let's allow marking as complete
    // In a real app, this would be based on actual completion via API calls or other checks
  };

  const markStepComplete = (stepId) => {
    setSteps(prevSteps => 
      prevSteps.map(step => 
        step.id === stepId ? { ...step, status: step.status === 'completed' ? 'pending' : 'completed' } : step
      )
    );
    const step = steps.find(s => s.id === stepId);
    if (step) {
        toast({
            title: `Step ${step.status === 'completed' ? 'Marked Pending' : 'Marked Complete'}`,
            description: `${step.title} status updated.`,
            variant: "default"
        });
    }
  };
  
  const getStatusIcon = (status) => {
    if (status === 'completed') return <CheckCircle className="text-green-500" />;
    if (status === 'pending') return <Circle className="text-yellow-500 animate-pulse" />;
    return <AlertCircle className="text-orange-500" />;
  };

  return (
    <div className="p-4 sm:p-6 md:p-8 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-6 md:mb-8"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Rocket className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Ignition Sequence
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Your step-by-step guide to launching the NEXIE Command Center. Complete these stages for full operational readiness.
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={itemVariants}
        initial="hidden"
        animate="visible"
        className="mb-6 md:mb-8"
      >
        <Card className="frosty-glass p-0.5">
          <CardContent className="p-4 md:p-5">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-foreground">Setup Progress: {completedSteps} of {steps.length} Steps</p>
              <Badge variant={progressPercentage === 100 ? "default" : "outline"} className={`shadcn-badge ${progressPercentage === 100 ? 'bg-green-500/20 text-green-600 border-green-500/40' : 'border-primary/40 text-primary'}`}>
                {progressPercentage === 100 ? "All Systems Go!" : `${Math.round(progressPercentage)}% Complete`}
              </Badge>
            </div>
            <Progress value={progressPercentage} className="h-2.5" indicatorClassName={progressPercentage === 100 ? "bg-green-500" : "bg-primary"} />
          </CardContent>
        </Card>
      </motion.div>

      <motion.div 
        variants={sectionVariants}
        initial="hidden"
        animate="visible"
        className="space-y-4 md:space-y-5 flex-grow"
      >
        {steps.map((step, index) => (
          <motion.div key={step.id} variants={itemVariants}>
            <Card className="frosty-glass p-0.5 overflow-hidden transition-all hover:shadow-lg hover:border-primary/20">
              <CardHeader className="flex flex-row items-start gap-4 p-4 md:p-5 bg-background/20">
                <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${step.status === 'completed' ? 'bg-green-500/15' : 'bg-primary/10'}`}>
                  <step.icon className={`h-5 w-5 ${step.status === 'completed' ? 'text-green-600' : 'text-primary'}`} />
                </div>
                <div className="flex-grow">
                  <CardTitle className="text-base md:text-lg font-semibold text-foreground">{step.id}. {step.title}</CardTitle>
                  <CardDescription className="text-xs md:text-sm mt-0.5">{step.description}</CardDescription>
                </div>
                <div className="flex flex-col items-end gap-2 ml-auto flex-shrink-0">
                  {getStatusIcon(step.status)}
                  {step.actionLabel && !step.isFuture && (
                    <Button 
                      size="sm" 
                      variant={step.status === 'completed' ? "ghost" : "outline"} 
                      className="shadcn-button text-xs h-7 px-2.5"
                      onClick={() => handleStepAction(step)}
                    >
                      {step.actionLabel}
                      {step.actionLink && <ExternalLink size={11} className="ml-1.5 opacity-70"/>}
                    </Button>
                  )}
                   {step.isFuture && (
                     <Badge variant="outline" className="text-[9px] px-1.5 py-0.5 bg-sky-500/10 text-sky-600 border-sky-500/30">Future</Badge>
                   )}
                </div>
              </CardHeader>
              <CardContent className="p-4 md:p-5 text-xs md:text-sm border-t border-border/30">
                <div className="flex items-start gap-2 text-muted-foreground bg-muted/20 p-3 rounded-md border border-border/20">
                    <Info size={16} className="flex-shrink-0 mt-0.5 text-primary/70"/>
                    <p>{step.details}</p>
                </div>
                {!step.isFuture && (
                    <Button 
                        variant="link" 
                        className="text-xs mt-2 h-auto p-0 text-primary hover:text-primary/80"
                        onClick={() => markStepComplete(step.id)}
                    >
                        {step.status === 'completed' ? 'Mark as Pending' : 'Mark as Complete (Manual)'}
                    </Button>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        className="mt-auto pt-6 md:pt-8 text-center"
      >
        {progressPercentage === 100 ? (
          <Button size="lg" className="shadcn-button bg-green-600 hover:bg-green-700 text-white" onClick={() => {
            toast({ title: "Launch Sequence Initiated!", description: "NEXIE Command Center is ready for operations!", variant: "default" });
            navigate('/');
          }}>
            <Rocket className="h-5 w-5 mr-2" /> Launch Command Center
          </Button>
        ) : (
          <p className="text-sm text-muted-foreground">Complete all steps to unlock the launch button.</p>
        )}
      </motion.div>
    </div>
  );
}