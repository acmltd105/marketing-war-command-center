
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Repeat, KeyRound as UsersRound, Network, Workflow, AlertTriangle, Mail, MessageSquare, PlayCircle, Eye, Palette, PlusCircle, Trash2, Settings2, Edit3, FileText } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};


const mockProductHighlights = [
  { id:1, name: "Product A Feature", image: "modern_gadget_1", desc: "Experience seamless integration and top-tier performance." },
  { id:2, name: "Benefit of Service B", image: "abstract_background_service", desc: "Unlock unparalleled efficiency and save valuable time." },
  { id:3, name: "Product C Advantage", image: "sleek_device_close_up", desc: "Stay ahead of the curve with cutting-edge technology." }
];

const initialRule = { 
  id: `rule_${Date.now()}`, 
  name: 'New Rule', 
  conditions: [{ field: 'zipCode', operator: 'startsWith', value: '' }], 
  actions: [{ type: 'sendSMS', campaignId: '' }] 
};


export function LeadLifecycleManager() {
  const [activeMainTab, setActiveMainTab] = useState("resumeJourneys");
  const [rules, setRules] = useState([
    { id: 'rule_1', name: 'CA Spanish Leads', conditions: [{field: 'zipCode', operator: 'startsWith', value: '9'}, {field: 'language', operator: 'is', value: 'Spanish'}], actions: [{type: 'sendSMS', campaignId: 'CA-Spanish-Welcome'}, {type: 'addTag', value: 'Bilingual_Path'}] },
    { id: 'rule_2', name: 'Teacher Healthcare Offer', conditions: [{field: 'jobTitle', operator: 'contains', value: 'Teacher'}, {field: 'productNeed', operator: 'is', value: 'Healthcare'}], actions: [{type: 'offerBundle', bundleId: 'EducatorTelemedRX'}, {type: 'showLandingPage', pageId: 'Teacher_Benefits_LP'}] },
  ]);
  const [currentRule, setCurrentRule] = useState(null);

  const addRule = () => {
    const newRule = {...initialRule, id: `rule_${Date.now()}`};
    setRules(prev => [...prev, newRule]);
    setCurrentRule(newRule);
  };

  const updateRule = (ruleId, field, value, conditionIndex, actionIndex) => {
    setRules(prev => prev.map(r => {
      if (r.id === ruleId) {
        const updatedRule = { ...r };
        if (conditionIndex !== undefined) {
          updatedRule.conditions[conditionIndex][field] = value;
        } else if (actionIndex !== undefined) {
          updatedRule.actions[actionIndex][field] = value;
        } else {
          updatedRule[field] = value;
        }
        return updatedRule;
      }
      return r;
    }));
  };
  
  const addCondition = (ruleId) => {
    setRules(prev => prev.map(r => r.id === ruleId ? {...r, conditions: [...r.conditions, {field:'', operator:'', value:''}]} : r));
  };
  const removeCondition = (ruleId, index) => {
    setRules(prev => prev.map(r => r.id === ruleId ? {...r, conditions: r.conditions.filter((_, i) => i !== index)} : r));
  };
  const addAction = (ruleId) => {
    setRules(prev => prev.map(r => r.id === ruleId ? {...r, actions: [...r.actions, {type:'', value:''}]} : r));
  };
  const removeAction = (ruleId, index) => {
    setRules(prev => prev.map(r => r.id === ruleId ? {...r, actions: r.actions.filter((_, i) => i !== index)} : r));
  };


  const fieldOptions = [
    { value: 'zipCode', label: 'Zip Code' }, { value: 'jobTitle', label: 'Job Title' },
    { value: 'leadScore', label: 'Lead Score' }, { value: 'lastInteraction', label: 'Last Interaction Date' },
    { value: 'productInterest', label: 'Product Interest' }, { value: 'language', label: 'Language Preference' }
  ];
  const operatorOptions = [
    { value: 'is', label: 'Is' }, { value: 'isNot', label: 'Is Not' },
    { value: 'startsWith', label: 'Starts With' }, { value: 'endsWith', label: 'Ends With' },
    { value: 'contains', label: 'Contains' }, { value: 'greaterThan', label: 'Greater Than' },
    { value: 'lessThan', label: 'Less Than' }
  ];
  const actionTypeOptions = [
    { value: 'sendSMS', label: 'Send SMS Campaign' }, { value: 'sendEmail', label: 'Send Email Campaign' },
    { value: 'addTag', label: 'Add Tag' }, { value: 'removeTag', label: 'Remove Tag' },
    { value: 'updateScore', label: 'Update Lead Score' }, { value: 'showLandingPage', label: 'Show Landing Page Version' },
    { value: 'offerBundle', label: 'Offer Product Bundle'}
  ];

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Repeat className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Lead Lifecycle Manager
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Automate re-engagement, personalize journeys with logic trees, and optimize lead conversion.
          </p>
        </div>
      </motion.header>

      <Tabs value={activeMainTab} onValueChange={setActiveMainTab} className="w-full flex-grow flex flex-col">
        <TabsList className="grid w-full grid-cols-2 gap-1 shadcn-tabs-list mb-4 md:mb-5">
            <TabsTrigger value="resumeJourneys" className="shadcn-tabs-trigger"><PlayCircle size={14} className="mr-1.5"/>Resume Journeys & Landing Pages</TabsTrigger>
            <TabsTrigger value="logicTree" className="shadcn-tabs-trigger"><Network size={14} className="mr-1.5"/>Audience Logic Tree</TabsTrigger>
        </TabsList>
        
        <motion.div
            key={activeMainTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            className="flex-grow flex flex-col"
        >
            <TabsContent value="resumeJourneys" className="m-0 p-0 flex-grow">
                <motion.div variants={sectionVariants} initial="hidden" animate="visible" className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                    <motion.div variants={itemVariants}>
                        <Card className="frosty-glass p-0.5 h-full">
                            <CardHeader className="px-5 pt-5 pb-3">
                                <CardTitle className="text-lg font-semibold flex items-center gap-2"><Mail className="h-5 w-5 text-primary"/>Re-Engagement Automation</CardTitle>
                                <CardDescription className="text-sm">Configure automated messages to bring back dropped-off leads.</CardDescription>
                            </CardHeader>
                            <CardContent className="px-5 pb-5 space-y-4">
                                <div>
                                    <Label htmlFor="reEngagementMessage" className="text-xs font-medium">Re-Engagement Message (SMS/Email)</Label>
                                    <Textarea id="reEngagementMessage" defaultValue={`Hi {{FirstName}}, noticed you left? Click here to resume: [your-domain]/.resume?lead_id={{LeadID}}`} className="shadcn-input mt-1 min-h-[80px] text-xs" />
                                    <p className="text-[11px] text-muted-foreground mt-1">Use placeholders like `{"{{FirstName}}"}`, `{"{{LeadID}}"}`.</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Switch id="abTestToggle" />
                                    <Label htmlFor="abTestToggle" className="text-xs font-medium">Enable A/B Testing for Messages</Label>
                                </div>
                                <Button className="w-full shadcn-button"><Settings2 size={14} className="mr-2"/>Configure Re-Engagement Rules</Button>
                            </CardContent>
                        </Card>
                    </motion.div>
                    <motion.div variants={itemVariants}>
                        <Card className="frosty-glass p-0.5 h-full">
                            <CardHeader className="px-5 pt-5 pb-3">
                                <CardTitle className="text-lg font-semibold flex items-center gap-2"><FileText className="h-5 w-5 text-primary"/>Resume Landing Page Preview</CardTitle>
                                <CardDescription className="text-sm">Conceptual preview of the re-entry page.</CardDescription>
                            </CardHeader>
                            <CardContent className="px-5 pb-5 space-y-3">
                                <div className="p-4 border border-border/50 rounded-md bg-background/30">
                                    <h3 className="text-lg font-semibold text-center mb-1">Welcome back, Alex!</h3>
                                    <p className="text-xs text-muted-foreground text-center mb-3">Let's finish signing up in just 2 minutes.</p>
                                    <div className="space-y-2 mb-3">
                                        <Input defaultValue="Alex Johnson" className="shadcn-input text-xs h-8" readOnly/>
                                        <Input defaultValue="alex.j@example.com" className="shadcn-input text-xs h-8" readOnly/>
                                    </div>
                                    <Button className="w-full shadcn-button h-8 text-xs">Resume My Application</Button>
                                </div>
                                <p className="text-xs font-medium text-muted-foreground text-center mt-2 mb-1">Animated Product Highlights (Mock):</p>
                                <div className="grid grid-cols-3 gap-2">
                                    {mockProductHighlights.slice(0,3).map(p => (
                                        <motion.div key={p.id} className="text-center bg-muted/20 p-2 rounded" whileHover={{scale:1.05}}>
                                            <img  alt={p.name} className="w-10 h-10 mx-auto mb-1 rounded opacity-70" src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                                            <p className="text-[10px] font-medium truncate">{p.name}</p>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                </motion.div>
            </TabsContent>

            <TabsContent value="logicTree" className="m-0 p-0 flex-grow">
                <motion.div variants={sectionVariants} initial="hidden" animate="visible" className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                    <motion.div variants={itemVariants} className="lg:col-span-1">
                         <Card className="frosty-glass p-0.5 h-full">
                            <CardHeader className="px-4 pt-4 pb-2 flex flex-row justify-between items-center">
                                <CardTitle className="text-base font-semibold flex items-center gap-1.5"><Network className="h-4 w-4 text-primary"/>Logic Rules ({rules.length})</CardTitle>
                                <Button size="xs" variant="outline" onClick={addRule} className="shadcn-button text-[11px] px-2 py-1 h-auto"><PlusCircle size={12} className="mr-1"/>Add Rule</Button>
                            </CardHeader>
                            <CardContent className="px-4 pb-4 space-y-2 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
                                {rules.map(rule => (
                                    <div key={rule.id} onClick={() => setCurrentRule(rule)} className={`p-2 rounded border cursor-pointer text-xs ${currentRule?.id === rule.id ? 'frosty-glass ring-1 ring-primary bg-primary/5' : 'bg-muted/30 hover:bg-muted/50'}`}>
                                        <div className="flex justify-between items-center">
                                            <span className="font-medium">{rule.name}</span>
                                            <Button variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-destructive" onClick={(e) => {e.stopPropagation(); setRules(prev => prev.filter(r => r.id !== rule.id)); if(currentRule?.id === rule.id) setCurrentRule(null);}}>
                                                <Trash2 size={10}/>
                                            </Button>
                                        </div>
                                        <p className="text-[10px] text-muted-foreground">{rule.conditions.length} condition(s), {rule.actions.length} action(s)</p>
                                    </div>
                                ))}
                                {rules.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">No rules defined yet.</p>}
                            </CardContent>
                        </Card>
                    </motion.div>
                    <motion.div variants={itemVariants} className="lg:col-span-2">
                        {currentRule ? (
                            <Card className="frosty-glass p-0.5 h-full">
                                <CardHeader className="px-5 pt-5 pb-3">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <Edit3 className="h-5 w-5 text-primary"/>
                                        <Input value={currentRule.name} onChange={(e) => updateRule(currentRule.id, 'name', e.target.value)} className="shadcn-input text-lg font-semibold p-1 h-auto border-0 focus-visible:ring-0 bg-transparent"/>
                                      </div>
                                      <Button size="sm" className="shadcn-button">Save Rule</Button>
                                    </div>
                                </CardHeader>
                                <CardContent className="px-5 pb-5 space-y-4 max-h-[calc(100vh-320px)] overflow-y-auto scrollbar-hide">
                                    <div>
                                        <Label className="text-xs font-medium mb-1 block">Conditions (ALL must be met):</Label>
                                        {currentRule.conditions.map((cond, index) => (
                                          <div key={index} className="grid grid-cols-[1fr_1fr_1fr_auto] gap-1.5 items-center mb-1.5 p-2 bg-muted/20 rounded">
                                            <Select value={cond.field} onValueChange={(val) => updateRule(currentRule.id, 'field', val, index)}>
                                              <SelectTrigger className="shadcn-input text-xs h-7"><SelectValue placeholder="Field"/></SelectTrigger>
                                              <SelectContent className="shadcn-select-content text-xs">{fieldOptions.map(opt => <SelectItem key={opt.value} value={opt.value} className="shadcn-select-item text-xs">{opt.label}</SelectItem>)}</SelectContent>
                                            </Select>
                                            <Select value={cond.operator} onValueChange={(val) => updateRule(currentRule.id, 'operator', val, index)}>
                                              <SelectTrigger className="shadcn-input text-xs h-7"><SelectValue placeholder="Operator"/></SelectTrigger>
                                              <SelectContent className="shadcn-select-content text-xs">{operatorOptions.map(opt => <SelectItem key={opt.value} value={opt.value} className="shadcn-select-item text-xs">{opt.label}</SelectItem>)}</SelectContent>
                                            </Select>
                                            <Input value={cond.value} onChange={(e) => updateRule(currentRule.id, 'value', e.target.value, index)} placeholder="Value" className="shadcn-input text-xs h-7"/>
                                            <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={() => removeCondition(currentRule.id, index)}><Trash2 size={10}/></Button>
                                          </div>
                                        ))}
                                        <Button variant="outline" size="xs" onClick={() => addCondition(currentRule.id)} className="shadcn-button text-[11px] px-2 py-1 h-auto mt-1"><PlusCircle size={12} className="mr-1"/>Add Condition</Button>
                                    </div>
                                    <div>
                                        <Label className="text-xs font-medium mb-1 block">Actions (Perform ALL):</Label>
                                        {currentRule.actions.map((act, index) => (
                                          <div key={index} className="grid grid-cols-[1fr_1fr_auto] gap-1.5 items-center mb-1.5 p-2 bg-muted/20 rounded">
                                            <Select value={act.type} onValueChange={(val) => updateRule(currentRule.id, 'type', val, undefined, index)}>
                                              <SelectTrigger className="shadcn-input text-xs h-7"><SelectValue placeholder="Action Type"/></SelectTrigger>
                                              <SelectContent className="shadcn-select-content text-xs">{actionTypeOptions.map(opt => <SelectItem key={opt.value} value={opt.value} className="shadcn-select-item text-xs">{opt.label}</SelectItem>)}</SelectContent>
                                            </Select>
                                            <Input value={act.value || act.campaignId || act.bundleId || act.pageId} onChange={(e) => updateRule(currentRule.id, Object.keys(act)[1] || 'value', e.target.value, undefined, index)} placeholder="Parameter (e.g., Campaign ID, Tag Name)" className="shadcn-input text-xs h-7"/>
                                            <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={() => removeAction(currentRule.id, index)}><Trash2 size={10}/></Button>
                                          </div>
                                        ))}
                                        <Button variant="outline" size="xs" onClick={() => addAction(currentRule.id)} className="shadcn-button text-[11px] px-2 py-1 h-auto mt-1"><PlusCircle size={12} className="mr-1"/>Add Action</Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ) : (
                            <div className="h-full flex flex-col items-center justify-center text-center border-2 border-dashed border-border/30 rounded-lg p-6 frosty-glass">
                                <Network className="h-14 w-14 text-muted-foreground opacity-30 mb-3"/>
                                <p className="text-base font-medium text-foreground">Select a rule to edit or create a new one.</p>
                                <p className="text-xs text-muted-foreground/80 mt-1">Define conditional logic to personalize lead journeys.</p>
                                <Button onClick={addRule} className="shadcn-button mt-4 text-xs"><PlusCircle size={14} className="mr-1.5"/>Create First Rule</Button>
                            </div>
                        )}
                    </motion.div>
                </motion.div>
            </TabsContent>
        </motion.div>
      </Tabs>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={3} 
        className="mt-auto pt-4 md:pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Advanced Automation Module</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                The Lead Lifecycle Manager provides a conceptual framework for sophisticated lead engagement strategies. Full implementation involves dynamic landing page generation, robust A/B testing infrastructure, and deep integration with CRM/CDP systems for behavior scoring and real-time data synchronization.
            </p>
        </div>
      </motion.div>
    </div>
  );
}
