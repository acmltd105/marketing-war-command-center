import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { UploadCloud, FileText, Trash2, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.97 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.05,
      duration: 0.4,
      ease: [0.2, 0.8, 0.2, 1]
    }
  }),
  exit: { opacity: 0, y: -10, scale: 0.98, transition: { duration: 0.2 } }
};

const FileUploadManager = ({standaloneView = false}) => {
  const [files, setFiles] = useState([]);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (event) => {
    const newFiles = Array.from(event.target.files);
    processFiles(newFiles);
  };

  const handleDrop = useCallback((event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
    const droppedFiles = Array.from(event.dataTransfer.files);
    processFiles(droppedFiles);
  }, []);

  const processFiles = (newFiles) => {
    const processed = newFiles.map(file => ({
      id: `${file.name}-${Date.now()}`,
      name: file.name,
      size: file.size,
      type: file.type,
      status: 'pending', 
      progress: 0,
      fileObject: file, 
    }));
    setFiles(prev => [...prev, ...processed]);
    toast({ title: `${processed.length} file(s) added to queue.`, description: "Ready for upload." });
  };

  const handleDragOver = useCallback((event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
  }, []);

  const removeFile = (fileId) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
    toast({ title: "File removed from queue.", variant: "default" });
  };

  const simulateUpload = (fileId) => {
    setFiles(prev => prev.map(f => f.id === fileId ? { ...f, status: 'uploading', progress: 0 } : f));
    
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 15 + 5; 
      if (progress >= 100) {
        clearInterval(interval);
        setFiles(prev => {
            const updatedFiles = prev.map(f => {
                if (f.id === fileId) {
                    const newStatus = Math.random() > 0.2 ? 'success' : 'error';
                    toast({ 
                        title: `Upload ${newStatus === 'success' ? 'Successful' : 'Failed'}`, 
                        description: `${f.name} ${newStatus === 'success' ? 'uploaded.' : 'failed to upload.'}`,
                        variant: newStatus === 'success' ? 'default' : 'destructive'
                    });
                    return { ...f, status: newStatus, progress: 100 };
                }
                return f;
            });
            return updatedFiles;
        });
      } else {
        setFiles(prev => prev.map(f => f.id === fileId ? { ...f, progress: Math.min(progress, 100) } : f));
      }
    }, 200);
  };

  const uploadAllFiles = () => {
    const pendingFiles = files.filter(f => f.status === 'pending');
    if (pendingFiles.length === 0) {
        toast({title: "No pending files", description: "All files are already processed or uploading."});
        return;
    }
    pendingFiles.forEach(f => simulateUpload(f.id));
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  const mainContent = (
    <>
        <motion.div
            variants={cardVariants} initial="hidden" animate="visible" custom={0}
            className={`file-upload-area ${isDragging ? 'is-drag-active' : ''} ${standaloneView ? 'border-2 border-dashed' : 'border'}`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
        >
            <input
            type="file"
            multiple
            onChange={handleFileChange}
            className="hidden"
            id={`file-upload-input-${standaloneView ? 'standalone' : 'embedded'}`}
            />
            <label htmlFor={`file-upload-input-${standaloneView ? 'standalone' : 'embedded'}`} className="cursor-pointer p-3 block text-center">
            <UploadCloud className="upload-icon h-8 w-8 md:h-10 md:w-10 mx-auto" />
            <h3 className="text-sm md:text-base font-semibold text-foreground mt-1.5">Drag & drop CSV files here</h3>
            <p className="mt-0.5 text-xs">or click to browse</p>
            <p className="text-[10px] mt-1 text-muted-foreground/80">Max 10MB per file (simulated)</p>
            </label>
        </motion.div>

        {files.length > 0 && (
            <motion.div variants={cardVariants} initial="hidden" animate="visible" custom={1} className="mt-3">
            <Card className="frosty-glass p-0.5 shadow-none border-border/50">
                <CardHeader className="px-3 pt-3 pb-2">
                <div className="flex justify-between items-center">
                    <CardTitle className="text-sm font-semibold text-foreground">Upload Queue ({files.length})</CardTitle>
                    <Button onClick={uploadAllFiles} size="xs" className="shadcn-button h-6 text-[10px]" disabled={files.every(f => f.status !== 'pending')}>
                    <UploadCloud className="h-3 w-3 mr-1" /> Upload All
                    </Button>
                </div>
                </CardHeader>
                <CardContent className="px-3 pb-3 space-y-2 max-h-[200px] overflow-y-auto scrollbar-thin">
                <AnimatePresence>
                    {files.map((file, index) => (
                    <motion.div
                        key={file.id}
                        layout
                        variants={cardVariants}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                        custom={index}
                        className="p-2 rounded border border-border/40 bg-background/20 flex items-center gap-2"
                    >
                        <FileText className="h-4 w-4 text-primary opacity-70 shrink-0" />
                        <div className="flex-grow overflow-hidden min-w-0">
                        <p className="text-[11px] font-medium text-foreground truncate" title={file.name}>{file.name}</p>
                        <p className="text-[9px] text-muted-foreground">{formatFileSize(file.size)}</p>
                        {file.status === 'uploading' && <Progress value={file.progress} className="h-0.5 mt-0.5 bg-muted/40" indicatorClassName="bg-primary" />}
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                        {file.status === 'pending' && (
                            <Button size="icon" variant="ghost" className="h-5 w-5 group" onClick={() => simulateUpload(file.id)}>
                                <UploadCloud className="h-3 w-3 text-muted-foreground group-hover:text-primary" />
                            </Button>
                        )}
                        {file.status === 'uploading' && <Loader2 className="h-3 w-3 text-primary animate-spin" />}
                        {file.status === 'success' && <CheckCircle className="h-3 w-3 text-green-600" />}
                        {file.status === 'error' && <AlertCircle className="h-3 w-3 text-red-600" />}
                        <Button size="icon" variant="ghost" className="h-5 w-5 hover:bg-destructive/10 group" onClick={() => removeFile(file.id)}>
                            <Trash2 className="h-3 w-3 text-muted-foreground group-hover:text-destructive" />
                        </Button>
                        </div>
                    </motion.div>
                    ))}
                </AnimatePresence>
                </CardContent>
            </Card>
            </motion.div>
        )}
        {files.length === 0 && (
            <motion.p 
                initial={{opacity: 0}} animate={{opacity:1}}
                className="text-center text-[10px] text-muted-foreground py-1.5"
            >
                No files selected for lead import.
            </motion.p>
        )}
    </>
  );


  if (standaloneView) {
    return (
      <div className="space-y-6 md:space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "circOut" }}
        >
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground tracking-tight">File Upload Manager</h2>
          <p className="text-base md:text-lg text-muted-foreground mt-1">Upload documents, contact lists, or other assets.</p>
        </motion.div>
        {mainContent}
      </div>
    );
  }

  return mainContent;
};

export { FileUploadManager };