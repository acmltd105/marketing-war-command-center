
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wand2, TestTube as TestTubeDiagonal, Newspaper, CalendarDays, TrendingUp, MessageCircle as MessageCircleHeart, Sparkles, Brain, Music, LayoutTemplate, Settings2, Link as LinkIcon, AlertTriangle, Edit3, PlusCircle, BarChartHorizontal, Filter, Check, Percent, Shuffle, FileText, Palette, GitBranch, Clock, ExternalLink, Activity, Trash2, CalendarClock } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const featureTabs = [
  { id: "audio_sms", name: "Audio-in-SMS", icon: Music, description: "Embed branded music/sounds in messages." },
  { id: "dynamic_lp", name: "Dynamic Landing Pages", icon: LayoutTemplate, description: "Auto-build personalized LPs per lead." },
  { id: "ab_testing", name: "A/B/C/Z Testing", icon: TestTubeDiagonal, description: "Test every variable for campaign optimization." },
  { id: "product_drops", name: "Product Drop Campaigns", icon: Newspaper, description: "Manage new product release campaigns." },
  { id: "real_time_offers", name: "Real-Time Offer Upgrades", icon: TrendingUp, description: "Instantly upgrade offers based on interaction." },
  { id: "nlp_input", name: "Natural Language Input", icon: Brain, description: "Parse and respond to lead queries like a rep." },
];

export function AdvancedFeaturesHub() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState(featureTabs[0].id);
  
  const [abTestName, setAbTestName] = useState("Q4 Email Subject Test");
  const [testVariables, setTestVariables] = useState({
    smsLength: true,
    image: false,
    ctaStyle: true,
    emojiUse: true,
    followUpTiming: false
  });
  const [variants, setVariants] = useState([
    { id: 'A', name: 'Subject A: "Huge Savings Inside!"', traffic: 50, conversions: 120, impressions: 1000 },
    { id: 'B', name: 'Subject B: "Your Discount Is Waiting..."', traffic: 50, conversions: 150, impressions: 1000 }
  ]);
  const [confidenceLevel, setConfidenceLevel] = useState(95);


  const handleAddVariant = () => {
    const newVariantId = String.fromCharCode(65 + variants.length);
    setVariants([...variants, { id: newVariantId, name: `Variant ${newVariantId} Content`, traffic: 0, conversions: 0, impressions: 0 }]);
    const newTraffic = Math.floor(100 / (variants.length + 1));
    setVariants(prev => prev.map((v, i) => ({...v, traffic: i === prev.length -1 ? 100 - (newTraffic * (prev.length -1)) : newTraffic })));
  };
  
  const handleVariantChange = (index, field, value) => {
    setVariants(prev => prev.map((v, i) => i === index ? {...v, [field]: value} : v));
  };


  const getWinner = () => {
    if (variants.length === 0) return null;
    if (variants.some(v => v.impressions === 0)) return null;
    return variants.reduce((prev, current) => ((current.conversions / current.impressions) > (prev.conversions / prev.impressions) ? current : prev));
  };
  const winner = getWinner();

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Wand2 className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Advanced Features & Experimentation Hub
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Explore conceptual "luxury modules" for next-level campaign intelligence and automation.
          </p>
        </div>
      </motion.header>

    <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-grow flex flex-col">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1 p-1 rounded-lg shadcn-tabs-list mb-4 md:mb-5">
            {featureTabs.map(tab => (
            <TabsTrigger key={tab.id} value={tab.id} className="py-2 text-xs sm:text-sm font-medium shadcn-tabs-trigger">
                <tab.icon className="w-3.5 h-3.5 mr-1.5 opacity-75" />
                {tab.name}
            </TabsTrigger>
            ))}
        </TabsList>

        <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="flex-grow"
        >
            <TabsContent value="audio_sms" className="h-full mt-0">
                <Card className="frosty-glass p-0.5 h-full flex flex-col">
                    <CardHeader><CardTitle className="flex items-center gap-2"><Music size={20}/>Audio-in-SMS (MMS/RCS)</CardTitle><CardDescription>Sends branded music clips or sound effects tied to promotions. E.g., drumroll before announcing a winner.</CardDescription></CardHeader>
                    <CardContent className="space-y-4 flex-grow">
                        <Select>
                            <SelectTrigger className="shadcn-input"><SelectValue placeholder="Select Sound Effect (Mock)" /></SelectTrigger>
                            <SelectContent className="shadcn-select-content">
                                <SelectItem value="drumroll" className="shadcn-select-item">Drumroll</SelectItem>
                                <SelectItem value="success_chime" className="shadcn-select-item">Success Chime</SelectItem>
                                <SelectItem value="cash_register" className="shadcn-select-item">Cash Register Ka-ching</SelectItem>
                            </SelectContent>
                        </Select>
                        <Input className="shadcn-input" placeholder="Or enter URL for branded music clip (mock)" />
                        <Button className="w-full shadcn-button" onClick={() => toast({title: "Conceptual Link", description: "Navigating to Animated Message Builder to compose full message with audio."})}>
                            <Palette size={16} className="mr-2"/> Go to Message Crafting
                        </Button>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="dynamic_lp" className="h-full mt-0">
                <Card className="frosty-glass p-0.5 h-full flex flex-col">
                    <CardHeader><CardTitle className="flex items-center gap-2"><LayoutTemplate size={20}/>Dynamic Landing Page Generator</CardTitle><CardDescription>Auto-builds pages from CRM data + campaign goals. Tailored URL per lead.</CardDescription></CardHeader>
                    <CardContent className="space-y-4 flex-grow">
                        <Select><SelectTrigger className="shadcn-input"><SelectValue placeholder="Connect CRM Data Source (Mock)" /></SelectTrigger></Select>
                        <Input className="shadcn-input" placeholder="Campaign Goal (e.g., Lead Capture)" />
                        <p className="text-xs text-muted-foreground">Conceptual Tailored URL: <code>yourdomain.com/lp/{"{{LeadID}}"}</code></p>
                        <Button className="w-full shadcn-button" onClick={() => toast({title: "Conceptual Link", description: "Navigating to Lead Resume Engine for similar setup concepts."})}>
                            <ExternalLink size={16} className="mr-2"/> View Lead Resume Engine
                        </Button>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="ab_testing" className="h-full mt-0">
                <Card className="frosty-glass p-0.5 h-full flex flex-col">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><TestTubeDiagonal size={20}/>A/B/C/Z Testing Engine</CardTitle>
                        <CardDescription>Auto-tests every variable—SMS length, image, CTA style, emoji use, agent follow-up timing.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4 flex-grow overflow-y-auto scrollbar-hide">
                        <div><Label className="text-xs">Test Name</Label><Input className="shadcn-input mt-1" value={abTestName} onChange={e => setAbTestName(e.target.value)} /></div>
                        <div>
                            <Label className="text-xs">Variables to Test (Mock)</Label>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2 mt-1 text-xs">
                                {Object.entries(testVariables).map(([key, value]) => (
                                    <div key={key} className="flex items-center space-x-2">
                                        <Checkbox id={`var-${key}`} checked={value} onCheckedChange={checked => setTestVariables(p => ({...p, [key]: checked}))} />
                                        <Label htmlFor={`var-${key}`} className="font-normal">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</Label>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="flex justify-between items-center">
                            <Label className="text-xs">Test Variants</Label>
                            <Button size="xs" variant="outline" onClick={handleAddVariant} className="shadcn-button"><PlusCircle size={12} className="mr-1"/>Add Variant</Button>
                        </div>
                        <div className="space-y-2 max-h-[150px] overflow-y-auto scrollbar-thin pr-1">
                            {variants.map((variant, index) => (
                            <Card key={variant.id} className="p-2 bg-muted/30">
                                <div className="flex items-center justify-between mb-1">
                                    <Input value={variant.name} onChange={e => handleVariantChange(index, 'name', e.target.value)} className="shadcn-input text-xs h-7 flex-grow mr-2" placeholder={`Variant ${variant.id} Content`}/>
                                    <Button size="icon" variant="ghost" className="h-6 w-6 text-destructive/70 hover:text-destructive" onClick={() => setVariants(v => v.filter(i => i.id !== variant.id))}><Trash2 size={12}/></Button>
                                </div>
                                <div className="grid grid-cols-3 gap-1 text-xs">
                                    <div><Label className="text-[10px]">Traffic %</Label><Input type="number" value={variant.traffic} onChange={e => handleVariantChange(index, 'traffic', parseInt(e.target.value))} className="shadcn-input h-6 text-[10px]"/></div>
                                    <div><Label className="text-[10px]">Impr.</Label><Input type="number" value={variant.impressions} onChange={e => handleVariantChange(index, 'impressions', parseInt(e.target.value))} className="shadcn-input h-6 text-[10px]"/></div>
                                    <div><Label className="text-[10px]">Conv.</Label><Input type="number" value={variant.conversions} onChange={e => handleVariantChange(index, 'conversions', parseInt(e.target.value))} className="shadcn-input h-6 text-[10px]"/></div>
                                </div>
                                <p className="text-[10px] text-muted-foreground mt-1">Conv. Rate: {variant.impressions > 0 ? ((variant.conversions / variant.impressions) * 100).toFixed(2) : '0.00'}%</p>
                            </Card>
                            ))}
                        </div>
                         {winner && <p className="text-xs text-green-600"><Check size={14} className="inline mr-1"/>Winner: Variant {winner.id} ({(winner.conversions / winner.impressions * 100).toFixed(2)}% CR)</p>}
                         <div><Label className="text-xs">Confidence Level</Label><Input type="number" value={confidenceLevel} onChange={e => setConfidenceLevel(parseInt(e.target.value))} className="shadcn-input mt-1 text-sm" placeholder="e.g., 95"/></div>
                         <Button className="w-full shadcn-button" onClick={() => toast({title: "Test Started (Mock)", description: "A/B/C/Z test is now running conceptually."})}><Activity size={16} className="mr-2"/>Start Test (Mock)</Button>
                    </CardContent>
                </Card>
            </TabsContent>
            
            <TabsContent value="product_drops" className="h-full mt-0">
                <Card className="frosty-glass p-0.5 h-full flex flex-col">
                    <CardHeader><CardTitle className="flex items-center gap-2"><Newspaper size={20}/>Product Drop Campaigns</CardTitle><CardDescription>“New PetPlan Released Today” with animation, FAQ, and auto-scheduler.</CardDescription></CardHeader>
                    <CardContent className="space-y-4 flex-grow">
                        <Input className="shadcn-input" placeholder="Product Name (e.g., PetPlan Deluxe)" />
                        <Input type="date" className="shadcn-input" />
                        <Textarea className="shadcn-input" placeholder="FAQ Content (mock)" />
                        <div className="flex items-center space-x-2"><Switch id="auto-scheduler"/><Label htmlFor="auto-scheduler">Auto-Scheduler Enabled</Label></div>
                        <Button className="w-full shadcn-button" onClick={() => toast({title: "Conceptual Link", description: "Navigating to Offer Calendar/Timed Campaigns for scheduling."})}>
                            <CalendarClock size={16} className="mr-2"/> View Offer Calendar
                        </Button>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="real_time_offers" className="h-full mt-0">
                 <Card className="frosty-glass p-0.5 h-full flex flex-col">
                    <CardHeader><CardTitle className="flex items-center gap-2"><TrendingUp size={20}/>Real-Time Offer Upgrades</CardTitle><CardDescription>Lead interacts → upsell logic triggers better deal instantly.</CardDescription></CardHeader>
                    <CardContent className="space-y-4 flex-grow">
                        <p className="text-sm text-muted-foreground">IF Lead interacts with <Input className="shadcn-input inline-block w-auto mx-1 h-8 text-xs" placeholder="[Offer A]"/> AND Score &gt; <Input type="number" className="shadcn-input inline-block w-20 mx-1 h-8 text-xs" placeholder="[75]"/> THEN Trigger <Input className="shadcn-input inline-block w-auto mx-1 h-8 text-xs" placeholder="[Upsell Offer B]"/>.</p>
                        <Button className="w-full shadcn-button" onClick={() => toast({title: "Logic Saved (Mock)", description: "Real-time offer upgrade rule configured."})}><Shuffle size={16} className="mr-2"/>Save Upsell Logic (Mock)</Button>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="nlp_input" className="h-full mt-0">
                <Card className="frosty-glass p-0.5 h-full flex flex-col">
                    <CardHeader><CardTitle className="flex items-center gap-2"><Brain size={20}/>Natural-Language Lead Input</CardTitle><CardDescription>“Text me the cheapest plan” → system parses and responds like a rep.</CardDescription></CardHeader>
                    <CardContent className="space-y-4 flex-grow">
                        <Textarea className="shadcn-input" placeholder="Lead texts: 'Text me the cheapest plan for my dog.'" />
                        <Button className="w-full shadcn-button" onClick={() => toast({title: "Parsed Intent (Mock)", description: "Request for 'quote_pet_insurance_basic'. Response: 'Our Basic PetPlan is $25/mo...'"})}>Parse & Respond (Mock)</Button>
                        <Button className="w-full shadcn-button" variant="outline" onClick={() => toast({title: "Conceptual Link", description: "Navigating to Bot Army Builder for NLP configurations."})}>
                           <GitBranch size={16} className="mr-2"/> Go to Bot Army Builder
                        </Button>
                    </CardContent>
                </Card>
            </TabsContent>
        </motion.div>
      </Tabs>

      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Conceptual Modules</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                The features in this hub are conceptual mockups. Full implementation requires significant backend development, AI model integration, and connections to relevant data sources and messaging platforms.
            </p>
        </div>
      </motion.div>
    </div>
  );
}
