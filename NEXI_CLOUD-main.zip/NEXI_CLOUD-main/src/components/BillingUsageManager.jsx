
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAppContext } from '@/contexts/AppContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, Legend } from 'recharts';
import { CreditCard, DollarSign, Zap, ShieldCheck, History, Loader2, AlertCircle, TrendingUp, Download, PlusCircle } from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100 } }
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="frosty-glass p-2 border border-border rounded-md shadow-lg">
        <p className="label text-sm text-foreground">{`${label}`}</p>
        <p className="intro text-xs text-primary">{`Spend : $${payload[0].value.toFixed(2)}`}</p>
      </div>
    );
  }
  return null;
};

export function BillingUsageManager() {
  const [loading, setLoading] = useState(true);
  const [billingData, setBillingData] = useState(null);
  const [localSettings, setLocalSettings] = useState(null);
  const { withSavingState } = useAppContext();
  const { toast } = useToast();

  const fetchBillingData = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('twilio-usage-proxy', {
        body: { action: 'get_billing_data' },
      });
      if (error || !data.success) throw new Error(error?.message || data.error);
      setBillingData(data.data);
      setLocalSettings(data.data.settings);
    } catch (err) {
      toast({ title: 'Failed to load billing data', description: err.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchBillingData();
  }, [fetchBillingData]);

  const handleSettingsChange = (key, value) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveSettings = async () => {
    await withSavingState(async () => {
      try {
        const { error } = await supabase.functions.invoke('twilio-usage-proxy', {
          body: { action: 'update_billing_settings', payload: localSettings },
        });
        if (error) throw error;
        toast({ title: 'Settings Saved', description: 'Your billing controls have been updated.', variant: 'success' });
        fetchBillingData(); 
      } catch (err) {
        toast({ title: 'Save Failed', description: err.message, variant: 'destructive' });
      }
    });
  };

  if (loading) {
    return <div className="h-full flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  if (!billingData || !localSettings) {
    return <div className="h-full flex items-center justify-center"><AlertCircle className="h-8 w-8 text-destructive" /><p className="ml-2">Could not load billing information.</p></div>;
  }

  const { settings, usage } = billingData;
  const spendPercentage = (usage.spendMonthToDate / settings.spending_limit_amount) * 100;

  return (
    <motion.div
      className="p-4 sm:p-6 md:p-8 h-full overflow-y-auto space-y-8"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants} className="flex items-center justify-start">
        <CreditCard className="h-8 w-8 md:h-9 md:w-9 text-primary mr-2.5 md:mr-3 opacity-85" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Billing & Usage</h1>
          <p className="text-muted-foreground mt-1">Monitor your real-time usage, manage spending, and view history.</p>
        </div>
      </motion.div>

      <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="frosty-glass md:col-span-2">
          <CardHeader>
            <CardTitle>Current Billing Cycle</CardTitle>
            <CardDescription>Month-to-date summary. Resets on the 1st.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Current Balance</p>
                <p className="text-3xl font-bold text-green-500">${settings.current_balance.toFixed(2)}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Month-to-Date Spend</p>
                <p className="text-3xl font-bold text-foreground">${usage.spendMonthToDate.toFixed(2)}</p>
              </div>
            </div>
            {settings.spending_limit_enabled && (
              <div className="mt-6">
                <div className="flex justify-between items-baseline mb-1">
                  <Label>Monthly Spending Limit</Label>
                  <span className="text-sm font-medium text-muted-foreground">${usage.spendMonthToDate.toFixed(2)} / <span className="text-foreground">${settings.spending_limit_amount.toFixed(2)}</span></span>
                </div>
                <Progress value={spendPercentage} className="h-3" indicatorClassName={spendPercentage > 85 ? 'bg-destructive' : spendPercentage > 60 ? 'bg-yellow-500' : 'bg-primary'} />
              </div>
            )}
          </CardContent>
        </Card>
        <Card className="frosty-glass flex flex-col justify-center">
            <CardHeader className="pb-4">
                <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
                <Button className="w-full shadcn-button"><PlusCircle className="mr-2 h-4 w-4"/> Add Funds Manually</Button>
                <Button variant="outline" className="w-full"><Download className="mr-2 h-4 w-4"/> Download Invoice</Button>
            </CardContent>
        </Card>
      </motion.div>
      
      <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="frosty-glass">
            <CardHeader>
                <CardTitle>Daily Spend (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={usage.dailySpendHistory} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border) / 0.5)" />
                        <XAxis dataKey="date" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                        <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsl(var(--primary) / 0.1)' }} />
                        <Line type="monotone" dataKey="spend" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
        <Card className="frosty-glass">
            <CardHeader>
                <CardTitle>Spend by Service (MTD)</CardTitle>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                   <PieChart>
                      <Pie data={usage.usageByService} dataKey="spend" nameKey="name" cx="50%" cy="50%" outerRadius={80} labelLine={false} label={({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
                        const radius = innerRadius + (outerRadius - innerRadius) * 1.2;
                        const x = cx + radius * Math.cos(-midAngle * Math.PI / 180);
                        const y = cy + radius * Math.sin(-midAngle * Math.PI / 180);
                        return percent > 0.05 ? <text x={x} y={y} fill="currentColor" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" className="text-xs fill-foreground">{(percent * 100).toFixed(0)}%</text> : null;
                      }}>
                        {usage.usageByService.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                      </Pie>
                      <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
                      <Legend iconSize={10} wrapperStyle={{fontSize: "12px"}}/>
                    </PieChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="frosty-glass">
          <CardHeader>
            <CardTitle>Billing Controls</CardTitle>
            <CardDescription>Manage automated billing actions and spending limits.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="flex items-start justify-between">
              <div>
                <Label htmlFor="autoRefillEnabled" className="font-semibold">Auto-Refill</Label>
                <p className="text-sm text-muted-foreground">Automatically add funds when balance drops below a threshold.</p>
              </div>
              <Switch id="autoRefillEnabled" checked={localSettings.auto_refill_enabled} onCheckedChange={(c) => handleSettingsChange('auto_refill_enabled', c)} />
            </div>
            <AnimatePresence>
              {localSettings.auto_refill_enabled && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="pl-4 space-y-4">
                  <div className="space-y-2">
                    <Label>Refill when balance is below:</Label>
                    <div className="flex items-center gap-4">
                      <Slider value={[localSettings.auto_refill_threshold]} onValueChange={([v]) => handleSettingsChange('auto_refill_threshold', v)} max={50} step={5} className="w-64" />
                      <span className="font-mono text-lg text-foreground">${localSettings.auto_refill_threshold.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Amount to add:</Label>
                    <Input type="number" value={localSettings.auto_refill_amount} onChange={(e) => handleSettingsChange('auto_refill_amount', parseFloat(e.target.value))} className="w-40" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            
            <div className="flex items-start justify-between">
              <div>
                <Label htmlFor="spendingLimitEnabled" className="font-semibold">Monthly Spend Limit</Label>
                <p className="text-sm text-muted-foreground">Suspend usage when spend exceeds this limit in a billing cycle.</p>
              </div>
              <Switch id="spendingLimitEnabled" checked={localSettings.spending_limit_enabled} onCheckedChange={(c) => handleSettingsChange('spending_limit_enabled', c)} />
            </div>
             <AnimatePresence>
              {localSettings.spending_limit_enabled && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="pl-4 space-y-4">
                  <div className="space-y-2">
                    <Label>Monthly Limit Amount:</Label>
                    <div className="flex items-center gap-4">
                      <Slider value={[localSettings.spending_limit_amount]} onValueChange={([v]) => handleSettingsChange('spending_limit_amount', v)} max={5000} step={100} className="w-64" />
                      <span className="font-mono text-lg text-foreground">${localSettings.spending_limit_amount.toFixed(2)}</span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            <div className="flex justify-end">
              <Button onClick={handleSaveSettings}><ShieldCheck className="mr-2 h-4 w-4"/>Save Controls</Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="frosty-glass">
            <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>A history of your recent payments and invoices.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="border rounded-lg overflow-hidden">
                    <div className="divide-y divide-border">
                        {usage.transactionHistory.map(tx => (
                            <div key={tx.id} className="grid grid-cols-4 items-center p-3 text-sm">
                                <span className="text-muted-foreground">{tx.date}</span>
                                <span className="font-medium text-foreground">{tx.type}</span>
                                <span className={`font-mono ${tx.amount > 0 ? 'text-green-500' : 'text-foreground'}`}>{tx.amount > 0 ? '+' : ''}${tx.amount.toFixed(2)}</span>
                                <span className="text-right"><Button variant="ghost" size="sm">Details</Button></span>
                            </div>
                        ))}
                    </div>
                </div>
            </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
