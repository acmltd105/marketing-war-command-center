import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
    Zap, Users, Route, BarChart2, Brain, MessageSquare, UserCheck, AlertTriangle, 
    ListChecks, UploadCloud, Filter, Send, TrendingUp, BrainCircuit, ListFilter, CheckSquare,
    Wand2, Edit, RefreshCw,ThumbsUp, ThumbsDown
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { FileUploadManager } from '@/components/FileUploadManager';
import { useChatGPT } from '@/hooks/useChatGPT'; 
import { useToast } from '@/components/ui/use-toast';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.07, delayChildren: i * 0.07, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const mockLearningLog = [
  "Optimized SMS send time for 'Early Bird Tech Adopters' to 8:15 AM local based on 'Paws for Teachers' campaign results.",
  "Increased bid for 'High-Value Insurance Leads' on LinkedIn source by 10%.",
  "A/B Test 'Benefit-Driven vs. Urgency CTA' for Email Campaign #102: Variant A winning (12% higher CTR).",
  "Paused automated follow-up for leads scoring below 35 after initial contact.",
  "Switched primary channel from Email to RCS for 'Gen Z Fashion Segment' due to higher open rates.",
  "Identified 'Product Demo Request' as a key conversion intent; routing directly to sales queue.",
  "Prioritized 'Free Giveaway' offers for 'Florida Teachers' segment due to high engagement in 'Paws for Teachers'."
];

const mockAgentEscalations = [
  { id: 'L001', name: 'John Doe', score: 88, reason: 'High engagement, asked for pricing.', script: 'Offer Plan B, mention 15% discount.', channel: 'SMS'},
  { id: 'L002', name: 'Jane Smith', score: 75, reason: 'Clicked 3 links, stalled on checkout.', script: 'Address potential payment concerns, offer support.', channel: 'Email'},
];

const mockScoreAdjustments = [
  { leadId: 'L789', change: '+5', reason: 'Opened email, clicked link' },
  { leadId: 'L456', change: '-2', reason: 'SMS undelivered' },
  { leadId: 'L123', change: '+10', reason: 'Completed demo request form' },
  { leadId: 'L901', change: '+3', reason: 'Replied to SMS with keyword' },
];

const workflowSteps = [
    { id: 1, title: "Lead Enters (CSV/API)", icon: UploadCloud, description: "New leads are ingested into the system via manual uploads or API integrations." },
    { id: 2, title: "System Scores & Classifies", icon: BrainCircuit, description: "AI analyzes lead data, assigning buyer scores, segmenting by region/demographics, and determining product affinity." },
    { id: 3, title: "System Chooses Optimal Path", icon: Route, description: "Based on scores and classification, the AI selects the best message type, timing, and CTA for engagement." },
    { id: 4, title: "Launches Campaign", icon: Send, description: "Automated campaigns are initiated across the chosen channels (SMS, Email, RCS, Voice)." },
    { id: 5, title: "Tracks Engagement & Updates Score", icon: TrendingUp, description: "Real-time monitoring of interactions; buyer scores are dynamically adjusted based on engagement." },
    { id: 6, title: "Learns & Adjusts Strategy", icon: Brain, description: "The AI analyzes campaign performance, identifies patterns, and refines its strategy for future interactions." },
    { id: 7, title: "Escalates to Agent (If Needed)", icon: UserCheck, description: "High-potential leads or those requiring human touch are escalated to agents with contextual scripts." }
];

export function GPTCampaignBrain() {
  const [leadInflow, setLeadInflow] = useState(0);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [currentScoreAdjustment, setCurrentScoreAdjustment] = useState(mockScoreAdjustments[0]);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [campaignCommand, setCampaignCommand] = useState("Create a campaign for PetCare for Florida teachers age 40+ using MMS + music with a free bowl giveaway.");
  const [aiGeneratedCampaign, setAiGeneratedCampaign] = useState(null);
  const { isLoading: isAiLoading, generateContent: mockGenerateCampaign } = useChatGPT();
  const { toast } = useToast();


  useEffect(() => {
    const inflowInterval = setInterval(() => {
      setLeadInflow(prev => prev + Math.floor(Math.random() * 3) + 1);
    }, 3000);
    const progressInterval = setInterval(() => {
      setProcessingProgress(prev => (prev < 100 ? prev + Math.floor(Math.random() * 7) + 3 : 0));
    }, 1800);
    
    let adjIndex = 0;
    const scoreAdjustmentInterval = setInterval(() => {
      adjIndex = (adjIndex + 1) % mockScoreAdjustments.length;
      setCurrentScoreAdjustment(mockScoreAdjustments[adjIndex]);
    }, 4000);

    return () => { clearInterval(inflowInterval); clearInterval(progressInterval); clearInterval(scoreAdjustmentInterval); };
  }, []);

  const handleGenerateCampaign = async () => {
    if (!campaignCommand.trim()) {
        toast({ title: "Command Missing", description: "Please enter a campaign command for the AI.", variant: "destructive" });
        return;
    }
    
    // Simulate calling the hook, which internally sets isLoading
    mockGenerateCampaign(campaignCommand, 'campaign_brief').then(() => {
        // Mock AI output based on the example
        const generated = {
            name: "Paws for Teachers",
            channel: "MMS",
            cta: "Claim your Free Bowl + Discounted Care Plan Today!",
            emojis: "🐶🍎📦",
            optimalTime: "4:00–6:00 PM local",
            scriptStatus: "✅ Ready to Launch",
            mockScript: "Hey {{TeacherName}}! 🐾 Time to treat your furry friend? Florida teachers like you get a FREE bowl & special PetCare discount! 🍎🐶 Click to claim by 6 PM: {{link}}"
        };
        setAiGeneratedCampaign(generated);
        toast({ title: "AI Campaign Generated!", description: `Campaign "${generated.name}" is ready for review.`});
    }).catch(err => {
        // Error toast is handled by the hook
    });
  };

  const handleApproveCampaign = () => {
    if (!aiGeneratedCampaign) return;
    toast({ title: "Campaign Approved!", description: `"${aiGeneratedCampaign.name}" launched (conceptual).`, variant: "default" });
    // Potentially add to a list of active campaigns or update learning log
    setAiGeneratedCampaign(null); // Clear after approval
  };
  
  const handleRequestRevisions = () => {
    if (!aiGeneratedCampaign) return;
    toast({ title: "Revisions Requested", description: "Sent back to AI for adjustments (conceptual).", variant: "default" });
    // Simulate AI making minor adjustments
    mockGenerateCampaign("Revise: " + aiGeneratedCampaign.name, 'campaign_revision').then(() => {
        setAiGeneratedCampaign(prev => ({
            ...prev,
            cta: prev.cta + " (Revised V2)",
            optimalTime: "4:30-6:30 PM local (Optimized)",
            mockScript: prev.mockScript.replace("Click to claim", "Tap here now to claim")
        }));
        toast({ title: "Campaign Revised!", description: "AI has updated the campaign details." });
    });
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <BrainCircuit className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              GPT Campaign Brain - Your AI-Powered CMO
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Command the AI to auto-generate, optimize, and launch campaigns. It learns and adapts.
          </p>
        </div>
      </motion.header>

      {/* AI Command & Output Section */}
      <motion.div variants={sectionVariants} initial="hidden" animate="visible" className="mb-6">
        <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 pt-5 pb-3">
                <div className="flex items-center gap-2">
                    <Wand2 size={18} className="text-primary"/>
                    <CardTitle className="text-lg font-semibold">AI Campaign Generation</CardTitle>
                </div>
                <CardDescription className="text-sm">Instruct the AI to build your next campaign.</CardDescription>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3">
                <div>
                    <Label htmlFor="campaignCommand" className="text-xs">Your Command to the AI</Label>
                    <Textarea 
                        id="campaignCommand" 
                        value={campaignCommand}
                        onChange={e => setCampaignCommand(e.target.value)}
                        placeholder="e.g., Create a campaign for PetCare for Florida teachers age 40+ using MMS + music with a free bowl giveaway."
                        className="shadcn-input mt-1 text-sm min-h-[60px]"
                    />
                </div>
                <Button onClick={handleGenerateCampaign} disabled={isAiLoading} className="w-full shadcn-button">
                    {isAiLoading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Zap className="h-4 w-4 mr-2"/>}
                    Generate Campaign with AI
                </Button>

                {aiGeneratedCampaign && (
                    <motion.div 
                        initial={{opacity:0, y:10}} animate={{opacity:1, y:0}}
                        className="mt-4 p-4 border border-primary/30 bg-primary/5 rounded-lg space-y-2"
                    >
                        <h4 className="text-base font-semibold text-primary">AI Generated Campaign Output:</h4>
                        <p className="text-xs"><strong className="text-muted-foreground">Campaign Name:</strong> {aiGeneratedCampaign.name}</p>
                        <p className="text-xs"><strong className="text-muted-foreground">Channel:</strong> <Badge variant="secondary" className="shadcn-badge">{aiGeneratedCampaign.channel}</Badge></p>
                        <p className="text-xs"><strong className="text-muted-foreground">CTA:</strong> {aiGeneratedCampaign.cta}</p>
                        <p className="text-xs"><strong className="text-muted-foreground">Emojis:</strong> {aiGeneratedCampaign.emojis}</p>
                        <p className="text-xs"><strong className="text-muted-foreground">Optimal Time:</strong> {aiGeneratedCampaign.optimalTime}</p>
                        <p className="text-xs"><strong className="text-muted-foreground">Script Status:</strong> {aiGeneratedCampaign.scriptStatus}</p>
                        <div className="text-xs p-2 bg-muted/20 rounded">
                           <strong className="text-muted-foreground">Generated Script (Mock):</strong>
                           <p className="italic text-muted-foreground/80">{aiGeneratedCampaign.mockScript}</p>
                        </div>
                        <div className="flex gap-2 pt-2">
                            <Button size="sm" variant="outline" onClick={handleRequestRevisions} disabled={isAiLoading} className="shadcn-button text-xs">
                                <Edit size={12} className="mr-1.5"/> Request Revisions
                            </Button>
                            <Button size="sm" onClick={handleApproveCampaign} disabled={isAiLoading} className="shadcn-button text-xs bg-green-600 hover:bg-green-700">
                                <ThumbsUp size={12} className="mr-1.5"/> Approve & Launch
                            </Button>
                        </div>
                    </motion.div>
                )}
            </CardContent>
             <CardFooter className="px-5 py-3 border-t border-border/20 text-xs text-muted-foreground">
                <AlertTriangle size={12} className="mr-1.5 text-amber-500"/> Conceptual: AI learns from results and auto-syncs with Segment, CRM, or SQL lead stack.
            </CardFooter>
        </Card>
      </motion.div>


      {/* Workflow Overview Section - Condensed */}
      <motion.div 
        variants={sectionVariants} initial="hidden" animate="visible" custom={0.5}
        className="mb-6 md:mb-8"
      >
        <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 pt-5 pb-3">
                <CardTitle className="text-base font-semibold flex items-center gap-2"><ListChecks size={18} className="text-primary"/>Underlying AI Workflow Stages</CardTitle>
            </CardHeader>
            <CardContent className="px-5 pb-5 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-2">
                {workflowSteps.map(step => (
                     <motion.div variants={itemVariants} key={step.id} className="p-2 bg-muted/25 rounded-md border border-border/30 text-center h-full flex flex-col items-center justify-center aspect-square">
                        <step.icon size={16} className="text-primary mb-1"/>
                        <p className="text-[10px] font-medium text-foreground leading-tight">{step.id}. {step.title.substring(0,15)}{step.title.length > 15 ? '...' : ''}</p>
                    </motion.div>
                ))}
            </CardContent>
        </Card>
      </motion.div>

      {/* Step 1: Lead Entry (Minimized) */}
      <motion.div variants={sectionVariants} initial="hidden" animate="visible" custom={1} className="mb-6">
        <Card className="frosty-glass p-0.5">
          <CardHeader className="px-5 pt-4 pb-2 flex flex-row justify-between items-center">
            <div className="flex items-center gap-2">
              <UploadCloud size={16} className="text-primary"/>
              <CardTitle className="text-base font-semibold">Lead Ingestion</CardTitle>
            </div>
            <Button size="xs" variant="outline" className="shadcn-button text-[10px]" onClick={() => setShowFileUpload(prev => !prev)}>
                {showFileUpload ? 'Hide CSV Upload' : 'Upload CSV'}
            </Button>
          </CardHeader>
          {showFileUpload && (
            <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} exit={{opacity:0, height:0}} className="overflow-hidden">
                <CardContent className="px-5 pb-4 pt-1">
                    <FileUploadManager />
                </CardContent>
            </motion.div>
          )}
           <CardFooter className="px-5 py-2 border-t border-border/20 text-xs text-muted-foreground">
             Leads today: <span className="font-semibold text-primary ml-1">{leadInflow.toLocaleString()}</span>
          </CardFooter>
        </Card>
      </motion.div>
      
      <motion.div 
        variants={sectionVariants} initial="hidden" animate="visible" custom={1.5}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6"
      >
        {/* Step 2 & 3: Scoring, Classification & Path Selection */}
        <motion.div variants={itemVariants} className="space-y-4">
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-4 pt-4 pb-2 flex items-center gap-2">
              <BrainCircuit size={16} className="text-primary"/>
              <CardTitle className="text-sm font-semibold">AI Scoring & Classification</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-3 text-xs space-y-1">
              <p><span className="font-medium text-muted-foreground">Avg. Buyer Score:</span> <Badge variant="secondary" className="shadcn-badge">78</Badge></p>
              <p><span className="font-medium text-muted-foreground">Top Region:</span> <Badge variant="outline" className="shadcn-badge">CA (Bay Area)</Badge></p>
              <p><span className="font-medium text-muted-foreground">Affinity:</span> <Badge variant="outline" className="shadcn-badge">Telemed Pro</Badge></p>
              <Progress value={processingProgress} className="h-1 mt-1.5 bg-primary/20" indicatorClassName="bg-primary" />
            </CardContent>
          </Card>
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-4 pt-4 pb-2 flex items-center gap-2">
                <Route size={16} className="text-primary"/>
                <CardTitle className="text-sm font-semibold">Optimal Path Selection</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-3 text-xs space-y-1">
                <p className="font-medium text-muted-foreground">Next Best Action for 'High Intent CA':</p>
                <div className="p-1.5 bg-muted/20 rounded-md text-[11px]">
                    <p><span className="font-medium">Channel:</span> SMS, <span className="font-medium">Timing:</span> 9 AM PST, <span className="font-medium">CTA:</span> "Limited Time..."</p>
                </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Step 4, 5 & Dynamic Score Ticker */}
        <motion.div variants={itemVariants} className="space-y-4">
            <Card className="frosty-glass p-0.5">
                <CardHeader className="px-4 pt-4 pb-2 flex items-center gap-2">
                    <Send size={16} className="text-primary"/>
                    <CardTitle className="text-sm font-semibold">Campaign Launch Status</CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-3 text-xs">
                    <p><span className="font-medium text-muted-foreground">Active Campaigns:</span> <Badge className="shadcn-badge bg-green-500/20 text-green-700">17</Badge></p>
                    <p className="mt-1 text-muted-foreground">Launched last hour: <span className="font-semibold text-primary">2</span></p>
                </CardContent>
            </Card>
             <Card className="frosty-glass p-0.5">
                <CardHeader className="px-4 pt-4 pb-2 flex items-center gap-2">
                    <TrendingUp size={16} className="text-primary"/>
                    <CardTitle className="text-sm font-semibold">Engagement Tracking</CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-3 text-xs space-y-1">
                    <p><span className="font-medium text-muted-foreground">Overall Engagement:</span> <Badge className="shadcn-badge bg-sky-500/20 text-sky-700">34.7%</Badge></p>
                    <div className="p-1.5 bg-muted/20 rounded-md mt-1">
                      <p className="font-medium text-primary/90 text-[11px]">Real-time Score Update:</p>
                      <AnimatePresence mode="wait">
                        <motion.p 
                            key={currentScoreAdjustment.leadId + currentScoreAdjustment.change}
                            initial={{opacity:0, x: -5}} animate={{opacity:1, x: 0}} exit={{opacity:0, x:5}} transition={{duration:0.2}}
                            className="text-muted-foreground text-[10px]"
                        >
                            {currentScoreAdjustment.leadId}: <span className={currentScoreAdjustment.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}>{currentScoreAdjustment.change}</span> ({currentScoreAdjustment.reason})
                        </motion.p>
                      </AnimatePresence>
                    </div>
                </CardContent>
            </Card>
        </motion.div>
        
        {/* Step 6 & 7: Learning Log and Escalation Queue (Condensed) */}
        <motion.div variants={itemVariants} className="space-y-4">
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-4 pt-4 pb-2 flex items-center gap-2">
              <Brain size={16} className="text-primary"/>
              <CardTitle className="text-sm font-semibold">AI Learning Log</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-3 max-h-[100px] overflow-y-auto scrollbar-hide">
              {mockLearningLog.slice(0,3).map((log, index) => (
                <div key={index} className="text-[10px] p-1 bg-muted/30 rounded flex items-start gap-1 mb-1">
                  <span className="text-primary pt-0.5 shrink-0 text-[8px]">&rarr;</span>
                  <span className="text-muted-foreground truncate">{log}</span>
                </div>
              ))}
            </CardContent>
          </Card>
           <Card className="frosty-glass p-0.5">
            <CardHeader className="px-4 pt-4 pb-2 flex items-center gap-2">
                <UserCheck size={16} className="text-primary"/>
                <CardTitle className="text-sm font-semibold">Agent Escalation</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-3 max-h-[100px] overflow-y-auto scrollbar-hide">
              {mockAgentEscalations.slice(0,1).map(lead => (
                <div key={lead.id} className="p-1 border border-border/40 rounded bg-background/20 text-[10px]">
                  <span className="font-medium">{lead.name} <Badge variant="secondary" className="shadcn-badge text-[8px] px-1 py-0">Score: {lead.score}</Badge></span>
                  <p className="text-muted-foreground truncate">{lead.reason}</p>
                </div>
              ))}
              {mockAgentEscalations.length === 0 && <p className="text-xs text-muted-foreground text-center py-2">No escalations.</p>}
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">AI-Powered Automation Core</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
               This dashboard conceptualizes an AI-driven campaign generation and lead conversion workflow. Full realization requires robust backend services, sophisticated AI/ML models, and seamless API integrations across data sources and communication channels.
            </p>
        </div>
      </motion.div>
    </div>
  );
}