import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ShieldCheck, Server, RotateCw, AlertTriangle, ExternalLink, WifiOff, ListFilter, Search, DollarSign, Star, Loader2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.05, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};


export function BackupProviders() {
  const [providers, setProviders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingProvider, setEditingProvider] = useState(null);
  const [formData, setFormData] = useState({ apiKey: '', failoverPriority: 1 });
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    const fetchProviders = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('providers')
        .select('*')
        .order('failover_priority', { ascending: true });

      if (error) {
        console.error('Error fetching providers:', error);
        toast({ title: "Error", description: "Could not fetch provider data.", variant: "destructive" });
      } else {
        setProviders(data);
      }
      setIsLoading(false);
    };

    fetchProviders();
  }, []);

  const providerTypes = useMemo(() => {
    if (isLoading || providers.length === 0) return ['all'];
    return ['all', ...new Set(providers.map(p => p.type))];
  }, [providers, isLoading]);


  const filteredProviders = useMemo(() => {
    return providers
      .filter(p => filterType === 'all' || p.type === filterType)
      .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
      .sort((a, b) => a.failover_priority - b.failover_priority);
  }, [providers, searchTerm, filterType]);

  const handleConfigure = (provider) => {
    setEditingProvider(provider);
    setFormData({ 
      apiKey: '', 
      failoverPriority: provider.failover_priority 
    });
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveConfiguration = async () => {
    if (!editingProvider) return;

    const newStatus = editingProvider.status === 'unconfigured' ? 'standby' : editingProvider.status;
    const { data, error } = await supabase
      .from('providers')
      .update({ failover_priority: formData.failoverPriority, status: newStatus, api_key_configured: true })
      .eq('id', editingProvider.id)
      .select()
      .single();

    if (error) {
      toast({ title: "Error Saving", description: error.message, variant: "destructive" });
    } else {
      setProviders(prev => prev.map(p => p.id === data.id ? data : p));
      toast({ title: "Provider Configuration Updated", description: `${editingProvider.name}'s failover priority is now ${formData.failoverPriority}.` });

      if (formData.apiKey) {
        toast({ title: "API Key Action (Conceptual)", description: "In a real app, the API key would be securely saved now.", variant: "default" });
      }

      setShowForm(false);
      setEditingProvider(null);
    }
  };

  const toggleProviderStatus = async (id) => {
    const provider = providers.find(p => p.id === id);
    if (!provider) return;

    if (!provider.api_key_configured) {
      toast({ title: "Configuration Required", description: `Please configure ${provider.name} before enabling.`, variant: "destructive" });
      return;
    }

    const newStatus = provider.status === 'active' ? 'standby' : 'active';
    const { data, error } = await supabase
      .from('providers')
      .update({ status: newStatus })
      .eq('id', id)
      .select()
      .single();
      
    if (error) {
        toast({ title: "Error Updating Status", description: error.message, variant: "destructive" });
    } else {
        setProviders(prev => prev.map(p => p.id === data.id ? data : p));
        toast({ title: `${provider.name} Status Changed`, description: `Now ${newStatus}.` });
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
        <Loader2 className="h-10 w-10 animate-spin mb-4" />
        <p className="text-lg font-medium">Loading Provider Intelligence...</p>
        <p className="text-sm">Fetching real-time configurations from secure database.</p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Backup Communication Providers
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Manage alternative communication service providers for contingency and failover.
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="space-y-6"
      >
        <motion.div variants={itemVariants}>
          <Card className="frosty-glass p-0.5">
            <CardContent className="p-3 flex flex-col sm:flex-row gap-3 items-center">
              <div className="relative w-full sm:flex-grow">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search providers..." className="shadcn-input pl-8" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
              </div>
              <div className="w-full sm:w-auto">
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="shadcn-input w-full sm:w-[220px]">
                    <ListFilter className="h-3.5 w-3.5 mr-2 text-muted-foreground"/>
                    <SelectValue placeholder="Filter by type..." />
                  </SelectTrigger>
                  <SelectContent className="shadcn-select-content">
                    {providerTypes.map(type => (
                      <SelectItem key={type} value={type} className="capitalize shadcn-select-item">{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {showForm && editingProvider && (
          <motion.div 
            initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} exit={{opacity:0, height:0}}
            className="overflow-hidden"
          >
            <Card className="frosty-glass p-0.5 mb-6 ring-2 ring-primary/50">
              <CardHeader className="px-5 pt-5 pb-2">
                <CardTitle className="text-base font-semibold">Configure: {editingProvider.name}</CardTitle>
                <CardDescription className="text-xs">Enter API credentials and set failover priority.</CardDescription>
              </CardHeader>
              <CardContent className="px-5 pb-5 space-y-3">
                <div>
                  <Label htmlFor="apiKey" className="text-xs text-muted-foreground">API Key (Conceptual)</Label>
                  <Input id="apiKey" type="password" value={formData.apiKey} onChange={e => setFormData({...formData, apiKey: e.target.value})} placeholder="Enter API Key to store in Vault" className="shadcn-input mt-0.5"/>
                </div>
                <div>
                    <Label htmlFor="failoverPriority" className="text-xs text-muted-foreground">Failover Priority (1=highest)</Label>
                    <Input id="failoverPriority" type="number" value={formData.failoverPriority} onChange={e => setFormData({...formData, failoverPriority: parseInt(e.target.value) || 1})} className="shadcn-input mt-0.5"/>
                </div>
                <div className="flex gap-2 pt-1">
                  <Button onClick={handleSaveConfiguration} className="shadcn-button">Save Configuration</Button>
                  <Button variant="outline" className="shadcn-button" onClick={() => {setShowForm(false); setEditingProvider(null);}}>Cancel</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {filteredProviders.length === 0 && !showForm && (
             <motion.div variants={itemVariants} className="text-center py-12 frosty-glass rounded-lg">
                <WifiOff className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold text-foreground mb-1.5">No Matching Providers Found</h3>
                <p className="text-sm text-muted-foreground">Try adjusting your search or filter criteria.</p>
            </motion.div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProviders.map((provider, index) => (
            <motion.div key={provider.id} variants={itemVariants} custom={index}>
              <Card className="frosty-glass p-0.5 h-full flex flex-col">
                <CardHeader className="px-4 pt-4 pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base font-semibold text-foreground">{provider.name}</CardTitle>
                    <Switch 
                      checked={provider.status === 'active' || provider.status === 'standby'} 
                      onCheckedChange={() => toggleProviderStatus(provider.id)}
                      className="shadcn-switch data-[state=checked]:bg-green-600 data-[state=unchecked]:bg-red-600"
                      aria-label={`Toggle ${provider.name} status`}
                      disabled={provider.status === 'disabled'}
                    />
                  </div>
                  <CardDescription className="text-xs">{provider.type}</CardDescription>
                </CardHeader>
                <CardContent className="px-4 pb-4 text-xs space-y-2 flex-grow flex flex-col">
                  <p className="flex items-center gap-1.5"><strong className="w-24 shrink-0">Status:</strong> <span className={`capitalize font-medium ${provider.status === 'active' ? 'text-green-500' : provider.status === 'standby' ? 'text-yellow-500' : provider.status === 'unconfigured' ? 'text-muted-foreground' : 'text-red-500'}`}>{provider.status}</span></p>
                  <p className="flex items-center gap-1.5"><strong className="w-24 shrink-0">Failover Priority:</strong> {provider.failover_priority === 0 ? 'Primary' : provider.failover_priority}</p>
                  <div className="p-2.5 rounded-md bg-muted/30 space-y-1.5 text-[11px]">
                    <p className="flex items-start gap-1.5"><Star className="h-3 w-3 mt-0.5 text-amber-500 shrink-0"/> <span><strong>Best For:</strong> {provider.best_for}</span></p>
                    <p className="flex items-start gap-1.5"><DollarSign className="h-3 w-3 mt-0.5 text-green-500 shrink-0"/> <span><strong>Pricing:</strong> {provider.pricing_model}</span></p>
                  </div>
                  <div className="flex gap-2 pt-2 mt-auto">
                    <Button size="sm" variant="outline" className="shadcn-button text-[10px] h-7" onClick={() => handleConfigure(provider)}>
                      {provider.api_key_configured ? 'Edit' : 'Configure'}
                    </Button>
                    <Button size="sm" variant="outline" className="shadcn-button text-[10px] h-7" onClick={() => toast({title:"Test Connection (Mock)", description:`Simulating test for ${provider.name}.`})}>Test</Button>
                    <a href={provider.docs_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline text-[10px] flex items-center ml-auto self-end">
                        API Docs <ExternalLink className="h-2.5 w-2.5 ml-0.5"/>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <motion.div variants={itemVariants} className="mt-auto pt-6">
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 pt-4 pb-2">
              <div className="flex items-center gap-2">
                <RotateCw className="h-4 w-4 text-primary opacity-80"/>
                <CardTitle className="text-sm font-semibold">Automatic Failover Logic (Conceptual)</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="px-5 pb-4 text-xs text-muted-foreground">
              <p>This system would ideally implement automated failover. If the primary provider experiences an outage, traffic would be rerouted to backup providers based on priority and health checks.</p>
              <ul className="list-disc list-inside pl-3 mt-1 space-y-0.5">
                  <li>Priority 1: Highest preference, used first on failover.</li>
                  <li>Health Checks: Regularly ping backup provider APIs.</li>
                  <li>Thresholds: Define conditions for triggering failover (e.g., X failed attempts).</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

         <motion.div 
            variants={itemVariants} 
            initial="hidden" 
            animate="visible" 
            custom={3} 
            className="mt-8"
        >
            <div className="p-3 frosty-glass rounded-md">
                <div className="flex items-center gap-1.5">
                    <AlertTriangle className="h-4 w-4 text-amber-500"/>
                    <h4 className="font-semibold text-foreground text-xs">Important Note</h4>
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                    Backup Provider data is now persistent. However, actual API key integration for each provider requires creating specific Supabase Edge Functions to securely handle credentials. This mockup demonstrates the UI and data structure.
                </p>
            </div>
        </motion.div>
      </motion.div>
    </div>
  );
}