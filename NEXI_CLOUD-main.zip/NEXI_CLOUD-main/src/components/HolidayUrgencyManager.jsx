import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CalendarClock, PlusCircle, Edit3, Trash2, Sparkles, AlertTriangle, Info, ListChecks, Tag, Users, Clock4, ChevronLeft, ChevronRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useTwilioData } from '@/hooks/useTwilioData'; // Assuming campaign data is managed here

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();
const getMonthMatrix = (year, month) => {
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = getDaysInMonth(year, month);
  let matrix = [];
  let day = 1;
  for (let i = 0; i < 6; i++) { 
    let week = [];
    for (let j = 0; j < 7; j++) {
      if (i === 0 && j < firstDay) {
        week.push(null);
      } else if (day > daysInMonth) {
        week.push(null);
      } else {
        week.push(day++);
      }
    }
    matrix.push(week);
    if (day > daysInMonth) break;
  }
  return matrix;
};

export function HolidayUrgencyManager() {
  const { campaigns, setCurrentTab } = useTwilioData(); // Use campaigns from global state
  const { toast } = useToast();
  
  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const monthMatrix = getMonthMatrix(currentYear, currentMonth);
  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const timedCampaignsOnCalendar = campaigns.filter(c => c.isTimedCampaign && c.startDate && c.endDate);

  const changeMonth = (delta) => {
    let newMonth = currentMonth + delta;
    let newYear = currentYear;
    if (newMonth < 0) {
      newMonth = 11;
      newYear--;
    } else if (newMonth > 11) {
      newMonth = 0;
      newYear++;
    }
    setCurrentMonth(newMonth);
    setCurrentYear(newYear);
  };

  const getCampaignsForDay = (day) => {
    if (!day) return [];
    const date = new Date(currentYear, currentMonth, day);
    return timedCampaignsOnCalendar.filter(c => {
        const startDate = new Date(c.startDate + 'T00:00:00Z'); // Ensure UTC interpretation if dates are stored as YYYY-MM-DD
        const endDate = new Date(c.endDate + 'T23:59:59Z');
        return date >= startDate && date <= endDate;
    });
  };
  
  const handleAddNewCampaign = () => {
    setCurrentTab('campaigns'); // Switch to CampaignManager tab
    toast({
        title: "Redirecting...",
        description: "Opening Campaign Manager to create a new timed campaign.",
    });
    // Ideally, also trigger 'new campaign' form with 'isTimedCampaign' checked in CampaignManager
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <CalendarClock className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Offer & Promotion Calendar
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Visualize your scheduled holiday campaigns, flash sales, and other timed promotions.
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        className="lg:col-span-3" 
      >
        <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 pt-5 pb-3">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <CardTitle className="text-lg font-semibold">Campaign Calendar</CardTitle>
                    <div className="flex items-center gap-2">
                        <Button variant="outline" size="icon" onClick={() => changeMonth(-1)} className="shadcn-button h-8 w-8 text-xs"><ChevronLeft size={16}/></Button>
                        <span className="text-sm font-medium w-32 text-center">{monthNames[currentMonth]} {currentYear}</span>
                        <Button variant="outline" size="icon" onClick={() => changeMonth(1)} className="shadcn-button h-8 w-8 text-xs"><ChevronRight size={16}/></Button>
                        <Button size="sm" onClick={handleAddNewCampaign} className="shadcn-button h-8 text-xs"><PlusCircle size={14} className="mr-1.5"/> New Timed Campaign</Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="px-5 pb-5">
                 <div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-muted-foreground mb-2">
                    {dayNames.map(day => <div key={day} className="py-1">{day}</div>)}
                </div>
                <div className="grid grid-cols-7 gap-1">
                    {monthMatrix.map((week, i) => week.map((day, j) => {
                        const campaignsOnThisDay = getCampaignsForDay(day);
                        const isToday = day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
                        return (
                            <div 
                                key={`${i}-${j}`} 
                                className={`h-20 sm:h-24 p-1.5 border border-border/20 rounded-md text-xs overflow-hidden relative
                                    ${day ? 'bg-background/30 hover:bg-muted/20' : 'bg-muted/10 cursor-default'}
                                    ${isToday ? 'ring-2 ring-primary ring-inset' : ''}`}
                            >
                               {day && <span className={`font-medium ${isToday ? 'text-primary' : ''}`}>{day}</span>}
                               <div className="mt-1 space-y-0.5">
                                {campaignsOnThisDay.slice(0, 2).map(campaign => (
                                    <div key={campaign.id} title={campaign.eventName || campaign.name} className="truncate text-[9px] sm:text-[10px] bg-primary/10 text-primary px-1 py-0.5 rounded-sm cursor-pointer hover:bg-primary/20">
                                       <Sparkles size={8} className="inline mr-0.5"/> {campaign.eventName || campaign.name}
                                    </div>
                                ))}
                                {campaignsOnThisDay.length > 2 && (
                                    <div className="text-[9px] text-muted-foreground text-center mt-0.5">+{campaignsOnThisDay.length - 2} more</div>
                                )}
                               </div>
                            </div>
                        );
                    }))}
                </div>
            </CardContent>
             <CardFooter className="px-5 py-3 border-t border-border/20">
                <p className="text-[10px] text-muted-foreground">Click on a campaign to view details (future feature). Manage timed campaigns in the Campaign Manager.</p>
            </CardFooter>
        </Card>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={1} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Promotion Visualization</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This calendar provides a visual overview of your timed marketing activities. Configuration and management of these campaigns are handled within the Campaign Manager section.
            </p>
        </div>
      </motion.div>
    </div>
  );
}