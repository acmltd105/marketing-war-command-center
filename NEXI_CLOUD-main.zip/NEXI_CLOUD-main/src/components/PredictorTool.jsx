import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BrainCircuit, DollarSign, Target, Zap, AlertTriangle, Lightbulb, BarChartBig, Search } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

export function PredictorTool() {
  const [predictorAmount, setPredictorAmount] = React.useState('');
  const [martyDeals, setMartyDeals] = React.useState('');
  const [martyPremium, setMartyPremium] = React.useState('');
  const [mockPrediction, setMockPrediction] = React.useState(null);
  const [mockMartyPlan, setMockMartyPlan] = React.useState(null);

  const handlePrediction = () => {
    if (!predictorAmount || parseFloat(predictorAmount) <= 0) {
      toast({ title: "Invalid Input", description: "Please enter a valid dollar amount.", variant: "destructive" });
      return;
    }
    setMockPrediction({
      bestCampaign: "Q3 SMS Blast",
      projectedRoi: "175%",
      estimatedLeads: Math.floor(parseFloat(predictorAmount) * 0.23),
      spendAllocation: [
        { channel: "SMS", percent: 60, amount: parseFloat(predictorAmount) * 0.6 },
        { channel: "Email", percent: 30, amount: parseFloat(predictorAmount) * 0.3 },
        { channel: "Voice Blast", percent: 10, amount: parseFloat(predictorAmount) * 0.1 },
      ]
    });
    toast({ title: "Prediction Generated (Mock)", description: "Displaying simulated campaign allocation." });
  };

  const handleMartyPlan = () => {
    if ((!martyDeals || parseInt(martyDeals) <= 0) && (!martyPremium || parseInt(martyPremium) <= 0)) {
      toast({ title: "Invalid Input", description: "Please enter target deals or premium.", variant: "destructive" });
      return;
    }
    setMockMartyPlan({
      requiredSpend: (parseInt(martyDeals || 0) * 55) + (parseInt(martyPremium || 0) * 0.15),
      campaignFocus: "High-Intent Email Sequence",
      timeline: "7 days",
      suggestedActions: [
        "Increase bid on 'Buy Now' keywords by 15%.",
        "Segment email list for users who visited pricing page.",
        "Launch retargeting SMS for cart abandoners.",
      ]
    });
     toast({ title: "Marty McFly Plan Generated (Mock)", description: "Displaying simulated spend and actions." });
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <BrainCircuit className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Campaign Predictor & Strategy Tool
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Leverage predictive insights and reverse-engineer your campaign success.
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="space-y-8 md:space-y-10"
      >
        <motion.div variants={itemVariants}>
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 md:px-6 pt-5 md:pt-6 pb-3">
              <div className="flex items-center gap-2.5">
                <Search className="h-5 w-5 text-primary opacity-90" />
                <CardTitle className="text-lg md:text-xl font-semibold text-foreground">Investment Predictor</CardTitle>
              </div>
              <CardDescription className="text-sm md:text-base">Enter a budget to see potential campaign allocations and results.</CardDescription>
            </CardHeader>
            <CardContent className="px-5 md:px-6 pb-5 md:pb-6 space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-end">
                <div className="flex-grow space-y-1.5">
                  <Label htmlFor="predictorAmount" className="text-xs font-medium text-muted-foreground">Total Investment Amount ($)</Label>
                  <Input id="predictorAmount" type="number" value={predictorAmount} onChange={(e) => setPredictorAmount(e.target.value)} placeholder="e.g., 5000" className="shadcn-input" />
                </div>
                <Button onClick={handlePrediction} className="shadcn-button w-full sm:w-auto">
                  <BarChartBig className="h-4 w-4 mr-2"/> Predict Outcome
                </Button>
              </div>
              {mockPrediction && (
                <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="mt-5 p-4 bg-primary/5 border border-primary/20 rounded-md space-y-2.5">
                  <h4 className="text-sm font-semibold text-primary">Simulated Prediction:</h4>
                  <p className="text-xs"><strong>Optimal Campaign Focus:</strong> {mockPrediction.bestCampaign}</p>
                  <p className="text-xs"><strong>Projected ROI:</strong> {mockPrediction.projectedRoi}</p>
                  <p className="text-xs"><strong>Estimated Leads:</strong> {mockPrediction.estimatedLeads}</p>
                  <p className="text-xs font-medium mt-1.5">Spend Allocation:</p>
                  <ul className="list-disc list-inside text-xs space-y-0.5 pl-1">
                    {mockPrediction.spendAllocation.map(item => (
                      <li key={item.channel}>{item.channel}: {item.percent}% (${item.amount.toFixed(2)})</li>
                    ))}
                  </ul>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 md:px-6 pt-5 md:pt-6 pb-3">
              <div className="flex items-center gap-2.5">
                <Zap className="h-5 w-5 text-primary opacity-90" />
                <CardTitle className="text-lg md:text-xl font-semibold text-foreground">"Marty McFly" Goal Reverser</CardTitle>
              </div>
              <CardDescription className="text-sm md:text-base">Input your desired outcomes, and we'll suggest the spend and strategy.</CardDescription>
            </CardHeader>
            <CardContent className="px-5 md:px-6 pb-5 md:pb-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="martyDeals" className="text-xs font-medium text-muted-foreground">Target Deals / Conversions</Label>
                  <Input id="martyDeals" type="number" value={martyDeals} onChange={(e) => setMartyDeals(e.target.value)} placeholder="e.g., 100" className="shadcn-input" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="martyPremium" className="text-xs font-medium text-muted-foreground">Target Premium / Revenue ($)</Label>
                  <Input id="martyPremium" type="number" value={martyPremium} onChange={(e) => setMartyPremium(e.target.value)} placeholder="e.g., 25000" className="shadcn-input" />
                </div>
              </div>
              <Button onClick={handleMartyPlan} className="shadcn-button w-full sm:w-auto">
                <Lightbulb className="h-4 w-4 mr-2"/> Generate Strategy
              </Button>
              {mockMartyPlan && (
                <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="mt-5 p-4 bg-primary/5 border border-primary/20 rounded-md space-y-2.5">
                  <h4 className="text-sm font-semibold text-primary">Simulated Strategic Plan:</h4>
                  <p className="text-xs"><strong>Required Spend Estimate:</strong> ${mockMartyPlan.requiredSpend.toFixed(2)}</p>
                  <p className="text-xs"><strong>Primary Campaign Focus:</strong> {mockMartyPlan.campaignFocus}</p>
                  <p className="text-xs"><strong>Estimated Timeline:</strong> {mockMartyPlan.timeline}</p>
                  <p className="text-xs font-medium mt-1.5">Key Actions:</p>
                  <ul className="list-disc list-inside text-xs space-y-0.5 pl-1">
                    {mockMartyPlan.suggestedActions.map((action, i) => <li key={i}>{action}</li>)}
                  </ul>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div variants={itemVariants} className="mt-auto pt-4">
          <div className="p-3 frosty-glass rounded-md">
              <div className="flex items-center gap-1.5">
                  <AlertTriangle className="h-4 w-4 text-amber-500"/>
                  <h4 className="font-semibold text-foreground text-xs">Alpha Feature Notice</h4>
              </div>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                  The Predictor and Marty McFly tools are currently in early development and use simulated data. 
                  Full functionality requires data integration and advanced analytics models.
              </p>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}