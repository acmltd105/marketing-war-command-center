import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ActivitySquare, Users, Clock, BarChartHorizontalBig, AlertTriangle, Filter, Download } from 'lucide-react';

export function FlexInsights() {
  const mockInsights = [
    { metric: "Average Handle Time", value: "4m 32s", trend: "-5%" },
    { metric: "First Call Resolution", value: "78%", trend: "+2%" },
    { metric: "Agent Occupancy", value: "85%", trend: "+1.5%" },
    { metric: "CSAT Score", value: "4.6/5", trend: "+0.1" },
    { metric: "Abandoned Calls", value: "3.2%", trend: "-0.5%" },
    { metric: "Active Agents", value: "42", trend: "Stable" },
  ];

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <ActivitySquare className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Twilio Flex Insights Dashboard
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Key performance indicators and operational metrics for your contact center. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay:0.1, ease: "circOut" }}
        className="flex-grow"
      >
        <div className="mb-6 flex justify-between items-center">
            <div className="flex gap-2">
                <Button variant="outline" className="shadcn-button text-xs">
                    <Filter className="h-3.5 w-3.5 mr-1.5"/> Date Range (Mock)
                </Button>
                 <Button variant="outline" className="shadcn-button text-xs">
                    <Users className="h-3.5 w-3.5 mr-1.5"/> Filter Agents (Mock)
                </Button>
            </div>
            <Button className="shadcn-button text-xs">
                <Download className="h-3.5 w-3.5 mr-1.5"/> Export Report (Mock)
            </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6 mb-8">
          {mockInsights.map((insight, index) => (
            <motion.div 
                key={insight.metric}
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.05, ease: "circOut" }}
            >
              <Card className="frosty-glass p-0.5 h-full">
                <CardHeader className="pb-2 pt-4 px-4">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{insight.metric}</CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-4">
                  <p className="text-2xl md:text-3xl font-bold text-foreground">{insight.value}</p>
                  <p className={`text-xs mt-1 ${insight.trend.startsWith('+') ? 'text-green-600' : insight.trend.startsWith('-') ? 'text-red-600' : 'text-muted-foreground'}`}>
                    {insight.trend} vs previous period
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 pt-5 pb-3">
                <CardTitle className="text-lg font-semibold text-foreground">Agent Performance Overview (Mock Chart)</CardTitle>
                <CardDescription className="text-sm">Comparative view of key agent metrics.</CardDescription>
            </CardHeader>
            <CardContent className="px-5 pb-5">
                <div className="h-64 bg-muted/30 rounded-md flex items-center justify-center">
                    <BarChartHorizontalBig className="h-12 w-12 text-muted-foreground opacity-50"/>
                    <p className="ml-3 text-muted-foreground">Detailed agent performance chart would appear here.</p>
                </div>
            </CardContent>
        </Card>
        
        <div className="mt-8 p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Conceptual Mockup</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This Flex Insights board is a conceptual representation. Actual implementation would require integration with Twilio Flex data sources and a robust charting library.
            </p>
        </div>
      </motion.div>
    </div>
  );
}