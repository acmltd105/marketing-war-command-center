
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from '@/components/ui/use-toast';
import { 
  Network as NetworkIcon,
  Key as KeyIcon, 
  Activity, 
  Link as LinkIcon, 
  CheckCircle, 
  AlertCircle, 
  Search, 
  Tag,
  ClipboardList,
  Terminal,
  Shapes
} from 'lucide-react';
import { nexusDynamicsApiLibrary } from '@/lib/nexusDynamicsApiLibrary';
import { cn } from '@/lib/utils';

const cardVariants = {
  hidden: { opacity: 0, y: 25, scale: 0.96 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.035,
      duration: 0.4,
      ease: [0.2, 0.8, 0.2, 1]
    }
  })
};

const sectionHeaderVariants = {
  hidden: { opacity: 0, y: -15 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'circOut' } }
};

const categoryIcons = {
  "Task Workflow": ClipboardList,
  "API Key": KeyIcon,
  "Account Detail": Tag,
  "Phone Number": Shapes,
  "Test Credential": Terminal,
  "Security Setting": AlertCircle,
  "Other": LinkIcon,
};

export function ApiProfileManager() {
  const [activeTests, setActiveTests] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [apiEntries, setApiEntries] = useState(nexusDynamicsApiLibrary);

  const apiCategories = useMemo(() => {
    return apiEntries.reduce((acc, entry) => {
      const categoryTitle = entry.category || "Other";
      if (!acc[categoryTitle]) {
        acc[categoryTitle] = {
          title: categoryTitle,
          icon: categoryIcons[categoryTitle] || LinkIcon,
          color: 'text-primary', 
          apis: []
        };
      }
      acc[categoryTitle].apis.push(entry);
      return acc;
    }, {});
  }, [apiEntries]);
  
  const filteredApiCategories = useMemo(() => {
    return Object.entries(apiCategories).map(([key, category]) => ({
      ...category,
      apis: category.apis.filter(api => 
        api.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        (api.id_or_value && api.id_or_value.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (api.type && api.type.toLowerCase().includes(searchTerm.toLowerCase())) ||
        api.category.toLowerCase().includes(searchTerm.toLowerCase())
      )
    })).filter(category => category.apis.length > 0);
  }, [apiCategories, searchTerm]);


  const testApiEntry = async (entryName, entryType) => {
    setActiveTests(prev => ({ ...prev, [entryName]: true }));
    toast({ title: "Initiating Test...", description: `Conceptual test for ${entryType}: ${entryName}.`, duration: 2000 });
    try {
      await new Promise(resolve => setTimeout(resolve, 1800));
      const success = Math.random() > 0.15; // Higher success rate for these conceptual tests

      setApiEntries(prevEntries => prevEntries.map(p => {
        if (p.name === entryName) {
          return { ...p, lastTestStatus: success ? 'success' : 'failed', lastTestDate: new Date().toISOString() };
        }
        return p;
      }));

      if (success) {
        toast({ title: "Test Successful (Conceptual)", description: `${entryName} responded as expected.`, duration: 3000 });
      } else {
        toast({ title: "Test Failed (Conceptual)", description: `${entryName} test failed or timed out.`, variant: "destructive", duration: 3000 });
      }
    } catch (error) {
      toast({ title: "Test Error (Conceptual)", description: `An unexpected error occurred during the test.`, variant: "destructive", duration: 3000 });
    } finally {
      setActiveTests(prev => ({ ...prev, [entryName]: false }));
    }
  };
  
  const getStatusBadge = (entry) => {
    if (entry && entry.lastTestStatus) {
        if (entry.lastTestStatus === 'success') {
            return <Badge variant="default" className="shadcn-badge bg-green-500/15 text-green-700"><CheckCircle className="h-3 w-3 mr-1 inline"/>Tested OK</Badge>;
        } else if (entry.lastTestStatus === 'failed') {
            return <Badge variant="destructive" className="shadcn-badge bg-red-500/15 text-red-700"><AlertCircle className="h-3 w-3 mr-1 inline"/>Test Failed</Badge>;
        }
    }
    // Default status or if no test has been run
    return <Badge variant="outline" className="shadcn-badge">Not Tested</Badge>;
  };

  return (
    <div className="space-y-8 md:space-y-10 p-0">
      <motion.div
         initial={{ opacity: 0, y: -20 }}
         animate={{ opacity: 1, y: 0 }}
         transition={{ duration: 0.5, ease: "circOut" }}
      >
        <div className="flex items-center gap-3">
            <NetworkIcon className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Nexus Dynamics API Profile Manager
            </h1>
        </div>
        <p className="text-sm md:text-base text-muted-foreground mt-1">
          Manage and test your curated collection of APIs, Workflows, and Credentials.
        </p>
      </motion.div>

      <motion.div variants={cardVariants} initial="hidden" animate="visible" custom={1} className="relative">
         <Input 
            type="text"
            placeholder="Search Nexus Dynamics API profiles..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="shadcn-input w-full pl-10 text-sm"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground opacity-60" />
      </motion.div>
      
      {filteredApiCategories.length === 0 && (
        <motion.div 
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="text-center py-12 frosty-glass rounded-lg"
        >
            <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold text-foreground mb-1.5">No API Profiles Found</h3>
            <p className="text-sm text-muted-foreground">
              {searchTerm ? `No entries match your search for "${searchTerm}".` : "No API profiles loaded or defined."}
            </p>
        </motion.div>
      )}

      {filteredApiCategories.map((category, catIndex) => (
        <motion.section
          key={category.title} 
          className="space-y-4"
          initial="hidden"
          animate="visible"
          variants={sectionHeaderVariants}
        >
          <motion.div className="flex items-center gap-2.5 pt-2" variants={sectionHeaderVariants}>
            <category.icon className={cn("h-6 w-6 opacity-85", category.color)} />
            <h3 className="text-xl font-semibold text-foreground">{category.title}</h3>
          </motion.div>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6"
            initial="hidden"
            animate="visible"
            variants={{ visible: { transition: { staggerChildren: 0.05 }}}}
          >
            {category.apis.map((entry, index) => {
              const isLoading = activeTests[entry.name];
              return (
                <motion.div key={`${entry.name}-${index}`} variants={cardVariants} custom={index}>
                  <Card className="api-profile-card h-full flex flex-col p-0.5 frosty-glass">
                    <CardHeader className="pb-2 pt-4 px-4">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-sm font-semibold text-foreground leading-tight">{entry.name}</CardTitle>
                        {getStatusBadge(entry)}
                      </div>
                      {entry.type && <p className="text-xs text-muted-foreground">{entry.type}</p>}
                    </CardHeader>
                    <CardContent className="px-4 flex-grow">
                      {entry.id_or_value && (
                         <div className="mb-1.5">
                            <p className="text-[10px] text-muted-foreground font-medium">ID/Value:</p>
                            <p className="text-[11px] text-foreground break-all bg-muted/50 p-1.5 rounded-sm">{entry.id_or_value}</p>
                         </div>
                      )}
                      {entry.description && <p className="text-[11px] text-muted-foreground leading-relaxed">{entry.description}</p>}
                    </CardContent>
                    <CardFooter className="pt-3 mt-auto border-t border-border/50 px-4 pb-3">
                      <Button size="sm" className="w-full shadcn-button h-8 text-xs" onClick={() => testApiEntry(entry.name, entry.type || 'Entry')} disabled={isLoading}>
                        {isLoading ? (
                          <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-primary-foreground mr-1.5"></div>
                        ) : (
                          <Activity className="h-3 w-3 mr-1.5 opacity-70" />
                        )}
                        {isLoading ? 'Testing...' : 'Test Entry'}
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.section>
      ))}
    </div>
  );
}
