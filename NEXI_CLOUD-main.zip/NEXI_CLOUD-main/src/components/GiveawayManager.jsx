import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Gift, PlusCircle, Edit3, Trash2, Users, Link2, Clock, Share2, AlertTriangle, Image as ImageIcon, Music, PlayCircle } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialGiveawayCampaign = {
  id: '',
  name: 'New Giveaway',
  giveawayItem: '$25 Dental Card',
  entryMethod: 'reply_sms', // reply_sms, click_link
  referralEnabled: false,
  referralText: 'Send this to 3 friends & win!',
  referralReward: 'Extra Entry',
  countdownDurationHours: 48,
  richContentType: 'none', // image, audio, none
  richContentUrl: '',
  status: 'Draft'
};

export function GiveawayManager() {
  const [campaigns, setCampaigns] = useState([]);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [currentConfig, setCurrentConfig] = useState({...initialGiveawayCampaign});

  const handleInputChange = (field, value) => {
    setCurrentConfig(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSaveCampaign = () => {
    let campaignToSave = {...currentConfig};
    if (!campaignToSave.id) campaignToSave.id = `giv_${Date.now()}`;
    
    const existingIndex = campaigns.findIndex(c => c.id === campaignToSave.id);
    if (existingIndex > -1) {
      setCampaigns(campaigns.map(c => c.id === campaignToSave.id ? campaignToSave : c));
    } else {
      setCampaigns([...campaigns, campaignToSave]);
    }
    setSelectedCampaign(campaignToSave);
    // toast for success
  };

  const handleNewCampaign = () => {
    setSelectedCampaign(null);
    setCurrentConfig({...initialGiveawayCampaign, id: `giv_${Date.now()}`});
  };

  const handleSelectCampaign = (campaign) => {
    setSelectedCampaign(campaign);
    setCurrentConfig(campaign);
  };
  
  const handleDeleteCampaign = (campaignId) => {
    setCampaigns(prev => prev.filter(c => c.id !== campaignId));
    if (selectedCampaign && selectedCampaign.id === campaignId) {
      handleNewCampaign();
    }
    // toast for deletion
  };

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Gift className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Giveaway & Viral Promo Manager
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Launch exciting giveaways with referral loops to boost engagement. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        <motion.div variants={itemVariants} className="lg:col-span-1 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3 flex flex-row justify-between items-center">
              <CardTitle className="text-lg font-semibold text-foreground">Giveaway Campaigns</CardTitle>
              <Button size="sm" variant="outline" onClick={handleNewCampaign} className="shadcn-button"><PlusCircle className="h-4 w-4 mr-1.5" /> New</Button>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-2.5 max-h-[calc(100vh-350px)] overflow-y-auto scrollbar-hide">
              {campaigns.length === 0 ? <p className="text-xs text-muted-foreground text-center py-4">No giveaway campaigns created yet.</p> : campaigns.map(c => (
                <div key={c.id} className={`p-2.5 rounded-md border cursor-pointer ${selectedCampaign?.id === c.id ? 'bg-primary/10 border-primary/50' : 'bg-muted/30 hover:bg-muted/50 border-transparent'}`} onClick={() => handleSelectCampaign(c)}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-foreground">{c.name}</span>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={(e) => {e.stopPropagation(); handleDeleteCampaign(c.id)}}><Trash2 size={12}/></Button>
                    </div>
                  </div>
                  <p className="text-[11px] text-muted-foreground">Item: {c.giveawayItem} - Status: {c.status}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
             <CardHeader className="px-5 pt-5 pb-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    {selectedCampaign ? <Edit3 className="h-5 w-5 text-primary" /> : <PlusCircle className="h-5 w-5 text-primary" />}
                    <CardTitle className="text-lg font-semibold text-foreground">{selectedCampaign ? `Edit: ${currentConfig.name}` : 'Create Giveaway Campaign'}</CardTitle>
                </div>
                <Button onClick={handleSaveCampaign} className="shadcn-button" size="sm"><PlusCircle className="h-4 w-4 mr-1.5"/> Save Campaign</Button>
              </div>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
              <div>
                <Label htmlFor="givName" className="text-xs">Campaign Name</Label>
                <Input id="givName" value={currentConfig.name} onChange={e => handleInputChange('name', e.target.value)} className="shadcn-input mt-1 text-sm" />
              </div>
              <div>
                <Label htmlFor="givItem" className="text-xs">Giveaway Item</Label>
                <Input id="givItem" value={currentConfig.giveawayItem} onChange={e => handleInputChange('giveawayItem', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="e.g., $50 Amazon Gift Card" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="givEntryMethod" className="text-xs">Entry Method</Label>
                  <Select value={currentConfig.entryMethod} onValueChange={val => handleInputChange('entryMethod', val)}>
                    <SelectTrigger id="givEntryMethod" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent className="shadcn-select-content">
                      <SelectItem value="reply_sms" className="shadcn-select-item">Reply YES to SMS</SelectItem>
                      <SelectItem value="click_link" className="shadcn-select-item">Click Link & Enter Email</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="givCountdown" className="text-xs">Countdown (Hours)</Label>
                  <Input id="givCountdown" type="number" value={currentConfig.countdownDurationHours} onChange={e => handleInputChange('countdownDurationHours', parseInt(e.target.value) || 0)} className="shadcn-input mt-1 text-sm" />
                </div>
              </div>
              <div className="flex items-center space-x-2 pt-1">
                <Checkbox id="givReferralEnabled" checked={currentConfig.referralEnabled} onCheckedChange={checked => handleInputChange('referralEnabled', checked)} />
                <Label htmlFor="givReferralEnabled" className="text-xs font-normal">Enable Viral Loop (Referrals)</Label>
              </div>
              {currentConfig.referralEnabled && (
                 <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} transition={{duration:0.3}} className="pl-3 border-l-2 border-primary/30 space-y-2">
                  <div>
                    <Label htmlFor="givReferralText" className="text-xs">Referral Message</Label>
                    <Textarea id="givReferralText" value={currentConfig.referralText} onChange={e => handleInputChange('referralText', e.target.value)} className="shadcn-input mt-1 text-sm min-h-[50px]" placeholder="e.g., Share with 3 friends to triple your chances!"/>
                  </div>
                  <div>
                    <Label htmlFor="givReferralReward" className="text-xs">Referral Reward</Label>
                    <Input id="givReferralReward" value={currentConfig.referralReward} onChange={e => handleInputChange('referralReward', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="e.g., Extra Entry, Small Discount"/>
                  </div>
                 </motion.div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="givRichContentType" className="text-xs">Rich Content (RCS/MMS)</Label>
                  <Select value={currentConfig.richContentType} onValueChange={val => handleInputChange('richContentType', val)}>
                    <SelectTrigger id="givRichContentType" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent className="shadcn-select-content">
                      <SelectItem value="none" className="shadcn-select-item">None</SelectItem>
                      <SelectItem value="image" className="shadcn-select-item">Image / GIF</SelectItem>
                      <SelectItem value="audio" className="shadcn-select-item">Audio Clip</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {currentConfig.richContentType !== 'none' && (
                  <div>
                    <Label htmlFor="givRichContentUrl" className="text-xs">Content URL or Upload (Mock)</Label>
                     <div className="flex items-center gap-2 mt-1">
                      <Input id="givRichContentUrl" value={currentConfig.richContentUrl} onChange={e => handleInputChange('richContentUrl', e.target.value)} className="shadcn-input text-sm flex-grow" placeholder="https://example.com/image.gif"/>
                      <Button variant="outline" size="icon" className="shadcn-button h-9 w-9">
                        {currentConfig.richContentType === 'image' ? <ImageIcon size={14}/> : <Music size={14}/>}
                      </Button>
                     </div>
                  </div>
                )}
              </div>
               <div className="flex gap-2 pt-2">
                <Button variant="outline" className="w-full shadcn-button text-xs" onClick={() => handleInputChange('status', 'Active')} disabled={currentConfig.status === 'Active'}>
                    <PlayCircle size={14} className="mr-2"/> Launch Giveaway
                </Button>
                <Button variant="outline" className="w-full shadcn-button text-xs" onClick={() => handleInputChange('status', 'Paused')} disabled={currentConfig.status !== 'Active'}>
                    <Clock size={14} className="mr-2"/> Pause Giveaway
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
       <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Promotional Engagement Module</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This manager helps design dynamic giveaway campaigns. Actual execution, tracking referrals, and delivering rich content (RCS/MMS audio) requires backend logic for messaging APIs and potentially unique link generation.
            </p>
        </div>
      </motion.div>
    </div>
  );
}