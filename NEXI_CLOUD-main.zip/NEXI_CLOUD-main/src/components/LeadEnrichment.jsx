import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sparkles, UserCheck, ShieldCheck, AlertTriangle, UploadCloud, Play, Database, RotateCcw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

export function LeadEnrichment() {
  const [processing, setProcessing] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const [results, setResults] = React.useState(null);

  const handleProcessLeads = () => {
    setProcessing(true);
    setProgress(0);
    setResults(null);

    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 10;
      if (currentProgress <= 100) {
        setProgress(currentProgress);
      } else {
        clearInterval(interval);
        setProcessing(false);
        setResults({
          totalLeads: 250,
          enriched: 180,
          sanitized: 235,
          duplicatesRemoved: 15,
          errors: 5,
        });
      }
    }, 300);
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Sparkles className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Lead Enrichment & Sanitizer
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Cleanse, validate, and enrich your contact lists for better campaign performance. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay:0.1, ease: "circOut" }}
        className="flex-grow space-y-8"
      >
        <Card className="frosty-glass p-0.5">
          <CardHeader className="px-5 pt-5 pb-3">
            <CardTitle className="text-lg font-semibold text-foreground">Upload Lead List</CardTitle>
            <CardDescription className="text-sm">Upload a CSV or connect a data source for processing.</CardDescription>
          </CardHeader>
          <CardContent className="px-5 pb-5 space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
                <Button variant="outline" className="shadcn-button flex-1">
                    <UploadCloud className="h-4 w-4 mr-2"/> Upload CSV (Mock)
                </Button>
                 <Button variant="outline" className="shadcn-button flex-1">
                    <Database className="h-4 w-4 mr-2"/> Connect Data Source (Mock)
                </Button>
            </div>
            <div className="pt-2">
                <Button onClick={handleProcessLeads} disabled={processing} className="shadcn-button w-full sm:w-auto">
                    {processing ? <RotateCcw className="h-4 w-4 mr-2 animate-spin"/> : <Play className="h-4 w-4 mr-2"/>}
                    {processing ? 'Processing Leads...' : 'Start Enrichment & Sanitization (Mock)'}
                </Button>
            </div>
          </CardContent>
        </Card>

        {processing && (
            <motion.div initial={{opacity:0}} animate={{opacity:1}}>
                 <Card className="frosty-glass p-0.5">
                    <CardContent className="p-5">
                        <p className="text-sm font-medium text-center mb-2">Processing your lead list...</p>
                        <Progress value={progress} className="h-2 bg-muted/60" indicatorClassName="bg-primary"/>
                        <p className="text-xs text-center text-muted-foreground mt-1.5">{progress}% complete</p>
                    </CardContent>
                </Card>
            </motion.div>
        )}

        {results && (
             <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}}>
                <Card className="frosty-glass p-0.5">
                    <CardHeader className="px-5 pt-5 pb-2">
                         <CardTitle className="text-lg font-semibold text-foreground">Processing Results (Mock)</CardTitle>
                    </CardHeader>
                    <CardContent className="px-5 pb-5 grid grid-cols-2 md:grid-cols-3 gap-4">
                        <div className="p-3 bg-primary/5 rounded-md">
                            <p className="text-xs text-muted-foreground">Total Leads Processed</p>
                            <p className="text-xl font-bold text-primary">{results.totalLeads}</p>
                        </div>
                         <div className="p-3 bg-green-500/5 rounded-md">
                            <p className="text-xs text-muted-foreground flex items-center"><UserCheck className="h-3.5 w-3.5 mr-1 text-green-600"/> Leads Enriched</p>
                            <p className="text-xl font-bold text-green-600">{results.enriched}</p>
                        </div>
                         <div className="p-3 bg-sky-500/5 rounded-md">
                            <p className="text-xs text-muted-foreground flex items-center"><ShieldCheck className="h-3.5 w-3.5 mr-1 text-sky-600"/>Leads Sanitized</p>
                            <p className="text-xl font-bold text-sky-600">{results.sanitized}</p>
                        </div>
                         <div className="p-3 bg-amber-500/5 rounded-md">
                            <p className="text-xs text-muted-foreground">Duplicates Removed</p>
                            <p className="text-xl font-bold text-amber-600">{results.duplicatesRemoved}</p>
                        </div>
                         <div className="p-3 bg-red-500/5 rounded-md">
                            <p className="text-xs text-muted-foreground">Validation Errors</p>
                            <p className="text-xl font-bold text-red-600">{results.errors}</p>
                        </div>
                    </CardContent>
                </Card>
             </motion.div>
        )}
        
        <div className="mt-auto pt-6">
            <div className="p-3 frosty-glass rounded-md">
                <div className="flex items-center gap-1.5">
                    <AlertTriangle className="h-4 w-4 text-amber-500"/>
                    <h4 className="font-semibold text-foreground text-xs">Conceptual Mockup</h4>
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                    This Lead Enrichment & Sanitizer board is a conceptual representation. 
                    Actual implementation would involve integration with third-party enrichment APIs (e.g., Clearbit, ZoomInfo) and robust data validation logic.
                </p>
            </div>
        </div>
      </motion.div>
    </div>
  );
}