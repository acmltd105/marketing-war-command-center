
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, UserCheck, ShieldCheck, AlertTriangle, UploadCloud, Play, Database, RotateCcw, SearchCode, Link as LinkIcon, Bot, ExternalLink } from 'lucide-react'; // Added ExternalLink
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/components/ui/use-toast';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};


function LeadEnrichmentSection() {
  const [processing, setProcessing] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const [results, setResults] = React.useState(null);

  const handleProcessLeads = () => {
    setProcessing(true);
    setProgress(0);
    setResults(null);

    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 10;
      if (currentProgress <= 100) {
        setProgress(currentProgress);
      } else {
        clearInterval(interval);
        setProcessing(false);
        setResults({
          totalLeads: 250,
          enriched: 180,
          sanitized: 235,
          duplicatesRemoved: 15,
          errors: 5,
        });
      }
    }, 300);
  };

  return (
    <motion.div 
      variants={itemVariants}
      className="space-y-6"
    >
      <Card className="frosty-glass p-0.5">
        <CardHeader className="px-5 pt-5 pb-3">
          <CardTitle className="text-lg font-semibold text-foreground">Upload Lead List</CardTitle>
          <CardDescription className="text-sm">Upload a CSV or connect a data source for processing.</CardDescription>
        </CardHeader>
        <CardContent className="px-5 pb-5 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
              <Button variant="outline" className="shadcn-button flex-1">
                  <UploadCloud className="h-4 w-4 mr-2"/> Upload CSV (Mock)
              </Button>
                <Button variant="outline" className="shadcn-button flex-1">
                  <Database className="h-4 w-4 mr-2"/> Connect Data Source (Mock)
              </Button>
          </div>
          <div className="pt-2">
              <Button onClick={handleProcessLeads} disabled={processing} className="shadcn-button w-full sm:w-auto">
                  {processing ? <RotateCcw className="h-4 w-4 mr-2 animate-spin"/> : <Play className="h-4 w-4 mr-2"/>}
                  {processing ? 'Processing Leads...' : 'Start Enrichment & Sanitization (Mock)'}
              </Button>
          </div>
        </CardContent>
      </Card>

      {processing && (
          <motion.div initial={{opacity:0}} animate={{opacity:1}}>
                <Card className="frosty-glass p-0.5">
                  <CardContent className="p-5">
                      <p className="text-sm font-medium text-center mb-2">Processing your lead list...</p>
                      <Progress value={progress} className="h-2 bg-muted/60" indicatorClassName="bg-primary"/>
                      <p className="text-xs text-center text-muted-foreground mt-1.5">{progress}% complete</p>
                  </CardContent>
              </Card>
          </motion.div>
      )}

      {results && (
            <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}}>
              <Card className="frosty-glass p-0.5">
                  <CardHeader className="px-5 pt-5 pb-2">
                        <CardTitle className="text-lg font-semibold text-foreground">Processing Results (Mock)</CardTitle>
                  </CardHeader>
                  <CardContent className="px-5 pb-5 grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="p-3 bg-primary/5 rounded-md">
                          <p className="text-xs text-muted-foreground">Total Leads Processed</p>
                          <p className="text-xl font-bold text-primary">{results.totalLeads}</p>
                      </div>
                        <div className="p-3 bg-green-500/5 rounded-md">
                          <p className="text-xs text-muted-foreground flex items-center"><UserCheck className="h-3.5 w-3.5 mr-1 text-green-600"/> Leads Enriched</p>
                          <p className="text-xl font-bold text-green-600">{results.enriched}</p>
                      </div>
                        <div className="p-3 bg-sky-500/5 rounded-md">
                          <p className="text-xs text-muted-foreground flex items-center"><ShieldCheck className="h-3.5 w-3.5 mr-1 text-sky-600"/>Leads Sanitized</p>
                          <p className="text-xl font-bold text-sky-600">{results.sanitized}</p>
                      </div>
                        <div className="p-3 bg-amber-500/5 rounded-md">
                          <p className="text-xs text-muted-foreground">Duplicates Removed</p>
                          <p className="text-xl font-bold text-amber-600">{results.duplicatesRemoved}</p>
                      </div>
                        <div className="p-3 bg-red-500/5 rounded-md">
                          <p className="text-xs text-muted-foreground">Validation Errors</p>
                          <p className="text-xl font-bold text-red-600">{results.errors}</p>
                      </div>
                  </CardContent>
              </Card>
            </motion.div>
      )}
    </motion.div>
  );
}

function BrowseAiSection() {
  const { toast } = useToast();
  const [robotName, setRobotName] = useState('');
  const [inputParameters, setInputParameters] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [runResults, setRunResults] = useState(null);

  const handleRunRobot = () => {
    if (!robotName) {
      toast({ title: "Robot Name Required", description: "Please enter a Browse.AI robot name or ID.", variant: "destructive"});
      return;
    }
    setIsRunning(true);
    setRunResults(null);
    // Simulate API call
    setTimeout(() => {
      setIsRunning(false);
      setRunResults({
        status: "Completed",
        itemsExtracted: Math.floor(Math.random() * 500) + 50,
        duration: (Math.random() * 5 + 1).toFixed(2) + " minutes",
        sampleData: [
          { field1: "Data A1", field2: "Data B1" },
          { field1: "Data A2", field2: "Data B2" },
        ]
      });
      toast({ title: "Browse.AI Robot Run (Mock)", description: `${robotName} finished processing.`});
    }, 3000);
  };

  return (
    <motion.div 
      variants={itemVariants}
      className="space-y-6"
    >
      <Card className="frosty-glass p-0.5">
        <CardHeader className="px-5 pt-5 pb-3">
          <CardTitle className="text-lg font-semibold text-foreground">Configure Browse.AI Robot</CardTitle>
          <CardDescription className="text-sm">Set up and run your Browse.AI robots to extract web data.</CardDescription>
        </CardHeader>
        <CardContent className="px-5 pb-5 space-y-4">
          <Input 
            className="shadcn-input" 
            placeholder="Browse.AI Robot Name or ID (e.g., 'LinkedIn Profile Scraper')" 
            value={robotName}
            onChange={(e) => setRobotName(e.target.value)}
          />
          <Input 
            className="shadcn-input" 
            placeholder="Input Parameters (JSON or URL Query String, optional)" 
            value={inputParameters}
            onChange={(e) => setInputParameters(e.target.value)}
          />
          <Button onClick={handleRunRobot} disabled={isRunning || !robotName} className="shadcn-button w-full sm:w-auto">
            {isRunning ? <RotateCcw className="h-4 w-4 mr-2 animate-spin"/> : <Play className="h-4 w-4 mr-2"/>}
            {isRunning ? 'Running Robot...' : 'Run Browse.AI Robot (Mock)'}
          </Button>
           <Button variant="outline" className="shadcn-button w-full sm:w-auto sm:ml-2" onClick={() => window.open('https://browse.ai', '_blank')}>
              <ExternalLink className="h-4 w-4 mr-2"/> Go to Browse.AI (External)
          </Button>
        </CardContent>
      </Card>

      {isRunning && (
        <motion.div initial={{opacity:0}} animate={{opacity:1}}>
            <Card className="frosty-glass p-0.5">
              <CardContent className="p-5 text-center">
                  <RotateCcw className="h-6 w-6 mx-auto mb-2 text-primary animate-spin"/>
                  <p className="text-sm font-medium">Browse.AI robot is processing...</p>
                  <p className="text-xs text-muted-foreground">This may take a few moments.</p>
              </CardContent>
          </Card>
        </motion.div>
      )}

      {runResults && (
        <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}}>
          <Card className="frosty-glass p-0.5">
              <CardHeader className="px-5 pt-5 pb-2">
                    <CardTitle className="text-lg font-semibold text-foreground">Browse.AI Run Results (Mock)</CardTitle>
              </CardHeader>
              <CardContent className="px-5 pb-5 space-y-3">
                  <p><Badge variant="outline" className="shadcn-badge">{runResults.status}</Badge></p>
                  <p className="text-sm">Items Extracted: <span className="font-semibold text-primary">{runResults.itemsExtracted}</span></p>
                  <p className="text-sm">Duration: <span className="font-semibold">{runResults.duration}</span></p>
                  <details className="text-xs">
                    <summary className="cursor-pointer hover:text-primary">View Sample Data (Mock)</summary>
                    <pre className="mt-1 p-2 bg-muted/50 rounded text-[10px] overflow-x-auto">
                      {JSON.stringify(runResults.sampleData, null, 2)}
                    </pre>
                  </details>
              </CardContent>
          </Card>
        </motion.div>
      )}
    </motion.div>
  );
}


export function LeadIntelHub() {
  const [activeTab, setActiveTab] = useState("enrichment");

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <SearchCode className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Lead Intelligence Hub
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Centralized tools for lead data acquisition, enrichment, and validation.
          </p>
        </div>
      </motion.header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-grow flex flex-col">
        <TabsList className="grid w-full grid-cols-2 gap-1 p-1 rounded-lg shadcn-tabs-list mb-4 md:mb-5">
            <TabsTrigger value="enrichment" className="py-2 text-xs sm:text-sm font-medium shadcn-tabs-trigger">
                <Sparkles className="w-3.5 h-3.5 mr-1.5 opacity-75" />
                Enrichment & Sanitizer
            </TabsTrigger>
            <TabsTrigger value="browse_ai" className="py-2 text-xs sm:text-sm font-medium shadcn-tabs-trigger">
                <Bot className="w-3.5 h-3.5 mr-1.5 opacity-75" />
                Browse.AI Integration
            </TabsTrigger>
        </TabsList>

        <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="flex-grow"
        >
            <TabsContent value="enrichment" className="h-full mt-0">
                <LeadEnrichmentSection />
            </TabsContent>
            <TabsContent value="browse_ai" className="h-full mt-0">
                <BrowseAiSection />
            </TabsContent>
        </motion.div>
      </Tabs>

      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Conceptual Modules</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                The features in this hub are conceptual mockups. Full implementation requires integration with third-party APIs (e.g., Clearbit, Browse.AI) and robust data validation logic.
            </p>
        </div>
      </motion.div>
    </div>
  );
}
