
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Sun, Moon, ChevronDown, Zap, Users, MessageSquare, BarChart, Youtube, BookOpen } from 'lucide-react';
import { useTheme } from '@/App';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuGroup } from '@/components/ui/dropdown-menu';
import { AutoSaveIndicator } from '@/components/AutoSaveIndicator';

const StatCard = ({ icon, value, label, color }) => (
  <div className="flex items-center gap-2">
    {React.cloneElement(icon, { className: `h-4 w-4 ${color}` })}
    <div>
      <p className="text-sm font-bold text-foreground">{value}</p>
      <p className="text-[10px] text-muted-foreground -mt-1">{label}</p>
    </div>
  </div>
);

const inspirationalLinks = [
    { name: "Steve Jobs - Stanford Commencement", url: "https://www.youtube.com/watch?v=UF8uR6Z6KLc" },
    { name: "Bill Gates - Harvard Commencement", url: "https://www.youtube.com/watch?v=z2eL-1a31SQL" },
    { name: "Travis Kalanick - The Story of Uber", url: "https://www.youtube.com/watch?v=pRunGg6kE5M" },
    { name: "Jeff Bezos - Princeton Commencement", url: "https://www.youtube.com/watch?v=B-6421g2V4g" },
    { name: "Elon Musk - USC Commencement", url: "https://www.youtube.com/watch?v=DxB4Aw-W9K4" },
];

export function LiveStatsHeader() {
  const { currentTheme, setTheme, themes } = useTheme();
  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setDateTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDate = (date) => {
    return date.toLocaleDateString(undefined, {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString();
  };

  const getThemeIcon = () => {
    if (currentTheme.includes('Dark') || currentTheme.includes('Night') || currentTheme.includes('dark') || currentTheme.includes('Deep') || currentTheme.includes('electric') || currentTheme.includes('Graphite')) {
      return <Moon className="h-4 w-4" />;
    }
    return <Sun className="h-4 w-4" />;
  };

  return (
    <motion.div
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 100, damping: 20, delay: 0.2 }}
      className="fixed top-0 left-0 right-0 h-[60px] bg-apple-input-bg/60 backdrop-blur-lg border-b border-apple-border z-40 flex items-center justify-between px-4 md:px-6"
    >
      <div className="flex items-center gap-4 md:gap-6">
        <div className="hidden md:flex items-center gap-4">
          <StatCard icon={<Zap />} value="1,204" label="Active Now" color="text-green-500" />
          <StatCard icon={<Users />} value="15,783" label="Leads Today" color="text-blue-500" />
          <StatCard icon={<MessageSquare />} value="89%" label="Engagement" color="text-purple-500" />
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        <div className="text-right hidden sm:block">
          <p className="text-xs font-medium text-foreground">{formatTime(dateTime)}</p>
          <p className="text-[10px] text-muted-foreground">{formatDate(dateTime)}</p>
        </div>
        
        <AutoSaveIndicator />

        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="outline" className="h-9 w-9 p-0">
                    <BookOpen className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="frosty-glass w-56">
                <DropdownMenuLabel>GET INSPIRED!</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                    {inspirationalLinks.map((link) => (
                        <DropdownMenuItem key={link.name} onSelect={() => window.open(link.url, '_blank')}>
                            <Youtube className="mr-2 h-4 w-4" />
                            <span>{link.name}</span>
                        </DropdownMenuItem>
                    ))}
                </DropdownMenuGroup>
            </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="h-9 w-9 p-0">
              {getThemeIcon()}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="frosty-glass">
            <DropdownMenuLabel>Switch Theme</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {Object.entries(themes).map(([key, theme]) => (
              <DropdownMenuItem key={key} onClick={() => setTheme(key)}>
                {theme.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </motion.div>
  );
}
