
import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle, Loader2 } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';

export function AutoSaveIndicator() {
  const { isSaving } = useAppContext();

  return (
    <div className="flex items-center justify-end text-xs text-muted-foreground h-6 w-36">
      <AnimatePresence mode="wait" initial={false}>
        {isSaving ? (
          <motion.div
            key="saving"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.2 }}
            className="flex items-center gap-1.5"
          >
            <Loader2 className="h-3.5 w-3.5 animate-spin text-blue-500" />
            <span>Saving...</span>
          </motion.div>
        ) : (
          <motion.div
            key="saved"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.2 }}
            className="flex items-center gap-1.5 text-green-500"
          >
            <CheckCircle className="h-3.5 w-3.5" />
            <span>Auto-saved to cloud</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
