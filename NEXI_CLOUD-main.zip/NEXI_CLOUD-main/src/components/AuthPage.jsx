import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/App';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from '@/components/ui/use-toast';
import { Loader2, LogIn, UserPlus, ShieldCheck, Phone, User } from 'lucide-react';
import { motion } from 'framer-motion';

export function AuthPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { setSession } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState(''); // For signup
  const [phoneNumber, setPhoneNumber] = useState(''); // For 2FA enrollment/login
  const [otp, setOtp] = useState(''); // For 2FA verification
  
  const [authMode, setAuthMode] = useState('login'); // 'login', 'signup', 'verify2fa'
  const [isLoading, setIsLoading] = useState(false);
  // const [showOtpInput, setShowOtpInput] = useState(false); // Managed by authMode now
  const [userIdFor2FA, setUserIdFor2FA] = useState(null);
  const [phoneFor2FA, setPhoneFor2FA] = useState('');


  const from = location.state?.from?.pathname || "/";

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      toast({ title: "Login Failed", description: error.message, variant: "destructive" });
      setIsLoading(false);
      return;
    } 
    
    if (data.user) {
      const userPhone = data.user.phone || data.user.user_metadata?.phone || phoneNumber;
      if (userPhone) {
        setUserIdFor2FA(data.user.id);
        setPhoneFor2FA(userPhone); // Store phone for OTP verification step
        await start2FAVerification(userPhone, data.user.id);
      } else {
        toast({ title: "Login Successful!", description: "Welcome back!" });
        setSession(data.session);
        navigate(from, { replace: true });
        setIsLoading(false);
      }
    } else {
      // Should not happen if no error, but as a fallback
      toast({ title: "Login Issue", description: "Could not retrieve user data.", variant: "destructive" });
      setIsLoading(false);
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const { data, error } = await supabase.auth.signUp({ 
      email, 
      password,
      options: {
        data: { // This data is stored in auth.users.raw_user_meta_data
          full_name: fullName,
          phone: phoneNumber, 
        }
      }
    });

    if (error) {
      toast({ title: "Signup Failed", description: error.message, variant: "destructive" });
      setIsLoading(false);
      return;
    } 
    
    if (data.user) {
      // If email confirmation is required, user object might be returned but session might be null.
      // Supabase handles this; user needs to confirm email.
      toast({ title: "Signup Successful!", description: "Please check your email to verify your account." });
      
      if (phoneNumber) { // If phone provided, proceed to 2FA
        setUserIdFor2FA(data.user.id);
        setPhoneFor2FA(phoneNumber);
        await start2FAVerification(phoneNumber, data.user.id);
      } else {
        // If no phone, user needs to verify email then can login.
        // Optionally, redirect to login or a specific "verify email" page.
        setAuthMode('login'); 
        setIsLoading(false);
      }
    } else {
       toast({ title: "Signup Issue", description: "Could not create user.", variant: "destructive" });
       setIsLoading(false);
    }
  };

  const start2FAVerification = async (targetPhoneNumber, userId) => {
    // setIsLoading(true) is already set by caller
    // Ensure phone number is in E.164 format
    const formattedPhoneNumber = targetPhoneNumber.startsWith('+') ? targetPhoneNumber : `+${targetPhoneNumber.replace(/\D/g, '')}`;
    setPhoneFor2FA(formattedPhoneNumber); // Store the formatted number

    try {
      const { data: functionData, error: functionError } = await supabase.functions.invoke('start-twilio-verify', {
        body: JSON.stringify({ to: formattedPhoneNumber, channel: 'sms', userId: userId })
      });

      if (functionError || functionData?.error) {
        throw new Error(functionError?.message || functionData?.error || "Failed to send OTP.");
      }
      
      toast({ title: "OTP Sent", description: `An OTP has been sent to ${formattedPhoneNumber}.` });
      setAuthMode('verify2fa'); 
    } catch (err) {
      toast({ title: "2FA Error", description: err.message, variant: "destructive" });
      // If OTP sending fails, maybe revert to login/signup form or show error message
      // For now, we stay on the current form, user might retry login/signup
    }
    setIsLoading(false); // Ensure loading is false after attempt
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    if(!userIdFor2FA || !phoneFor2FA) { // phoneFor2FA used for display/retry, userIdFor2FA for verification
        toast({ title: "Error", description: "User session or phone number not found for 2FA.", variant: "destructive"});
        setIsLoading(false);
        setAuthMode('login'); // Revert to login
        return;
    }

    try {
      // The check-twilio-verify function should ideally use the userId to fetch the associated phone
      // and then verify the OTP against Twilio's check.
      // Supabase doesn't directly link OTPs to users in its auth schema for Twilio Verify.
      // The Edge Function needs to handle this logic (e.g., by storing a temporary association or using Twilio Verify's internal state).
      const { data: functionData, error: functionError } = await supabase.functions.invoke('check-twilio-verify', {
        body: JSON.stringify({ userId: userIdFor2FA, code: otp, to: phoneFor2FA }) // Pass phoneFor2FA if your function needs it
      });
      
      if (functionError || functionData?.error || (functionData?.status && functionData.status !== 'approved')) {
         throw new Error(functionError?.message || functionData?.error || functionData?.message || "Invalid OTP.");
      }
      
      // If OTP is correct, the user's session from initial login/signup should become fully active.
      // We fetch the session again to confirm.
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
       if(sessionError || !sessionData.session){
           toast({ title: "Session Error", description: "Could not retrieve session after 2FA.", variant: "destructive"});
           setAuthMode('login'); // Revert to login on session error
       } else {
           toast({ title: "2FA Successful!", description: "You are now logged in." });
           setSession(sessionData.session);
           navigate(from, { replace: true });
       }

    } catch (err) {
      toast({ title: "OTP Verification Failed", description: err.message, variant: "destructive" });
    }
    setIsLoading(false);
  };

  const renderForm = () => {
    if (authMode === 'verify2fa') {
      return (
        <form onSubmit={handleVerifyOtp} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="otp" className="text-sm">Enter OTP sent to {phoneFor2FA}</Label>
            <Input 
              id="otp" 
              type="text" 
              value={otp} 
              onChange={(e) => setOtp(e.target.value)} 
              placeholder="123456" 
              required 
              className="shadcn-input"
            />
          </div>
          <Button type="submit" className="w-full shadcn-button" disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
            Verify OTP
          </Button>
           <Button variant="link" size="sm" onClick={() => { setAuthMode('login'); setIsLoading(false); /* Reset other states if needed */ }} className="w-full mt-2">
            Back to Login
          </Button>
        </form>
      );
    }

    return (
      <Tabs value={authMode} onValueChange={(newMode) => { setAuthMode(newMode); /* Clear fields if desired */ }} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="login">Login</TabsTrigger>
          <TabsTrigger value="signup">Sign Up</TabsTrigger>
        </TabsList>
        <TabsContent value="login">
          <form onSubmit={handleLogin} className="space-y-6 pt-4">
            <div className="space-y-2">
              <Label htmlFor="login-email">Email</Label>
              <Input id="login-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required className="shadcn-input" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="login-password">Password</Label>
              <Input id="login-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required className="shadcn-input" />
            </div>
             <div className="space-y-2">
              <Label htmlFor="login-phone">Phone for 2FA (If enrolled)</Label>
              <Input id="login-phone" type="tel" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="18144409068 (Optional)" className="shadcn-input" />
               <p className="text-xs text-muted-foreground">If 2FA is enabled, an OTP will be sent to your enrolled number or the one provided here.</p>
            </div>
            <Button type="submit" className="w-full shadcn-button" disabled={isLoading}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <LogIn className="mr-2 h-4 w-4" />}
              Login
            </Button>
          </form>
        </TabsContent>
        <TabsContent value="signup">
          <form onSubmit={handleSignup} className="space-y-6 pt-4">
             <div className="space-y-2">
              <Label htmlFor="signup-fullname">Full Name</Label>
              <Input id="signup-fullname" type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Your Name" required className="shadcn-input" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-email">Email</Label>
              <Input id="signup-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required className="shadcn-input" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-password">Password</Label>
              <Input id="signup-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Create a strong password" required className="shadcn-input" />
            </div>
             <div className="space-y-2">
              <Label htmlFor="signup-phone">Phone Number (for 2FA)</Label>
              <Input id="signup-phone" type="tel" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="18144409068 (e.g. +1XXXXXXXXXX)" required className="shadcn-input" />
               <p className="text-xs text-muted-foreground">An OTP will be sent to this number to verify your account.</p>
            </div>
            <Button type="submit" className="w-full shadcn-button" disabled={isLoading}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
              Sign Up
            </Button>
          </form>
        </TabsContent>
      </Tabs>
    );
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <motion.div
        initial={{ opacity: 0, y: -50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: "circOut" }}
      >
        <Card className="w-full max-w-md shadow-2xl frosty-glass border-purple-500/30">
          <CardHeader className="text-center">
            <div className="inline-block p-3 bg-purple-500/20 rounded-full mx-auto mb-3">
               {authMode === 'verify2fa' ? <ShieldCheck className="h-8 w-8 text-purple-400" /> : <User className="h-8 w-8 text-purple-400" />}
            </div>
            <CardTitle className="text-2xl font-bold text-foreground">
              {authMode === 'verify2fa' ? 'Verify Your Identity' : 'NEXIE Command Center Access'}
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              {authMode === 'verify2fa' 
                ? 'Enter the OTP sent to your phone.' 
                : 'Secure login or sign up to continue.'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {renderForm()}
          </CardContent>
        </Card>
      </motion.div>
      <motion.p 
        initial={{ opacity: 0, y:20 }}
        animate={{ opacity:1, y:0 }}
        transition={{ delay: 0.5, duration:0.5 }}
        className="text-center text-xs text-purple-300/70 mt-8"
      >
        &copy; {new Date().getFullYear()} NEXIE Cloud. All rights reserved.
      </motion.p>
    </div>
  );
}
