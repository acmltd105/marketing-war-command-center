import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { 
  Key as KeyIcon, 
  Activity, 
  Link as LinkIcon, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Search, 
  MessageSquare, 
  Headphones, 
  Server, 
  CloudCog, 
  Globe,
  Code,
  DollarSign,
  Wifi,
  Shield
} from 'lucide-react';
import { twilioApiLibrary } from '@/lib/twilioApiLibrary';

const cardVariants = {
  hidden: { opacity: 0, y: 25, scale: 0.96 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.035,
      duration: 0.4,
      ease: [0.2, 0.8, 0.2, 1]
    }
  })
};

const sectionHeaderVariants = {
  hidden: { opacity: 0, y: -15 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'circOut' } }
};

export function TwilioAPIs() {
  const [activeTests, setActiveTests] = useState({});
  const [apiKeys, setApiKeys] = useState({ accountSid: '', authToken: '' });
  const [searchTerm, setSearchTerm] = useState('');
  const [products, setProducts] = useState(twilioApiLibrary);

  const apiCategories = products.reduce((acc, product) => {
    const categoryTitle = product.category;
    if (!acc[categoryTitle]) {
      acc[categoryTitle] = {
        title: categoryTitle,
        icon: categoryTitle === "Channels" ? MessageSquare : 
              categoryTitle === "Engagement" ? Headphones :
              categoryTitle === "Platform" ? Server : 
              categoryTitle === "Connectivity" ? CloudCog : 
              categoryTitle === "Developer Tools" ? Code :
              categoryTitle === "Account & Billing" ? DollarSign :
              categoryTitle === "IoT" ? Wifi :
              categoryTitle === "Security" ? Shield :
              Globe,
        color: categoryTitle === "Channels" ? 'text-sky-500' : 
               categoryTitle === "Engagement" ? 'text-purple-500' :
               categoryTitle === "Platform" ? 'text-amber-500' :
               categoryTitle === "Connectivity" ? 'text-teal-500' :
               categoryTitle === "Developer Tools" ? 'text-blue-500' :
               categoryTitle === "Account & Billing" ? 'text-green-500' :
               categoryTitle === "IoT" ? 'text-pink-500' :
               categoryTitle === "Security" ? 'text-red-500' :
               'text-gray-500',
        apis: []
      };
    }
    acc[categoryTitle].apis.push(product);
    return acc;
  }, {});
  
  const filteredApiCategories = Object.entries(apiCategories).map(([key, category]) => ({
    ...category,
    apis: category.apis.filter(api => 
      api.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      api.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      api.category.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.apis.length > 0);

  const testAPI = async (apiName) => {
    const product = products.find(p => p.name === apiName);
    if (!product) return;

    if (!apiKeys.accountSid || !apiKeys.authToken) {
      toast({
        title: "Configuration Required",
        description: "Please enter Account SID and Auth Token before testing APIs.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    setActiveTests(prev => ({ ...prev, [apiName]: true }));
    toast({ title: "Testing API...", description: `Initiating test for ${apiName}.`, duration: 2000 });

    try {
      let response;
      const headers = {
        'Authorization': `Basic ${btoa(`${apiKeys.accountSid}:${apiKeys.authToken}`)}`
      };

      if (product.method === 'POST') {
        headers['Content-Type'] = 'application/x-www-form-urlencoded';
        const body = new URLSearchParams(product.body).toString();
        response = await fetch(product.url, {
          method: 'POST',
          headers,
          body
        });
      } else if (product.method === 'GET') {
        const url = product.url.replace('{PhoneNumber}', product.body?.To || '+18144409068');
        response = await fetch(url, { method: 'GET', headers });
      }

      const success = response.ok;
      const result = await response.json();

      setProducts(prev =>
        prev.map(p =>
          p.name === apiName
            ? { ...p, lastTestStatus: success ? 'success' : 'failed', lastTestDate: new Date().toISOString() }
            : p
        )
      );

      if (success) {
        toast({
          title: "API Test Successful",
          description: `${apiName} responded: ${result.sid || 'OK'}`,
          duration: 3000
        });
      } else {
        toast({
          title: "API Test Failed",
          description: `Status ${response.status}: ${result.message || 'Unknown error'}`,
          variant: "destructive",
          duration: 4000
        });
      }
    } catch (err) {
      toast({
        title: "API Error",
        description: err.message,
        variant: "destructive",
        duration: 4000
      });
    } finally {
      setActiveTests(prev => ({ ...prev, [apiName]: false }));
    }
  };

  const handleKeyChange = (e) => {
    setApiKeys(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const connectTwilio = () => {
    if (!apiKeys.accountSid || !apiKeys.authToken) {
      toast({ title: "Missing Credentials", description: "Please provide both Account SID and Auth Token.", variant: "destructive", duration: 3000});
      return;
    }
    toast({ title: "Credentials Stored (Session)", description: "Twilio credentials saved locally for this session.", duration: 3000});
  };

  const getStatusBadge = (status, product) => {
    if (product && product.lastTestStatus) {
      return product.lastTestStatus === 'success' ? (
        <Badge className="shadcn-badge bg-green-500/15 text-green-700">
          <CheckCircle className="h-3 w-3 mr-1 inline" />Tested OK
        </Badge>
      ) : (
        <Badge className="shadcn-badge bg-red-500/15 text-red-700">
          <AlertCircle className="h-3 w-3 mr-1 inline" />Test Failed
        </Badge>
      );
    }

    switch (status) {
      case 'operational':
        return <Badge className="shadcn-badge bg-green-500/15 text-green-700"><CheckCircle className="h-3 w-3 mr-1 inline" />Operational</Badge>;
      case 'degraded_performance':
        return <Badge className="shadcn-badge bg-yellow-500/15 text-yellow-700"><Clock className="h-3 w-3 mr-1 inline" />Degraded</Badge>;
      case 'error':
        return <Badge className="shadcn-badge bg-red-500/15 text-red-700"><AlertCircle className="h-3 w-3 mr-1 inline" />Error</Badge>;
      default:
        return <Badge className="shadcn-badge">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-10">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <h2 className="text-4xl font-semibold text-foreground">Twilio Products & APIs</h2>
        <p className="text-lg text-muted-foreground mt-1">Live test suite with full authentication and endpoint calls.</p>
      </motion.div>

      <motion.div variants={cardVariants} initial="hidden" animate="visible" custom={0}>
        <Card className="frosty-glass p-0.5">
          <CardHeader className="px-6 pt-6 pb-3">
            <CardTitle className="text-2xl font-semibold flex items-center gap-2.5 text-foreground"><KeyIcon className="h-5 w-5 text-primary opacity-90" />API Credentials</CardTitle>
            <CardDescription>Enter your Twilio Account SID and Auth Token. Stored locally for this session.</CardDescription>
          </CardHeader>
          <CardContent className="px-6 pb-6 space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="text-xs font-medium text-muted-foreground block">Account SID</label>
                <Input name="accountSid" value={apiKeys.accountSid} onChange={handleKeyChange} placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground block">Auth Token</label>
                <Input name="authToken" type="password" value={apiKeys.authToken} onChange={handleKeyChange} placeholder="••••••••••••••••••••••••••••••••" />
              </div>
            </div>
            <Button onClick={connectTwilio}><LinkIcon className="h-4 w-4 mr-2" />Connect Twilio Account</Button>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div className="relative">
        <Input type="text" placeholder="Search all Twilio products & APIs..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground opacity-60" />
      </motion.div>

      {filteredApiCategories.map((category, catIndex) => (
        <motion.section key={category.title} className="space-y-4" initial="hidden" animate="visible" variants={sectionHeaderVariants}>
          <motion.div className="flex items-center gap-2.5 pt-2">
            <category.icon className={`h-6 w-6 ${category.color} opacity-85`} />
            <h3 className="text-xl font-semibold text-foreground">{category.title}</h3>
          </motion.div>
          <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {category.apis.map((api, index) => {
              const ApiSpecificIcon = api.icon;
              const isLoading = activeTests[api.name];
              return (
                <motion.div key={api.name} variants={cardVariants} custom={index}>
                  <Card className="h-full flex flex-col p-0.5">
                    <CardHeader className="pb-2 pt-4 px-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <ApiSpecificIcon className={`h-4 w-4 ${category.color} opacity-75 mt-0.5`} />
                          <CardTitle className="text-sm font-semibold">{api.name}</CardTitle>
                        </div>
                        {getStatusBadge(api.status, api)}
                      </div>
                    </CardHeader>
                    <CardContent className="px-4 flex-grow">
                      <p className="text-[11px] text-muted-foreground">{api.description}</p>
                    </CardContent>
                    <CardFooter className="pt-3 mt-auto border-t border-border/50 px-4 pb-3">
                      <Button size="sm" className="w-full h-8 text-xs" onClick={() => testAPI(api.name)} disabled={isLoading}>
                        {isLoading ? (
                          <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-primary-foreground mr-1.5"></div>
                        ) : (
                          <Activity className="h-3 w-3 mr-1.5 opacity-70" />
                        )}
                        {isLoading ? 'Testing...' : 'Test API'}
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.section>
      ))}
    </div>
  );
}
