
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AudienceBuilder } from '@/components/audience/AudienceBuilder';
import { Send, Users, Edit, Clock, Zap, AlertCircle, Info, SlidersHorizontal } from 'lucide-react';
import { twilioNumberTypes, getThroughputInfo } from '@/lib/twilioThroughputs';
import { Slider } from '@/components/ui/slider';

const formVariants = {
  hidden: { opacity: 0, height: 0, y: -25 },
  visible: { opacity: 1, height: 'auto', y: 0, transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] } },
  exit: { opacity: 0, height: 0, y: -25, transition: { duration: 0.35, ease: [0.76, 0, 0.24, 1] } }
};

const mockHolidays = [
  { value: 'black_friday', label: 'Black Friday' },
  { value: 'cyber_monday', label: 'Cyber Monday' },
  { value: 'christmas', label: 'Christmas' },
  { value: 'new_year', label: 'New Year\'s Day' },
  { value: 'valentines', label: 'Valentine\'s Day' },
];

export function CampaignForm({ showForm, editingCampaign, formData, onInputChange, onSelectChange, onSubmit, onCancel, onAudienceUpdate }) {
  const [isAudienceModalOpen, setIsAudienceModalOpen] = useState(false);
  const [selectedNumberTypeInfo, setSelectedNumberTypeInfo] = useState(null);

  useEffect(() => {
    if (formData.sendingNumberType) {
      setSelectedNumberTypeInfo(getThroughputInfo(formData.sendingNumberType));
    } else {
      setSelectedNumberTypeInfo(null);
    }
  }, [formData.sendingNumberType]);

  const handleAudienceSave = (rules, count) => {
    onAudienceUpdate(rules, count);
    setIsAudienceModalOpen(false);
  };

  const calculateEstimatedDuration = () => {
    if (!formData.recipients || formData.recipients <= 0) return "N/A (No recipients)";
    
    const rates = [];
    if (formData.mpsRate && formData.mpsRate > 0) rates.push(formData.mpsRate);
    if (formData.mpmRate && formData.mpmRate > 0) rates.push(formData.mpmRate / 60);
    if (formData.mp10mRate && formData.mp10mRate > 0) rates.push(formData.mp10mRate / 600);
    if (formData.mphRate && formData.mphRate > 0) rates.push(formData.mphRate / 3600);

    if (rates.length === 0) {
        const defaultMps = selectedNumberTypeInfo?.defaultMps || 1;
        rates.push(defaultMps);
    }
    
    const effectiveMps = Math.min(...rates);
    if (effectiveMps <= 0) return "N/A (Invalid rate)";

    const totalSeconds = formData.recipients / effectiveMps;
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);

    let durationString = "";
    if (hours > 0) durationString += `${hours}h `;
    if (minutes > 0) durationString += `${minutes}m `;
    if (seconds > 0 || (hours === 0 && minutes === 0)) durationString += `${seconds}s`;
    
    return durationString.trim() || "Instant";
  };
  
  const estimatedDuration = useMemo(calculateEstimatedDuration, [
    formData.recipients, 
    formData.mpsRate, 
    formData.mpmRate, 
    formData.mp10mRate, 
    formData.mphRate,
    selectedNumberTypeInfo
  ]);

  const handleSliderChange = (value) => {
    onInputChange({ target: { name: 'mpsRate', value: value[0] } });
  };

  return (
    <AnimatePresence>
      {showForm && (
        <motion.div 
          key="campaign-form"
          variants={formVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          className="mb-6 md:mb-8 overflow-hidden"
        >
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 md:px-6 pt-5 md:pt-6 pb-4">
              <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">{editingCampaign ? 'Edit Campaign Details' : 'Create New Campaign'}</CardTitle>
              <CardDescription className="text-sm md:text-base">{editingCampaign ? `Modifying: ${editingCampaign.name}` : 'Define parameters for your new campaign.'}</CardDescription>
            </CardHeader>
            <CardContent className="px-5 md:px-6 pb-5 md:pb-6">
              <form onSubmit={onSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <Label htmlFor="campaignName" className="text-xs font-medium text-muted-foreground mb-1.5 block">Campaign Name *</Label>
                    <Input id="campaignName" name="name" className="shadcn-input" value={formData.name} onChange={onInputChange} placeholder="e.g., Q3 Product Promotion" />
                  </div>
                  <div>
                    <Label htmlFor="campaignType" className="text-xs font-medium text-muted-foreground mb-1.5 block">Campaign Type *</Label>
                    <Select name="type" value={formData.type} onValueChange={(val) => onSelectChange('type', val)}>
                      <SelectTrigger id="campaignType" className="shadcn-input"><SelectValue /></SelectTrigger>
                      <SelectContent className="shadcn-select-content">
                        <SelectItem value="sms" className="shadcn-select-item">SMS</SelectItem>
                        <SelectItem value="voice" className="shadcn-select-item">Voice Call</SelectItem>
                        <SelectItem value="email" className="shadcn-select-item">Email</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {formData.type === 'sms' && (
                  <div>
                    <Label htmlFor="senderId" className="text-xs font-medium text-muted-foreground mb-1.5 block">Sender ID *</Label>
                    <Input id="senderId" name="senderId" className="shadcn-input" value={formData.senderId} onChange={onInputChange} placeholder="e.g., MyCompany (max 11 chars or number)" />
                  </div>
                )}
                {formData.type === 'email' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                     <div>
                      <Label htmlFor="subject" className="text-xs font-medium text-muted-foreground mb-1.5 block">Subject Line *</Label>
                      <Input id="subject" name="subject" className="shadcn-input" value={formData.subject} onChange={onInputChange} placeholder="Your Email Subject" />
                    </div>
                    <div>
                      <Label htmlFor="senderEmail" className="text-xs font-medium text-muted-foreground mb-1.5 block">Sender Email *</Label>
                      <Input id="senderEmail" name="senderEmail" type="email" className="shadcn-input" value={formData.senderEmail} onChange={onInputChange} placeholder="e.g., marketing@example.com" />
                    </div>
                  </div>
                )}
                
                <div>
                  <Label htmlFor="messageContent" className="text-xs font-medium text-muted-foreground mb-1.5 block">Message Content / {formData.type === 'voice' ? 'Script' : 'Body'} *</Label>
                  <Textarea id="messageContent" name="message" className="shadcn-input" value={formData.message} onChange={onInputChange} placeholder={formData.type === 'email' ? "Enter email body content..." : "Enter SMS message or voice script..."} rows={formData.type === 'email' ? 6:4} />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3 border-t border-border/30">
                   <div>
                      <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">Audience *</Label>
                      <div className="p-3 rounded-lg bg-muted/50 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                           <Users className="h-5 w-5 text-primary"/>
                           <div>
                                <p className="font-bold text-lg text-primary leading-none">{formData.recipients?.toLocaleString() || 0}</p>
                                <p className="text-xs text-muted-foreground">Contacts</p>
                           </div>
                        </div>
                         <Dialog open={isAudienceModalOpen} onOpenChange={setIsAudienceModalOpen}>
                            <DialogTrigger asChild>
                                <Button variant="outline"><Edit size={14} className="mr-2"/>Define Audience</Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-[650px]">
                                <DialogHeader>
                                    <DialogTitle>Audience Segmentation</DialogTitle>
                                </DialogHeader>
                                <AudienceBuilder 
                                    initialRules={formData.segmentRules} 
                                    onSave={handleAudienceSave}
                                />
                            </DialogContent>
                        </Dialog>
                      </div>
                      {formData.segmentRules && formData.segmentRules.length > 0 ? (
                        <p className="text-[10px] text-muted-foreground mt-1.5">
                          Audience defined by {formData.segmentRules.length} rule(s).
                        </p>
                      ) : (
                        <p className="text-[10px] text-muted-foreground mt-1.5">
                          Click 'Define Audience' to set targeting rules and calculate count.
                        </p>
                      )}
                  </div>
                   <div>
                    <Label htmlFor="budget" className="text-xs font-medium text-muted-foreground mb-1.5 block">Allocated Budget ($)</Label>
                    <Input id="budget" name="budget" className="shadcn-input" type="number" step="10" value={formData.budget} onChange={onInputChange} placeholder="e.g., 1000" />
                  </div>
                </div>

                {/* Sending Configuration Section */}
                <div className="pt-4 border-t border-border/30">
                  <div className="flex items-center gap-2 mb-3">
                    <SlidersHorizontal className="h-5 w-5 text-primary" />
                    <h3 className="text-md font-semibold text-foreground">Sending Configuration & Throughput</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <Label htmlFor="sendingNumberType" className="text-xs font-medium text-muted-foreground mb-1.5 block">Sending Number/Channel Type</Label>
                      <Select name="sendingNumberType" value={formData.sendingNumberType || ''} onValueChange={(val) => onSelectChange('sendingNumberType', val)}>
                        <SelectTrigger id="sendingNumberType" className="shadcn-input"><SelectValue placeholder="Select number type..."/></SelectTrigger>
                        <SelectContent className="shadcn-select-content">
                          {twilioNumberTypes.map(type => (
                            <SelectItem key={type.value} value={type.value} className="shadcn-select-item">{type.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {selectedNumberTypeInfo && (
                        <div className="mt-1.5 p-2 bg-muted/30 rounded text-xs text-muted-foreground">
                          <p>Default MPS: <span className="font-semibold text-primary">{selectedNumberTypeInfo.defaultMps}</span> (Max: {selectedNumberTypeInfo.maxMps})</p>
                          <p className="text-[10px]">{selectedNumberTypeInfo.notes}</p>
                        </div>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="specificSendTime" className="text-xs font-medium text-muted-foreground mb-1.5 block">Specific Send Time (Optional)</Label>
                      <Input id="specificSendTime" name="specificSendTime" type="time" className="shadcn-input" value={formData.specificSendTime || ''} onChange={onInputChange} />
                       <p className="text-[10px] text-muted-foreground mt-1">Campaign will only send at/after this time (local).</p>
                    </div>
                  </div>

                  <div className="mt-4 space-y-3">
                    <div>
                      <Label htmlFor="mpsRate" className="text-xs font-medium text-muted-foreground mb-1.5 block">
                        Messages Per Second (MPS): <span className="font-bold text-primary">{formData.mpsRate || (selectedNumberTypeInfo?.defaultMps || 0)}</span>
                      </Label>
                      <Slider
                        id="mpsRate"
                        name="mpsRate"
                        min={0}
                        max={selectedNumberTypeInfo?.maxMps || 100}
                        step={selectedNumberTypeInfo?.value === 'us_short_code' ? 5 : 1}
                        defaultValue={[formData.mpsRate || selectedNumberTypeInfo?.defaultMps || 0]}
                        onValueChange={handleSliderChange}
                        className="my-2"
                        disabled={!selectedNumberTypeInfo}
                      />
                       <p className="text-[10px] text-muted-foreground">Adjust desired sending speed. Max based on selected number type.</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <Label htmlFor="mpmRate" className="text-xs font-medium text-muted-foreground">Messages/Minute</Label>
                        <Input id="mpmRate" name="mpmRate" type="number" className="shadcn-input mt-1 text-xs" value={formData.mpmRate || ''} onChange={onInputChange} placeholder={`e.g., ${(selectedNumberTypeInfo?.defaultMps || 1) * 60}`} />
                      </div>
                      <div>
                        <Label htmlFor="mp10mRate" className="text-xs font-medium text-muted-foreground">Messages/10 Mins</Label>
                        <Input id="mp10mRate" name="mp10mRate" type="number" className="shadcn-input mt-1 text-xs" value={formData.mp10mRate || ''} onChange={onInputChange} placeholder={`e.g., ${(selectedNumberTypeInfo?.defaultMps || 1) * 600}`} />
                      </div>
                      <div>
                        <Label htmlFor="mphRate" className="text-xs font-medium text-muted-foreground">Messages/Hour</Label>
                        <Input id="mphRate" name="mphRate" type="number" className="shadcn-input mt-1 text-xs" value={formData.mphRate || ''} onChange={onInputChange} placeholder={`e.g., ${(selectedNumberTypeInfo?.defaultMps || 1) * 3600}`} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 p-3 bg-primary/5 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-primary" />
                      <p className="text-xs font-medium text-foreground">Estimated Send Duration:</p>
                      <p className="text-sm font-bold text-primary">{estimatedDuration}</p>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-0.5">Based on recipient count and the most restrictive rate set.</p>
                  </div>
                </div>


                <div className="space-y-2 pt-3 border-t border-border/30">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="isTimedCampaign" name="isTimedCampaign" checked={formData.isTimedCampaign} onCheckedChange={(checked) => onSelectChange('isTimedCampaign', checked)} />
                      <Label htmlFor="isTimedCampaign" className="text-sm font-medium">This is a Timed/Holiday Campaign</Label>
                    </div>
                </div>

                {formData.isTimedCampaign && (
                  <motion.div 
                      initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} transition={{duration:0.3}}
                      className="space-y-5 pl-2 border-l-2 border-primary/40 ml-2"
                  >
                      <div>
                          <Label htmlFor="eventName" className="text-xs font-medium text-muted-foreground mb-1.5 block">Event/Promotion Name *</Label>
                          <Input id="eventName" name="eventName" className="shadcn-input" value={formData.eventName} onChange={onInputChange} placeholder="e.g., Black Friday Blowout"/>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                          <div>
                              <Label htmlFor="triggerType" className="text-xs font-medium text-muted-foreground mb-1.5 block">Trigger Type *</Label>
                              <Select name="triggerType" value={formData.triggerType} onValueChange={(val) => onSelectChange('triggerType', val)}>
                                  <SelectTrigger id="triggerType" className="shadcn-input"><SelectValue /></SelectTrigger>
                                  <SelectContent className="shadcn-select-content">
                                  <SelectItem value="specific_date" className="shadcn-select-item">Specific Date Range</SelectItem>
                                  <SelectItem value="holiday" className="shadcn-select-item">Holiday</SelectItem>
                                  </SelectContent>
                              </Select>
                          </div>
                          {formData.triggerType === 'holiday' && (
                              <div>
                                  <Label htmlFor="holidayType" className="text-xs font-medium text-muted-foreground mb-1.5 block">Holiday Type</Label>
                                  <Select name="holidayType" value={formData.holidayType} onValueChange={(val) => onSelectChange('holidayType', val)}>
                                      <SelectTrigger id="holidayType" className="shadcn-input"><SelectValue placeholder="Select Holiday"/></SelectTrigger>
                                      <SelectContent className="shadcn-select-content">
                                      {mockHolidays.map(h => <SelectItem key={h.value} value={h.value} className="shadcn-select-item">{h.label}</SelectItem>)}
                                      </SelectContent>
                                  </Select>
                              </div>
                          )}
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                          <div>
                              <Label htmlFor="startDate" className="text-xs font-medium text-muted-foreground mb-1.5 block">Start Date *</Label>
                              <Input id="startDate" name="startDate" className="shadcn-input" type="date" value={formData.startDate} onChange={onInputChange} />
                          </div>
                          <div>
                              <Label htmlFor="endDate" className="text-xs font-medium text-muted-foreground mb-1.5 block">End Date *</Label>
                              <Input id="endDate" name="endDate" className="shadcn-input" type="date" value={formData.endDate} onChange={onInputChange} />
                          </div>
                      </div>
                  </motion.div>
                )}
                 <div className="grid grid-cols-1">
                  <div>
                    <Label htmlFor="scheduledAt" className="text-xs font-medium text-muted-foreground mb-1.5 block">Scheduled Start Date/Time</Label>
                    <Input id="scheduledAt" name="scheduledAt" className="shadcn-input" type="datetime-local" value={formData.scheduledAt} onChange={onInputChange} disabled={formData.isTimedCampaign}/>
                    {formData.isTimedCampaign && <p className="text-[10px] text-muted-foreground mt-1">Regular scheduling disabled. Campaign will run between the Start and End dates defined above.</p>}
                  </div>
                </div>

                <div className="flex gap-3 pt-3">
                  <Button type="submit" className="shadcn-button">
                    <Send className="w-4 h-4 mr-2"/>
                    {editingCampaign ? 'Save Changes' : 'Create Campaign'}
                  </Button>
                  <Button type="button" variant="outline" className="shadcn-button" onClick={onCancel}>Cancel</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
