
import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, MessageSquare as MessageSquareText, Zap, BarChart, PhoneCall, TrendingUp, Target, AlertTriangle, Clock } from 'lucide-react';
import { getThroughputInfo } from '@/lib/twilioThroughputs';

const StatCard = ({ title, value, icon: Icon, unit, trend, helpText }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "circOut" }}
      className="frosty-glass p-0.5 rounded-lg flex-1 min-w-[160px]"
    >
      <Card className="h-full bg-card/50">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1.5 pt-3 px-4">
          <CardTitle className="text-xs font-medium text-muted-foreground">{title}</CardTitle>
          <Icon className="h-4 w-4 text-muted-foreground opacity-70" />
        </CardHeader>
        <CardContent className="pb-3 px-4">
          <div className="text-xl font-bold text-primary">{value?.toLocaleString() || '0'}</div>
          {unit && <p className="text-[10px] text-muted-foreground">{unit}</p>}
          {trend !== undefined && (
            <div className={`text-[10px] flex items-center ${trend > 0 ? 'text-green-500' : trend < 0 ? 'text-red-500' : 'text-muted-foreground'}`}>
              <TrendingUp size={10} className={`mr-0.5 ${trend < 0 ? 'transform rotate-180' : ''} ${trend === 0 ? 'opacity-50': ''}`} />
              {trend > 0 ? '+' : ''}{trend.toFixed(1)}%
            </div>
          )}
          {helpText && <p className="text-[9px] text-muted-foreground/70 mt-0.5">{helpText}</p>}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export function CampaignStatsTicker({ campaigns }) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const activeCampaignsData = useMemo(() => {
    if (!campaigns) return { currentMps: 0, currentMpm: 0, queuedMessages: 0, activeCampaignsCount: 0 };

    let totalMps = 0;
    let totalMpm = 0;
    let totalQueued = 0;
    let activeCount = 0;

    campaigns.forEach(campaign => {
      if (campaign.status === 'active') {
        activeCount++;
        const numberTypeInfo = campaign.sendingNumberType ? getThroughputInfo(campaign.sendingNumberType) : null;
        const mps = campaign.mpsRate || numberTypeInfo?.defaultMps || 0;
        const mpm = campaign.mpmRate || mps * 60;
        
        totalMps += mps;
        totalMpm += mpm;
        totalQueued += Math.max(0, (campaign.recipients || 0) - (campaign.delivered || 0));
      }
    });
    return { currentMps: totalMps, currentMpm: totalMpm, queuedMessages: totalQueued, activeCampaignsCount: activeCount };
  }, [campaigns]);


  return (
    <motion.div 
      className="mb-6 md:mb-8"
      initial={{ opacity: 0, y: -15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1, ease: "circOut" }}
    >
      <div className="flex flex-wrap gap-3 md:gap-4">
        <StatCard title="Active Campaigns" value={activeCampaignsData.activeCampaignsCount} icon={Target} unit="Currently Running" />
        <StatCard title="Current MPS" value={activeCampaignsData.currentMps} icon={Zap} unit="Aggregate Messages/Sec" helpText="Sum of active campaign rates" />
        <StatCard title="Current MPM" value={activeCampaignsData.currentMpm} icon={MessageSquareText} unit="Aggregate Messages/Min" />
        <StatCard title="Outbound Queue" value={activeCampaignsData.queuedMessages} icon={BarChart} unit="Total Messages Pending" helpText="Conceptual - requires backend" />
        <StatCard title="System Time" value={currentTime.toLocaleTimeString()} icon={Clock} unit={currentTime.toLocaleDateString(undefined, { weekday: 'short' })} />
      </div>
    </motion.div>
  );
}
