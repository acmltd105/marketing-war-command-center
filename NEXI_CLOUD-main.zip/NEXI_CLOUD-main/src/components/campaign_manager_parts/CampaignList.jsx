import React from 'react';
import { motion } from 'framer-motion';
import { CampaignCard } from '@/components/campaign_manager_parts/CampaignCard';
import { Button } from '@/components/ui/button';
import { FileText, Plus } from 'lucide-react';

export function CampaignList({ campaigns, filter, onEdit, onStatusChange, onDelete, onNewCampaignClick }) {
  if (campaigns.length === 0) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 15 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="text-center py-16 md:py-20 border-2 border-dashed border-border/50 rounded-lg frosty-glass"
      >
        <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-5 opacity-60" />
        <h3 className="text-xl font-semibold text-foreground mb-2.5">No Campaigns Found</h3>
        <p className="text-base text-muted-foreground mb-6 max-w-md mx-auto">
          There are no campaigns matching the current filter "{filter}". <br/> Try adjusting the filter or create a new campaign to get started.
        </p>
        <Button className="shadcn-button" onClick={onNewCampaignClick}>
          <Plus className="h-5 w-5 mr-2" />
          Create First Campaign
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div 
      className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5 md:gap-6"
      initial="hidden"
      animate="visible"
      variants={{ visible: { transition: { staggerChildren: 0.06 } } }}
    >
      {campaigns.map((campaign, index) => (
        <CampaignCard 
          key={campaign.id} 
          campaign={campaign} 
          index={index}
          onEdit={onEdit}
          onStatusChange={onStatusChange}
          onDelete={onDelete}
        />
      ))}
    </motion.div>
  );
}