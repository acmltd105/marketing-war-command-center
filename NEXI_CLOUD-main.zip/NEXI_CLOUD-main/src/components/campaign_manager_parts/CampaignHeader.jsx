import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, ListFilter } from 'lucide-react';

export function CampaignHeader({ filter, setFilter, onNewCampaignClick }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "circOut" }}
      className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
    >
      <div>
        <h2 className="text-3xl md:text-4xl font-semibold text-foreground tracking-tight">Campaign Management</h2>
        <p className="text-base md:text-lg text-muted-foreground mt-1">Oversee, create, and manage all marketing campaigns, including timed promotions.</p>
      </div>
      <div className="flex gap-2.5 mt-3 sm:mt-0">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[190px] shadcn-input bg-card/70">
            <ListFilter className="h-4 w-4 mr-2 text-muted-foreground opacity-80" />
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent className="shadcn-select-content">
            <SelectItem value="all" className="shadcn-select-item">All Statuses</SelectItem>
            <SelectItem value="active" className="shadcn-select-item">Active</SelectItem>
            <SelectItem value="paused" className="shadcn-select-item">Paused</SelectItem>
            <SelectItem value="draft" className="shadcn-select-item">Draft</SelectItem>
            <SelectItem value="completed" className="shadcn-select-item">Completed</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={onNewCampaignClick} className="shadcn-button">
          <Plus className="h-4 w-4 mr-1.5" />
          New Campaign
        </Button>
      </div>
    </motion.div>
  );
}