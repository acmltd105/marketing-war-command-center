
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Play, Pause, Trash2, Edit, MessageSquare, Phone, Mail, Users, CalendarDays, DollarSign, Fingerprint, Type, AtSign, Clock, Tag, Filter, Zap, SlidersHorizontal
} from 'lucide-react';
import { getThroughputInfo } from '@/lib/twilioThroughputs';


const cardVariants = {
  hidden: { opacity: 0, y: 25, scale: 0.96 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.04,
      duration: 0.45,
      ease: [0.2, 0.8, 0.2, 1]
    }
  }),
  exit: { opacity: 0, y: -15, scale: 0.97, transition: { duration: 0.25, ease: "easeIn" } }
};

const mockHolidays = [
  { value: 'black_friday', label: 'Black Friday' },
  { value: 'cyber_monday', label: 'Cyber Monday' },
  { value: 'christmas', label: 'Christmas' },
  { value: 'new_year', label: 'New Year\'s Day' },
  { value: 'valentines', label: 'Valentine\'s Day' },
];

const getTypeIcon = (type) => {
  const iconMap = { sms: MessageSquare, voice: Phone, email: Mail };
  return iconMap[type] || MessageSquare;
};

export function CampaignCard({ campaign, index, onEdit, onStatusChange, onDelete }) {
  const TypeIcon = getTypeIcon(campaign.type);
  const statusStyles = {
    active: 'bg-green-500/15 text-green-700 border-green-500/30',
    paused: 'bg-yellow-500/15 text-yellow-700 border-yellow-500/30',
    draft: 'bg-gray-500/15 text-gray-600 border-gray-500/30',
    completed: 'bg-blue-500/15 text-blue-600 border-blue-500/30',
  };
  const hasSegmentRules = campaign.segmentRules && campaign.segmentRules.length > 0;
  const numberTypeInfo = campaign.sendingNumberType ? getThroughputInfo(campaign.sendingNumberType) : null;

  const getRateDisplay = () => {
    const rates = [];
    if (campaign.mpsRate) rates.push(`${campaign.mpsRate} MPS`);
    if (campaign.mpmRate) rates.push(`${campaign.mpmRate}/min`);
    if (campaign.mp10mRate) rates.push(`${campaign.mp10mRate}/10min`);
    if (campaign.mphRate) rates.push(`${campaign.mphRate}/hr`);
    if (rates.length > 0) return rates.join(' | ');
    if (numberTypeInfo) return `Default: ${numberTypeInfo.defaultMps} MPS`;
    return 'N/A';
  };

  const calculateEstimatedDuration = () => {
    if (!campaign.recipients || campaign.recipients <= 0 || campaign.status !== 'active') return null;
    
    const rates = [];
    if (campaign.mpsRate && campaign.mpsRate > 0) rates.push(campaign.mpsRate);
    if (campaign.mpmRate && campaign.mpmRate > 0) rates.push(campaign.mpmRate / 60);
    if (campaign.mp10mRate && campaign.mp10mRate > 0) rates.push(campaign.mp10mRate / 600);
    if (campaign.mphRate && campaign.mphRate > 0) rates.push(campaign.mphRate / 3600);

    if (rates.length === 0) {
        const defaultMps = numberTypeInfo?.defaultMps || 1;
        rates.push(defaultMps);
    }
    
    const effectiveMps = Math.min(...rates);
    if (effectiveMps <= 0) return "Invalid rate";

    const remainingRecipients = campaign.recipients - (campaign.delivered || 0);
    if (remainingRecipients <= 0) return "Completed";

    const totalSeconds = remainingRecipients / effectiveMps;
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    
    let durationString = "";
    if (hours > 0) durationString += `${hours}h `;
    if (minutes > 0) durationString += `${minutes}m `;
    if (hours === 0 && minutes === 0 && totalSeconds > 0) durationString += `<1m`;
    
    return durationString.trim() ? `~${durationString.trim()} left` : null;
  };
  const estimatedTimeLeft = calculateEstimatedDuration();


  return (
    <motion.div variants={cardVariants} custom={index}>
      <Card className="campaign-card h-full flex flex-col p-0.5">
        <CardHeader className="pb-3 pt-5 px-5">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <TypeIcon className={`h-5 w-5 opacity-80 ${campaign.type === 'sms' ? 'text-sky-500' : campaign.type === 'voice' ? 'text-green-600' : 'text-amber-500'}`} />
              <CardTitle className="text-base font-semibold text-foreground leading-tight">{campaign.isTimedCampaign ? campaign.eventName : campaign.name}</CardTitle>
            </div>
            <Badge variant="outline" className={`shadcn-badge capitalize ${statusStyles[campaign.status] || statusStyles.draft}`}>{campaign.status}</Badge>
          </div>
          {campaign.isTimedCampaign && <p className="text-[10px] text-primary mt-0.5">Timed Campaign: {campaign.name}</p>}
        </CardHeader>
        <CardContent className="space-y-2 text-xs px-5 flex-grow">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className={`h-3.5 w-3.5 opacity-70 ${hasSegmentRules ? 'text-primary' : ''}`} />
            <span>{campaign.recipients?.toLocaleString()} Recipients</span>
            {hasSegmentRules && <Badge variant="outline" className="text-[9px] px-1.5 py-0 border-primary/30 text-primary bg-primary/10"><Filter size={10} className="mr-1"/>Segmented</Badge>}
          </div>
          {campaign.type === 'sms' && campaign.senderId && <div className="flex items-center gap-2 text-muted-foreground"><Fingerprint className="h-3.5 w-3.5 opacity-70" /><span>Sender ID: {campaign.senderId}</span></div>}
          {campaign.type === 'email' && campaign.subject && <div className="flex items-center gap-2 text-muted-foreground"><Type className="h-3.5 w-3.5 opacity-70" /><span>Subject: {campaign.subject}</span></div>}
           {campaign.type === 'email' && campaign.senderEmail && <div className="flex items-center gap-2 text-muted-foreground"><AtSign className="h-3.5 w-3.5 opacity-70" /><span>From: {campaign.senderEmail}</span></div>}
          <div className="flex items-center gap-2 text-muted-foreground"><DollarSign className="h-3.5 w-3.5 opacity-70" /><span>Budget: ${campaign.budget > 0 ? campaign.budget?.toLocaleString() : 'N/A'}</span></div>
          
          {campaign.isTimedCampaign ? (
              <>
                  <div className="flex items-center gap-2 text-muted-foreground"><Clock className="h-3.5 w-3.5 opacity-70 text-blue-500" /><span>Duration: {new Date(campaign.startDate).toLocaleDateString()} - {new Date(campaign.endDate).toLocaleDateString()}</span></div>
                  {campaign.triggerType === 'holiday' && campaign.holidayType && <div className="flex items-center gap-2 text-muted-foreground"><Tag className="h-3.5 w-3.5 opacity-70 text-purple-500"/><span>Holiday: {mockHolidays.find(h=>h.value === campaign.holidayType)?.label || campaign.holidayType}</span></div>}
              </>
          ) : (
              <>
                  <div className="flex items-center gap-2 text-muted-foreground"><CalendarDays className="h-3.5 w-3.5 opacity-70" /><span>Created: {new Date(campaign.createdAt).toLocaleDateString()}</span></div>
                  {campaign.scheduledAt && <div className="flex items-center gap-2 text-muted-foreground"><CalendarDays className="h-3.5 w-3.5 opacity-70" /><span>Scheduled: {new Date(campaign.scheduledAt).toLocaleString([], {dateStyle: 'short', timeStyle: 'short'})}</span></div>}
              </>
          )}

          {campaign.type === 'sms' && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <SlidersHorizontal className="h-3.5 w-3.5 opacity-70 text-teal-500" />
              <span>{numberTypeInfo?.label || 'Custom Rate'}: {getRateDisplay()}</span>
            </div>
          )}
          {estimatedTimeLeft && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Zap className="h-3.5 w-3.5 opacity-70 text-orange-500" />
              <span>{estimatedTimeLeft}</span>
            </div>
          )}

          <p className="text-muted-foreground line-clamp-2 pt-1 text-[13px]">"{campaign.message || 'No message content provided.'}"</p>
        </CardContent>
        <CardFooter className="pt-4 mt-2 border-t border-border/60 flex gap-2 px-5 pb-4">
          <Button size="sm" variant={campaign.status === 'active' ? "outline" : "default"} className="flex-1 shadcn-button" onClick={() => onStatusChange(campaign.id, campaign.status)}>
            {campaign.status === 'active' ? <Pause className="h-3.5 w-3.5 mr-1.5" /> : <Play className="h-3.5 w-3.5 mr-1.5" />}
            {campaign.status === 'active' ? 'Pause' : (campaign.status === 'draft' ? 'Launch!' : 'Resume')}
          </Button>
          <Button size="sm" variant="outline" className="shadcn-button" onClick={() => onEdit(campaign)}><Edit className="h-3.5 w-3.5" /></Button>
          <Button size="sm" variant="destructive" className="shadcn-button bg-destructive/90 hover:bg-destructive" onClick={() => onDelete(campaign.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
