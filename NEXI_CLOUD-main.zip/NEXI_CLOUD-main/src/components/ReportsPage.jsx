import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/use-toast';
import { 
  History, TrendingUp, AlertTriangle, FileText, ListChecks, DollarSign, 
  MessageSquare, Phone, Mail, Users, Percent, CalendarDays, Filter, Download, BarChartHorizontalBig, Info, Briefcase, Smartphone, PieChart
} from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "circOut" } }
};

const StatCard = ({ title, value, icon: Icon, unit, trend, trendDirection, colorClass = 'text-primary' }) => (
  <motion.div variants={itemVariants}>
    <Card className="bg-card/60 p-4 shadow-sm hover:shadow-md transition-shadow duration-300 h-full flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-1">
          <p className="text-xs font-medium text-muted-foreground">{title}</p>
          {Icon && <Icon className={`h-4 w-4 ${colorClass} opacity-70`} />}
        </div>
        <p className="text-xl md:text-2xl font-bold text-foreground">{value}{unit && <span className="text-sm font-normal text-muted-foreground ml-0.5">{unit}</span>}</p>
      </div>
      {trend && (
        <p className={`text-[11px] mt-1.5 flex items-center ${trendDirection === 'up' ? 'text-green-600' : 'text-red-600'}`}>
          <TrendingUp className={`h-3 w-3 mr-0.5 ${trendDirection === 'down' ? 'transform rotate-180' : ''}`} />
          {trend}
        </p>
      )}
    </Card>
  </motion.div>
);

const DetailStatCard = ({ title, data, icon: Icon, colorClass = 'text-primary' }) => (
  <motion.div variants={itemVariants}>
    <Card className="bg-card/60 p-4 shadow-sm hover:shadow-md transition-shadow duration-300 h-full">
      <div className="flex items-center mb-2">
        {Icon && <Icon className={`h-5 w-5 ${colorClass} opacity-80 mr-2`} />}
        <h3 className="text-base font-semibold text-foreground">{title}</h3>
      </div>
      <div className="space-y-1.5 text-xs">
        {Object.entries(data).map(([key, val]) => {
          if (key === 'currency') return null;
          const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
          const displayValue = typeof val === 'number' && (key.toLowerCase().includes('rate') || key.toLowerCase().includes('avg')) ? 
                              (key.toLowerCase().includes('spend') || key.toLowerCase().includes('cost') ? `${data.currency || 'USD'} ${val.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}` : val.toLocaleString(undefined, {minimumFractionDigits: 1, maximumFractionDigits: 1}) + (key.toLowerCase().includes('rate') ? '%' : (key.toLowerCase().includes('duration') ? ' min' : '')))
                              : (key.toLowerCase().includes('spend') || key.toLowerCase().includes('cost') ? `${data.currency || 'USD'} ${val.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}` : (typeof val === 'number' ? val.toLocaleString() : val) );
          return (
            <div key={key} className="flex justify-between items-center">
              <span className="text-muted-foreground">{label}:</span>
              <span className="font-medium text-foreground">{displayValue}</span>
            </div>
          );
        })}
      </div>
    </Card>
  </motion.div>
);


export function ReportsPage({ reportsData, settingsData, updateReportFilters }) {
  const [currentFilters, setCurrentFilters] = useState(reportsData?.dataFilters || {});

  useEffect(() => {
    if (reportsData?.dataFilters) {
      setCurrentFilters(reportsData.dataFilters);
    }
  }, [reportsData?.dataFilters]);

  if (!reportsData || !settingsData) {
    return (
      <div className="p-4 sm:p-6 md:p-8 h-full flex items-center justify-center">
        <Card className="frosty-glass w-full max-w-lg text-center p-0.5">
          <CardHeader>
            <AlertTriangle className="h-16 w-16 text-destructive mx-auto mb-4" />
            <CardTitle className="text-2xl">Reporting Data Unavailable</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              There was an issue loading historic reporting data. Please check configurations or try again later.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { kpiOverview, detailedUsage, campaignPerformance, usageSummary, spendByService, dataFilters } = reportsData;
  const billingCurrency = settingsData.billing?.currency || 'USD';

  const handleFilterChange = (filterKey, value) => {
    const newFilters = { ...currentFilters, [filterKey]: value };
    setCurrentFilters(newFilters);
    if (typeof updateReportFilters === 'function') {
      updateReportFilters(newFilters);
    } else {
      console.warn("updateReportFilters function is not provided");
      toast({ title: "Filters Updated (Local)", description: "Filter changes are local, update function missing.", variant: "default" });
    }
  };
  
  const applyFilters = () => {
     toast({
        title: "Applying Filters (Mock)",
        description: "In a real scenario, this would fetch new data based on selected filters.",
        duration: 3000,
      });
  };

  return (
    <motion.div 
      className="p-4 sm:p-6 md:p-8 space-y-8 md:space-y-10 h-full overflow-y-auto selection:bg-primary/20"
      variants={sectionVariants}
      initial="hidden"
      animate="visible"
      exit="hidden"
    >
      <motion.div variants={itemVariants}>
        <div className="flex items-center justify-start">
          <History className="h-8 w-8 md:h-9 md:w-9 text-primary mr-2.5 md:mr-3 opacity-85" />
          <div>
            <h1 className="text-3xl md:text-4xl font-semibold text-foreground tracking-tight">Historic Reporting & Analytics</h1>
            <p className="text-base md:text-lg text-muted-foreground mt-1">
              Comprehensive insights into KPIs, spend, usage, and campaign effectiveness.
            </p>
          </div>
        </div>
      </motion.div>
      
      <motion.div variants={itemVariants} className="p-3.5 border border-blue-500/30 bg-blue-500/10 rounded-md flex items-start gap-2.5">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
          <p className="text-xs text-blue-700">
            <strong>Data Source:</strong> Currently displaying representative mock data. Live Twilio data and database integration (e.g., via Supabase) are pending.
          </p>
      </motion.div>

      {/* Filters Section */}
      <motion.div variants={sectionVariants} custom={1.5}>
        <Card className="frosty-glass p-0.5">
          <CardHeader className="pb-3 pt-5 px-5">
            <div className="flex items-center gap-2.5">
              <Filter className="h-5 w-5 text-primary opacity-90" />
              <CardTitle className="text-lg md:text-xl font-semibold text-foreground">Filter Data</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="px-5 pb-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <motion.div variants={itemVariants} className="space-y-1.5">
              <label htmlFor="dateRange" className="text-xs font-medium text-muted-foreground">Date Range</label>
              <Select value={currentFilters.dateRange} onValueChange={(value) => handleFilterChange('dateRange', value)}>
                <SelectTrigger id="dateRange" className="shadcn-input text-xs">
                  <SelectValue placeholder="Select date range" />
                </SelectTrigger>
                <SelectContent className="shadcn-select-content">
                  {dataFilters?.availableRanges?.map(range => <SelectItem key={range} value={range} className="shadcn-select-item text-xs">{range}</SelectItem>)}
                </SelectContent>
              </Select>
            </motion.div>
            <motion.div variants={itemVariants} className="space-y-1.5">
              <label htmlFor="campaignType" className="text-xs font-medium text-muted-foreground">Campaign Type</label>
              <Select value={currentFilters.campaignType} onValueChange={(value) => handleFilterChange('campaignType', value)}>
                <SelectTrigger id="campaignType" className="shadcn-input text-xs">
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent className="shadcn-select-content">
                   {dataFilters?.availableCampaignTypes?.map(type => <SelectItem key={type} value={type} className="shadcn-select-item text-xs">{type}</SelectItem>)}
                </SelectContent>
              </Select>
            </motion.div>
            <motion.div variants={itemVariants} className="space-y-1.5">
              <label htmlFor="specificSid" className="text-xs font-medium text-muted-foreground">Specific SID (Optional)</label>
              <Input id="specificSid" value={currentFilters.specificSid} onChange={(e) => handleFilterChange('specificSid', e.target.value)} placeholder="e.g., MGxxxx, PNxxxx" className="shadcn-input text-xs" />
            </motion.div>
            <motion.div variants={itemVariants}>
              <Button onClick={applyFilters} className="w-full shadcn-button text-xs">
                <BarChartHorizontalBig className="h-3.5 w-3.5 mr-1.5" /> Apply Filters
              </Button>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>

      {/* KPI Overview Section */}
      <motion.div variants={sectionVariants} custom={2}>
        <Card className="frosty-glass p-0.5">
          <CardHeader className="pb-3 pt-5 px-5">
            <div className="flex items-center gap-2.5">
              <TrendingUp className="h-6 w-6 text-primary opacity-90" />
              <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Key Performance Indicators</CardTitle>
            </div>
             <CardDescription className="text-sm md:text-base">High-level overview of critical metrics ({currentFilters.dateRange || 'N/A'}).</CardDescription>
          </CardHeader>
          <CardContent className="px-5 pb-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
            <StatCard title="Total Spend" value={kpiOverview?.totalSpendYTD?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} unit={kpiOverview?.currency || billingCurrency} icon={DollarSign} colorClass="text-green-500" trend="+5.2% vs last period" trendDirection="up" />
            <StatCard title="Overall Delivery Rate" value={kpiOverview?.overallDeliveryRate?.toFixed(1)} unit="%" icon={Percent} colorClass="text-sky-500" trend="-0.3% vs last period" trendDirection="down" />
            <StatCard title="Avg. Cost Per Conversion" value={kpiOverview?.avgCostPerConversion?.toFixed(2)} unit={kpiOverview?.currency || billingCurrency} icon={DollarSign} colorClass="text-amber-500" trend="+2.1% vs last period" trendDirection="up" />
            <StatCard title="Subscriber Growth" value={kpiOverview?.activeSubscribersGrowth?.toFixed(1)} unit="%" icon={Users} colorClass="text-purple-500" trend="+1.5k new" trendDirection="up" />
          </CardContent>
        </Card>
      </motion.div>
      
      {/* Detailed Usage Breakdown Section */}
      <motion.div variants={sectionVariants} custom={3}>
        <Card className="frosty-glass p-0.5">
          <CardHeader className="pb-3 pt-5 px-5">
            <div className="flex items-center gap-2.5">
              <Briefcase className="h-6 w-6 text-primary opacity-90" />
              <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Detailed Usage Breakdown</CardTitle>
            </div>
            <CardDescription className="text-sm md:text-base">Service-specific usage and spend details ({currentFilters.dateRange || 'N/A'}).</CardDescription>
          </CardHeader>
          <CardContent className="px-5 pb-5 grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
            <DetailStatCard title="SMS/MMS Usage" data={detailedUsage?.smsMms || {}} icon={MessageSquare} colorClass="text-sky-500" />
            <DetailStatCard title="Voice Call Usage" data={detailedUsage?.voice || {}} icon={Phone} colorClass="text-red-500" />
            <DetailStatCard title="Email Campaign Stats" data={detailedUsage?.email || {}} icon={Mail} colorClass="text-amber-500" />
            <DetailStatCard title="WhatsApp Usage" data={detailedUsage?.whatsApp || {}} icon={Smartphone} colorClass="text-green-500" />
          </CardContent>
        </Card>
      </motion.div>

      {/* Spend by Service Pie Chart (Mock) */}
      {spendByService && spendByService.length > 0 && (
        <motion.div variants={sectionVariants} custom={3.5}>
          <Card className="frosty-glass p-0.5">
            <CardHeader className="pb-3 pt-5 px-5">
              <div className="flex items-center gap-2.5">
                <PieChart className="h-6 w-6 text-primary opacity-90" />
                <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Spend Distribution by Service</CardTitle>
              </div>
              <CardDescription className="text-sm md:text-base">Visual breakdown of costs across Twilio services ({currentFilters.dateRange || 'N/A'}).</CardDescription>
            </CardHeader>
            <CardContent className="px-5 pb-5">
              <div className="w-full aspect-[16/7] bg-muted/20 rounded-md flex items-center justify-center p-4">
                <p className="text-sm text-muted-foreground">
                  Interactive pie chart visualizing spend distribution would appear here.
                  (Requires charting library integration)
                </p>
              </div>
               <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs">
                {spendByService.map(item => (
                  <div key={item.service} className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-primary mr-1.5 opacity-70"></span> 
                    <span className="text-muted-foreground">{item.service}:</span>
                    <span className="ml-1 font-medium text-foreground">{kpiOverview?.currency || billingCurrency} {item.spend.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Campaign Performance Section */}
      <motion.div variants={sectionVariants} custom={4}>
        <Card className="frosty-glass p-0.5">
          <CardHeader className="pb-3 pt-5 px-5">
            <div className="flex items-center gap-2.5">
              <ListChecks className="h-6 w-6 text-primary opacity-90" />
              <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Campaign Performance Drilldown</CardTitle>
            </div>
            <CardDescription className="text-sm md:text-base">Metrics for individual campaigns ({currentFilters.dateRange || 'N/A'}).</CardDescription>
          </CardHeader>
          <CardContent className="px-5 pb-5 space-y-3 md:space-y-4">
            {campaignPerformance && campaignPerformance.length > 0 ? campaignPerformance.map((report) => (
              <motion.div key={report.campaignId} variants={itemVariants}>
                <Card className="bg-card/50 p-3.5 shadow-sm hover:shadow-md transition-shadow duration-300">
                  <div className="flex flex-col sm:flex-row justify-between sm:items-start mb-1.5">
                    <h3 className="text-sm font-semibold text-foreground">{report.campaignName}</h3>
                    <Badge variant={ report.type === 'sms' ? 'default' : report.type === 'email' ? 'secondary' : 'outline' } className="shadcn-badge text-[10px] capitalize mt-1 sm:mt-0">
                      {report.type}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-[11px] text-muted-foreground">
                    <p><strong>Delivered:</strong> {report.delivered?.toLocaleString() || 'N/A'}</p>
                    <p><strong>Cost:</strong> {kpiOverview?.currency || billingCurrency} {report.cost?.toFixed(2) || 'N/A'}</p>
                    <p><strong>{report.type === 'email' ? 'Open Rate:' : 'CTR:'}</strong> {report.ctr ? (report.ctr * 100).toFixed(1) + '%' : (report.openRate ? (report.openRate * 100).toFixed(1) + '%' : 'N/A')}</p>
                    <p><strong>Conv. Rate:</strong> {report.conversionRate?.toFixed(1) + '%' || 'N/A'}</p>
                    <p><strong>ROI:</strong> {report.roi?.toFixed(0) + '%' || 'N/A'}</p>
                  </div>
                  <Progress 
                    value={report.type === 'sms' ? ((report.delivered / (report.delivered + (report.failed || 0))) * 100) || 0 : (report.openRate ? report.openRate * 100 : 0) } 
                    className="h-1 mt-2.5 bg-muted/70" 
                    indicatorClassName={`${report.type === 'sms' ? 'bg-sky-500' : 'bg-amber-500'} opacity-90`} 
                  />
                </Card>
              </motion.div>
            )) : (
              <motion.div variants={itemVariants} className="text-center py-8 text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                No campaign performance data for current filters.
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>
      
      <motion.div variants={itemVariants} className="flex justify-end pt-2">
        <Button variant="outline" className="shadcn-button text-xs">
          <Download className="h-3.5 w-3.5 mr-1.5" /> Export Full Report (PDF/CSV)
        </Button>
      </motion.div>

      <motion.p variants={itemVariants} className="text-center text-xs text-muted-foreground mt-6 pb-4">
        Future enhancements: Custom report builder, automated report scheduling, real-time anomaly detection.
      </motion.p>
    </motion.div>
  );
}