import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Share2, AlertTriangle, CheckCircle, FileText } from 'lucide-react';
import FlowBuilder from '@/components/flow_builder/FlowBuilder';

export function TwilioFlowBuilder() {
  const [flows, setFlows] = useState([]);
  const [selectedFlow, setSelectedFlow] = useState(null);
  const [flowDefinition, setFlowDefinition] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditorLoading, setIsEditorLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchFlows = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    const { data, error } = await supabase.functions.invoke('twilio-proxy', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ "path": "/flows" })
    });

    if (error || data.error) {
      const errorMessage = error?.message || data.error;
      setError(errorMessage);
      toast({
        title: "Error Fetching Flows",
        description: errorMessage,
        variant: "destructive",
      });
      setFlows([]);
    } else {
      setFlows(data.flows || []);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchFlows();
  }, [fetchFlows]);

  const handleSelectFlow = async (flowSid) => {
    setIsEditorLoading(true);
    setSelectedFlow(flows.find(f => f.sid === flowSid));
    const { data, error } = await supabase.functions.invoke('twilio-proxy', {
        method: 'GET',
        body: JSON.stringify({ "path": `/flows/${flowSid}` })
    });

    if (error || data.error) {
        toast({ title: "Error loading flow definition", description: error?.message || data.error, variant: "destructive" });
        setFlowDefinition(null);
    } else {
        setFlowDefinition(data.definition);
    }
    setIsEditorLoading(false);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
        <Loader2 className="h-10 w-10 animate-spin mb-4" />
        <p className="text-lg font-medium">Contacting Twilio API...</p>
        <p className="text-sm">Fetching available Studio Flows via secure proxy.</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-destructive p-8">
        <AlertTriangle className="h-16 w-16 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Connection Error</h2>
        <p className="text-center mb-4 max-w-md">Could not connect to the Twilio API via the Supabase proxy. Please ensure your Twilio credentials are correctly set up as secrets in your Supabase project.</p>
        <Card className="w-full max-w-md bg-destructive/10 border-destructive/50">
            <CardContent className="p-4 text-xs">
                <p className="font-mono">{error}</p>
            </CardContent>
        </Card>
        <Button onClick={fetchFlows} className="mt-6">Retry Connection</Button>
      </div>
    );
  }

  if (flowDefinition && selectedFlow) {
    return <FlowBuilder key={selectedFlow.sid} flow={selectedFlow} initialDefinition={flowDefinition} onBack={() => { setFlowDefinition(null); setSelectedFlow(null); fetchFlows(); }} />;
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 h-full flex flex-col">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-6"
      >
        <div className="flex items-center gap-3">
          <Share2 className="h-8 w-8 text-primary opacity-85" />
          <h1 className="text-3xl font-bold text-foreground tracking-tight">Twilio Flow Builder</h1>
        </div>
        <p className="mt-1 text-muted-foreground">Select a Twilio Studio Flow to edit visually.</p>
      </motion.header>
      
      {isEditorLoading && (
        <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <Loader2 className="h-10 w-10 animate-spin mb-4" />
            <p className="text-lg font-medium">Loading Flow Editor...</p>
            <p className="text-sm">Fetching flow definition from Twilio.</p>
        </div>
      )}

      {!isEditorLoading && (
        <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ staggerChildren: 0.05 }}
        >
            {flows.map(flow => (
            <motion.div key={flow.sid} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="frosty-glass h-full flex flex-col hover:ring-2 hover:ring-primary/50 transition-shadow duration-300">
                <CardHeader>
                    <CardTitle className="flex items-center justify-between text-base">
                        {flow.friendly_name}
                        <span className={`text-xs px-2 py-0.5 rounded-full ${flow.status === 'published' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                            {flow.status}
                        </span>
                    </CardTitle>
                    <CardDescription className="text-xs font-mono pt-1">{flow.sid}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col justify-between">
                    <div className="text-xs text-muted-foreground space-y-1">
                        <p className="flex items-center gap-2"><CheckCircle className="h-3.5 w-3.5 text-primary/70"/> Version: {flow.version}</p>
                        <p className="flex items-center gap-2"><FileText className="h-3.5 w-3.5 text-primary/70"/> Last updated: {new Date(flow.date_updated).toLocaleString()}</p>
                    </div>
                    <Button onClick={() => handleSelectFlow(flow.sid)} className="w-full mt-4">Edit Flow</Button>
                </CardContent>
                </Card>
            </motion.div>
            ))}
        </motion.div>
      )}
    </div>
  );
}