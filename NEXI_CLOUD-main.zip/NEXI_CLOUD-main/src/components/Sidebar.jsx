import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';
import { 
    LayoutDashboard, MessageSquare, Database, Zap, Rss, Settings, BarChart2, 
    GitFork, Users, ShieldCheck, Server, Power, RotateCcw, SlidersHorizontal, 
    LifeBuoy, Package, CalendarClock, BrainCircuit, Gift, Film, Sparkles, 
    Wand2, Home, Command, Clock, Share2, Palette, Network as NetworkIcon, 
    SearchCode, Rocket 
} from 'lucide-react';

const navItemColors = [
  'rgb(var(--icon-color-blue-rgb))',    // Home
  'rgb(var(--icon-color-orange-rgb))',  // Rocket (Ignition Sequence)
  'rgb(var(--icon-color-purple-rgb))',  // BrainCircuit
  'rgb(var(--icon-color-teal-rgb))',    // GitFork
  'rgb(var(--icon-color-pink-rgb))',    // Gift
  'rgb(var(--icon-color-green-rgb))',   // Users
  'rgb(var(--icon-color-yellow-rgb))',  // MessageSquare
  'rgb(var(--icon-color-indigo-rgb))',  // Wand2
  'rgb(var(--icon-color-red-rgb))',     // Zap
  'rgb(var(--icon-color-blue-rgb))',    // Package
  'rgb(var(--icon-color-green-rgb))',   // BarChart2
  'rgb(var(--icon-color-orange-rgb))',  // SearchCode (LeadIntelHub)
  'rgb(var(--icon-color-purple-rgb))',  // Server
  'rgb(var(--icon-color-teal-rgb))',    // ShieldCheck
  'rgb(var(--icon-color-pink-rgb))',    // LifeBuoy
  'rgb(var(--icon-color-yellow-rgb))',  // LayoutDashboard
  'rgb(var(--icon-color-red-rgb))',     // Share2
  'rgb(var(--icon-color-blue-rgb))',    // Palette (AnimatedMessageBuilder)
  'rgb(var(--icon-color-purple-rgb))',  // NetworkIcon (ApiProfileManager)
  'rgb(var(--icon-color-teal-rgb))',    // Rss (Twilio APIs)
];

const navItems = [
  { name: 'Operations Hub', path: '/', icon: Home }, 
  { name: 'Ignition Sequence', path: '/ignition-sequence', icon: Rocket }, 
  { name: 'GPT Campaign Brain', path: '/gpt-campaign-brain', icon: BrainCircuit },
  { name: 'Journey Builder', path: '/journey-builder', icon: GitFork },
  { name: 'Twilio Flow Builder', path: '/twilio-flow-builder', icon: Share2 },
  { name: 'Lead Intel Hub', path: '/lead-intel-hub', icon: SearchCode },
  { name: 'Lead Resume Engine', path: '/lead-resume-engine', icon: RotateCcw },
  { name: 'Giveaway Manager', path: '/giveaway-manager', icon: Gift },
  { name: 'Lead Lifecycle', path: '/lead-lifecycle', icon: Users },
  { name: 'Bot Army Builder', path: '/bot-army-builder', icon: MessageSquare },
  { name: 'Advanced Features', path: '/advanced-features', icon: Wand2 },
  { name: 'API Profile Manager', path: '/api-profile-manager', icon: NetworkIcon },
  { name: 'Predictor Tool', path: '/predictor', icon: Zap },
  { name: 'Studio Builder', path: '/studio-builder', icon: Package },
  { name: 'Flex Insights', path: '/flex-insights', icon: BarChart2 },
  { name: 'Backup Providers', path: '/backup-providers', icon: Server },
  { name: 'Compliance Center', path: '/compliance-center', icon: ShieldCheck },
  { name: 'Machine Health', path: '/machine-health', icon: LifeBuoy },
  { name: 'Dashboard Builder', path: '/dashboard-builder', icon: LayoutDashboard },
  { name: 'Twilio APIs', path: '/twilio-apis', icon: Rss },
];

const bottomNavItems = [
  { name: 'Settings', path: '/settings', icon: Settings, color: 'rgb(var(--icon-color-gray-rgb))' },
  { name: 'Log Out', path: '/logout', icon: Power, color: 'rgb(var(--icon-color-red-rgb))' },
];

const sidebarVariants = {
  open: { width: '260px', transition: { type: 'spring', stiffness: 300, damping: 30 } },
  closed: { width: '72px', transition: { type: 'spring', stiffness: 300, damping: 30 } },
};

const navItemVariants = {
  open: { opacity: 1, x: 0, transition: { duration: 0.3, ease: "easeOut" } },
  closed: { opacity: 0, x: -20, transition: { duration: 0.2, ease: "easeIn" } },
};

const NexieLogo = () => (
  <motion.svg 
    width="32" 
    height="32" 
    viewBox="0 0 100 100" 
    className="h-8 w-8"
    initial={{ rotate: 0, scale: 0.9 }}
    animate={{ rotate: [0, 10, -5, 0], scale: [0.9, 1.05, 0.95, 1] }}
    transition={{ duration: 4, ease: "easeInOut", repeat: Infinity, repeatDelay: 2 }}
  >
    <defs>
      <linearGradient id="nexieGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: "rgb(var(--icon-color-purple-rgb))", stopOpacity:1}} />
        <stop offset="100%" style={{stopColor: "rgb(var(--icon-color-blue-rgb))", stopOpacity:1}} />
      </linearGradient>
    </defs>
    <motion.path 
      d="M50 10 L90 35 L90 65 L50 90 L10 65 L10 35 Z" 
      fill="url(#nexieGradient)"
      stroke="rgb(var(--color-primary-val-rgb))" 
      strokeWidth="3"
      initial={{ pathLength: 0, opacity: 0 }}
      animate={{ pathLength: 1, opacity: 1 }}
      transition={{ duration: 1.5, ease: "circOut", delay: 0.2 }}
    />
    <motion.path 
      d="M50 10 L70 22 L70 40 L50 52 L30 40 L30 22 Z" 
      fill="rgba(var(--color-bg-val-rgb), 0.3)"
      stroke="rgb(var(--icon-color-blue-rgb))"
      strokeWidth="2"
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8, ease: "easeOut", delay: 0.8 }}
    />
     <motion.circle 
      cx="50" cy="50" r="8" 
      fill="rgb(var(--color-bg-val-rgb))"
      initial={{ opacity: 0, r:0 }}
      animate={{ opacity: 1, r:8 }}
      transition={{ duration: 0.5, ease: "easeOut", delay: 1.2 }}
    />
  </motion.svg>
);

const NavItem = ({ item, index, isOpen }) => {
  const location = useLocation();
  const { toast } = useToast(); 
  const isActive = location.pathname === item.path;
  const iconColor = item.color || navItemColors[index % navItemColors.length];

  const linkContent = (
    <div
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ease-in-out group relative",
        isActive 
          ? 'bg-apple-accent/10 text-apple-accent shadow-sm border border-apple-accent/20' 
          : 'text-apple-secondary hover:bg-apple-input-bg/70 hover:text-apple-primary',
        !isOpen && 'justify-center',
        item.name === 'Log Out' && 'hover:bg-red-500/10'
      )}
    >
      <motion.div 
        whileHover={{ scale: 1.2, rotate: 5 }}
        transition={{ type: 'spring', stiffness: 300, damping: 10 }}
      >
        <item.icon 
          style={{ color: isActive ? 'rgb(var(--color-accent-val-rgb))' : iconColor }} 
          className={cn(
            'h-5 w-5 flex-shrink-0 transition-colors duration-200',
            isActive && 'drop-shadow-lg',
            item.name === 'Log Out' && 'group-hover:text-red-500'
          )} 
        />
      </motion.div>
      <motion.span
        variants={navItemVariants}
        initial={false}
        animate={isOpen ? "open" : "closed"}
        className={cn(!isOpen && 'sr-only', isActive ? 'font-semibold' : 'font-medium', item.name === 'Log Out' && 'group-hover:text-red-500')}
      >
        {item.name}
      </motion.span>
    </div>
  );

  if (item.name === 'Log Out') {
    return (
      <button onClick={() => toast({ title: "🚧 Feature Not Implemented", description: "Log out functionality isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" })} className="w-full text-left">
        {linkContent}
      </button>
    )
  }

  return (
    <Link to={item.path}>
      {linkContent}
    </Link>
  );
};


export function Sidebar() {
  const [isOpen, setIsOpen] = React.useState(true);

  return (
    <motion.aside
      variants={sidebarVariants}
      initial={false}
      animate={isOpen ? 'open' : 'closed'}
      className="h-screen bg-apple-bg/80 backdrop-blur-lg text-apple-primary flex flex-col border-r border-apple-border/60 shadow-lg sticky top-0"
    >
      <div className="p-3 flex items-center justify-between h-[60px] border-b border-apple-border/60 flex-shrink-0">
        <motion.div 
          className="flex items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.4 }}
        >
          <NexieLogo />
          {isOpen && (
            <motion.span 
              variants={navItemVariants}
              initial="closed"
              animate="open"
              exit="closed"
              className="font-semibold text-base tracking-tight text-apple-primary">
              NEXIE COMMAND
            </motion.span>
          )}
        </motion.div>
        <button 
          onClick={() => setIsOpen(!isOpen)} 
          className="p-1.5 rounded-md hover:bg-apple-input-bg/70 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-apple-accent focus-visible:ring-offset-2 focus-visible:ring-offset-apple-bg"
          aria-label={isOpen ? "Collapse Sidebar" : "Expand Sidebar"}
        >
           <SlidersHorizontal className="h-5 w-5 text-apple-secondary" />
        </button>
      </div>

      <nav className="flex-grow p-2.5 space-y-1 overflow-y-auto scrollbar-hide">
        {navItems.map((item, index) => (
            <NavItem key={item.name} item={item} index={index} isOpen={isOpen} />
        ))}
      </nav>

      <div className="p-2.5 mt-auto border-t border-apple-border/60 space-y-1">
        {bottomNavItems.map((item, index) => (
           <NavItem key={item.name} item={item} index={index} isOpen={isOpen} />
        ))}
      </div>
    </motion.aside>
  );
}
