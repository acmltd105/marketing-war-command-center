import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CalendarDays, Tag, Clock, AlertTriangle, Info, List, PlusCircle, Edit3, Eye } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const mockOffers = [
  { id: 'offer1', name: 'Summer Splash Sale', discount: '20% Off Sitewide', validFrom: '2025-07-01', validTo: '2025-07-15', status: 'Active', countdown: '5 days left' },
  { id: 'offer2', name: 'Back to School Bonanza', discount: 'Free Shipping + 10% Off Books', validFrom: '2025-08-15', validTo: '2025-08-31', status: 'Upcoming', countdown: null },
  { id: 'offer3', name: 'Flash Friday Deal', discount: '$50 Off Premium Plan', validFrom: '2025-06-14', validTo: '2025-06-14', status: 'Active', countdown: 'Ends Today!' },
  { id: 'offer4', name: 'Holiday Gift Guide', discount: 'Special Bundles Available', validFrom: '2025-11-20', validTo: '2025-12-25', status: 'Upcoming', countdown: null },
];

// Mock calendar data generation
const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();
const getMonthMatrix = (year, month) => {
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = getDaysInMonth(year, month);
  let matrix = [];
  let day = 1;
  for (let i = 0; i < 6; i++) {
    let week = [];
    for (let j = 0; j < 7; j++) {
      if (i === 0 && j < firstDay) {
        week.push(null);
      } else if (day > daysInMonth) {
        week.push(null);
      } else {
        week.push(day++);
      }
    }
    matrix.push(week);
    if (day > daysInMonth) break;
  }
  return matrix;
};

export function OfferCalendar() {
  const [offers, setOffers] = useState(mockOffers);
  const [viewMode, setViewMode] = useState('list'); // list or calendar

  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const monthMatrix = getMonthMatrix(currentYear, currentMonth);
  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const changeMonth = (delta) => {
    let newMonth = currentMonth + delta;
    let newYear = currentYear;
    if (newMonth < 0) { newMonth = 11; newYear--; }
    else if (newMonth > 11) { newMonth = 0; newYear++; }
    setCurrentMonth(newMonth);
    setCurrentYear(newYear);
  };

  const getOffersForDay = (day) => {
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return offers.filter(offer => {
        const from = new Date(offer.validFrom + 'T00:00:00');
        const to = new Date(offer.validTo + 'T23:59:59');
        const current = new Date(dateStr + 'T12:00:00');
        return current >= from && current <= to;
    });
  };

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <CalendarDays className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Offer Calendar & Countdown
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            View active and upcoming promotions, with expiry dates and countdowns. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div variants={sectionVariants} initial="hidden" animate="visible">
         <div className="flex justify-between items-center mb-4">
            <div className="flex gap-2">
                <Button variant={viewMode === 'list' ? 'default' : 'outline'} onClick={() => setViewMode('list')} className="shadcn-button text-xs"><List size={14} className="mr-1.5"/> List View</Button>
                <Button variant={viewMode === 'calendar' ? 'default' : 'outline'} onClick={() => setViewMode('calendar')} className="shadcn-button text-xs"><CalendarDays size={14} className="mr-1.5"/> Calendar View</Button>
            </div>
            <Button variant="outline" className="shadcn-button text-xs"><PlusCircle size={14} className="mr-1.5"/> Add New Offer (Mock)</Button>
         </div>

        {viewMode === 'list' && (
            <motion.div variants={itemVariants} className="space-y-3">
                {offers.map(offer => (
                    <Card key={offer.id} className="frosty-glass p-0.5">
                        <CardContent className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                            <div className="flex-grow mb-2 sm:mb-0">
                                <div className="flex items-center gap-2 mb-0.5">
                                    <Tag className="h-4 w-4 text-primary opacity-80"/>
                                    <h3 className="text-base font-semibold text-foreground">{offer.name}</h3>
                                </div>
                                <p className="text-xs text-muted-foreground ml-6">{offer.discount}</p>
                                <p className="text-[10px] text-muted-foreground ml-6 mt-0.5">
                                    Valid: {new Date(offer.validFrom).toLocaleDateString()} - {new Date(offer.validTo).toLocaleDateString()}
                                </p>
                            </div>
                            <div className="text-right shrink-0">
                                <Badge variant={offer.status === 'Active' ? 'default' : 'outline'} className="shadcn-badge capitalize mb-1">{offer.status}</Badge>
                                {offer.countdown && (
                                    <div className="flex items-center justify-end gap-1 text-xs text-red-600">
                                        <Clock size={12}/>
                                        <span>{offer.countdown}</span>
                                    </div>
                                )}
                                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary mt-0.5"><Edit3 size={12}/></Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
                {offers.length === 0 && <p className="text-center text-muted-foreground py-8">No offers to display.</p>}
            </motion.div>
        )}

        {viewMode === 'calendar' && (
             <motion.div variants={itemVariants}>
                <Card className="frosty-glass p-0.5">
                    <CardHeader className="px-5 pt-5 pb-3">
                        <div className="flex justify-between items-center">
                            <CardTitle className="text-lg font-semibold">Promotions Calendar</CardTitle>
                            <div className="flex items-center gap-2">
                                <Button variant="outline" size="sm" onClick={() => changeMonth(-1)} className="shadcn-button h-8 px-2 text-xs">&lt; Prev</Button>
                                <span className="text-sm font-medium w-28 text-center">{monthNames[currentMonth]} {currentYear}</span>
                                <Button variant="outline" size="sm" onClick={() => changeMonth(1)} className="shadcn-button h-8 px-2 text-xs">Next &gt;</Button>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="px-5 pb-5">
                        <div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-muted-foreground mb-2">
                            {dayNames.map(day => <div key={day}>{day}</div>)}
                        </div>
                        <div className="grid grid-cols-7 gap-1">
                            {monthMatrix.map((week, i) => week.map((day, j) => {
                                const dayOffers = day ? getOffersForDay(day) : [];
                                return (
                                <div key={`${i}-${j}`} className={`h-20 p-1 border border-border/20 rounded text-xs ${day ? 'bg-background/30' : 'bg-muted/10'} ${dayOffers.length > 0 ? 'ring-1 ring-primary ring-inset' : ''}`}>
                                   {day && <span className={`${dayOffers.length > 0 ? 'font-bold text-primary' : ''}`}>{day}</span>}
                                   {dayOffers.map(offer => (
                                       <div key={offer.id} className="mt-0.5 text-[9px] truncate text-primary/80 bg-primary/10 px-1 rounded-sm hover:opacity-75 cursor-pointer" title={offer.name}>{offer.name}</div>
                                   ))}
                                </div>
                                );
                            }))}
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
        )}
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Promotional Visibility</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
               The Offer Calendar provides a view of ongoing and upcoming deals. For leads, this might be a public page. For agents, an internal dashboard. Relies on data from `HolidayUrgencyManager` or a dedicated offer database.
            </p>
        </div>
      </motion.div>
    </div>
  );
}