
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Wifi, WifiOff, Loader2, CheckCircle, AlertTriangle, KeyRound } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.3 } }
};

export function TwilioConnectionStatusIndicator({ showCardWrapper = true }) {
  const [status, setStatus] = useState('idle'); // idle, loading, success, error
  const [accountDetails, setAccountDetails] = useState(null);
  const [lastChecked, setLastChecked] = useState(null);

  const testConnection = async () => {
    setStatus('loading');
    setAccountDetails(null);
    try {
      const { data, error: functionError } = await supabase.functions.invoke('twilio-account-check');

      if (functionError) {
        let detailedMessage = functionError.message || "Failed to invoke the twilio-account-check function.";
        if (detailedMessage.includes("Failed to fetch") || detailedMessage.includes("NetworkError")) {
            detailedMessage += " This could be a CORS issue or network problem with the Edge Function itself."
        }
        throw new Error(detailedMessage);
      }

      if (data && data.error) {
        throw new Error(data.error);
      }

      if (data && data.success && data.account) {
        setStatus('success');
        setAccountDetails(data.account);
        setLastChecked(new Date());
        toast({
          title: "Twilio Connection Successful!",
          description: `Connected to Account: ${data.account.friendly_name || data.account.sid}. Status: ${data.account.status}.`,
          variant: "success",
        });
      } else {
        throw new Error(data.message || "Unknown response from Twilio account check function.");
      }
    } catch (err) {
      setStatus('error');
      setAccountDetails({ error: err.message });
      toast({
        title: "Twilio Connection Test Failed",
        description: err.message,
        variant: "destructive",
      });
    }
  };

  const StatusDisplay = () => {
    let icon;
    let text;
    let colorClass;
    let details = null;

    switch (status) {
      case 'loading':
        icon = <Loader2 className="h-5 w-5 animate-spin text-primary" />;
        text = "Checking Connection...";
        colorClass = "text-primary";
        break;
      case 'success':
        icon = <CheckCircle className="h-5 w-5 text-green-500" />;
        text = "Twilio Connected";
        colorClass = "text-green-600 dark:text-green-400";
        if (accountDetails) {
          details = (
            <div className="text-xs mt-1.5 space-y-0.5">
              <p><strong>Account:</strong> {accountDetails.friendly_name || accountDetails.sid}</p>
              <p><strong>Status:</strong> <Badge variant={accountDetails.status === 'active' ? 'default' : 'destructive'} className="capitalize">{accountDetails.status}</Badge></p>
              {lastChecked && <p><strong>Last Checked:</strong> {lastChecked.toLocaleTimeString()}</p>}
            </div>
          );
        }
        break;
      case 'error':
        icon = <AlertTriangle className="h-5 w-5 text-red-500" />;
        text = "Connection Failed";
        colorClass = "text-red-600 dark:text-red-400";
        if (accountDetails && accountDetails.error) {
          details = <p className="text-xs mt-1.5 max-w-sm truncate" title={accountDetails.error}><strong>Error:</strong> {accountDetails.error}</p>;
        }
        break;
      default: // idle
        icon = <WifiOff className="h-5 w-5 text-muted-foreground" />;
        text = "Not Connected / Untested";
        colorClass = "text-muted-foreground";
    }

    return (
      <motion.div variants={itemVariants} className="flex flex-col items-center md:items-start">
        <div className="flex items-center gap-2.5">
          {icon}
          <span className={`font-medium text-sm ${colorClass}`}>{text}</span>
        </div>
        {details && <div className={`pl-0 md:pl-[calc(1.25rem+0.625rem)] ${colorClass}`}>{details}</div>}
      </motion.div>
    );
  };

  const content = (
    <>
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <StatusDisplay />
        <Button onClick={testConnection} disabled={status === 'loading'} className="w-full md:w-auto shadcn-button">
          {status === 'loading' ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Wifi className="mr-2 h-4 w-4" />
          )}
          Test Twilio Connection
        </Button>
      </div>
      <p className="text-xs text-muted-foreground mt-3 text-center md:text-left">
        This test uses credentials stored in Supabase Vault (<code>TWILIO_ACCOUNT_SID</code> & <code>TWILIO_AUTH_TOKEN</code>).
      </p>
    </>
  );
  
  if (showCardWrapper) {
    return (
      <motion.div initial="hidden" animate="visible" variants={itemVariants}>
        <Card className="frosty-glass p-0.5">
          <CardHeader className="pb-3 pt-5 px-5">
             <div className="flex items-center gap-2.5">
                <KeyRound className="h-6 w-6 text-primary opacity-90" />
                <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">Twilio API Connection Status</CardTitle>
            </div>
            <CardDescription className="text-sm md:text-base">Verify if NEXIE can connect to your Twilio account using Supabase Vault credentials.</CardDescription>
          </CardHeader>
          <CardContent className="px-5 pb-5">
            {content}
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div initial="hidden" animate="visible" variants={itemVariants} className="p-4 border rounded-lg bg-card/50">
      {content}
    </motion.div>
  );
}
