import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle, XCircle, Loader2, ExternalLink, AlertTriangle } from 'lucide-react';
import { cn } from "@/lib/utils";

export function DeploymentPlanModal({ isOpen, onClose, steps }) {

  const getStatusIcon = (status) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="text-green-500" size={18} />;
      case "pending":
        return <Loader2 className="animate-spin text-apple-secondary" size={18} />;
      case "blocked":
        return <XCircle className="text-red-500" size={18} />;
      default:
        return null;
    }
  };

  const handleAction = (step) => {
    if (step.actionType === "external") {
      alert("This action requires you to go to the Hostinger Panel. Please follow the instructions provided.");
    } else if (step.actionType === "external_supabase") {
      alert("This action will redirect you to the Supabase Studio. Ensure you are logged in.");
      window.open('https://app.supabase.io', '_blank');
    } else {
       alert("🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀");
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <Dialog open={isOpen} onOpenChange={onClose}>
          <DialogContent 
            className="sm:max-w-[600px] bg-apple-bg text-apple-primary border-apple-border shadow-xl rounded-lg"
            asChild // Use motion.div for animations
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 10 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              <DialogHeader className="p-6 pb-4 border-b border-apple-border/70">
                <DialogTitle className="text-xl font-semibold text-apple-primary">Supabase Integration Plan</DialogTitle>
                <DialogDescription className="text-sm text-apple-secondary mt-1">
                  Follow these steps to integrate Supabase for backend functionality. Some steps require manual actions in Hostinger or Supabase.
                </DialogDescription>
              </DialogHeader>
              
              <ScrollArea className="max-h-[60vh] p-6">
                <ul className="space-y-4">
                  {steps.map((step) => (
                    <li key={step.id} className="flex items-start space-x-3 p-3 bg-apple-input-bg/50 rounded-md border border-apple-border/50">
                      <div className="flex-shrink-0 mt-0.5">{getStatusIcon(step.status)}</div>
                      <div className="flex-grow">
                        <p className="font-medium text-apple-primary text-sm">{step.id}. {step.title}</p>
                        <p className="text-xs text-apple-secondary mt-0.5">{step.description}</p>
                        {step.status === "blocked" && step.id === 1 && (
                           <div className="mt-2 p-2.5 bg-red-500/10 border border-red-500/30 rounded-md text-xs text-red-700 flex items-center gap-2">
                            <AlertTriangle size={16} />
                            <span>Action Required: Please complete Supabase connection in Hostinger Panel to unblock.</span>
                           </div>
                        )}
                      </div>
                      {step.actionLabel && (
                        <Button 
                          variant={step.status === "blocked" ? "destructive" : "outline"} 
                          size="sm" 
                          className="ml-auto text-xs self-center shadcn-button"
                          onClick={() => handleAction(step)}
                          disabled={step.status === "completed"}
                        >
                          {step.actionLabel}
                          {step.actionType?.startsWith("external") && <ExternalLink size={12} className="ml-1.5" />}
                        </Button>
                      )}
                    </li>
                  ))}
                </ul>
              </ScrollArea>
              
              <DialogFooter className="p-6 pt-4 border-t border-apple-border/70">
                <Button variant="outline" onClick={onClose} className="shadcn-button">Close</Button>
              </DialogFooter>
            </motion.div>
          </DialogContent>
        </Dialog>
      )}
    </AnimatePresence>
  );
}