
import React from 'react';
import { motion } from 'framer-motion';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CheckCircle, AlertCircle, Power, Database, Radio, BrainCircuit } from 'lucide-react';

const StatusItem = ({ icon, label, status, statusColor }) => (
  <div className="flex items-center justify-between text-xs">
    <div className="flex items-center gap-2">
      {icon}
      <span className="text-muted-foreground">{label}</span>
    </div>
    <span className={`font-semibold ${statusColor}`}>{status}</span>
  </div>
);

export function SystemStatus() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="flex items-center gap-2 cursor-pointer group mt-2"
        >
          <div className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
          </div>
          <span className="text-xs text-green-400 group-hover:text-green-300 transition-colors">All Systems Operational</span>
        </motion.div>
      </PopoverTrigger>
      <PopoverContent className="w-64 frosty-glass p-3" side="top" align="center">
        <div className="space-y-3">
          <p className="text-sm font-semibold text-foreground">System Status Breakdown</p>
          <StatusItem 
            icon={<Power className="h-4 w-4 text-green-500" />} 
            label="Frontend Application" 
            status="Operational"
            statusColor="text-green-500"
          />
          <StatusItem 
            icon={<Database className="h-4 w-4 text-green-500" />} 
            label="Supabase Connection" 
            status="Connected"
            statusColor="text-green-500"
          />
          <StatusItem 
            icon={<Radio className="h-4 w-4 text-green-500" />} 
            label="Twilio API Proxy" 
            status="Ready"
            statusColor="text-green-500"
          />
          <StatusItem 
            icon={<BrainCircuit className="h-4 w-4 text-amber-500" />} 
            label="OpenAI Services" 
            status="Awaiting Key"
            statusColor="text-amber-500"
          />
        </div>
      </PopoverContent>
    </Popover>
  );
}
