import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Gavel, ShieldCheck, FileText, ClipboardList, BarChartBig, AlertTriangle, ExternalLink, Search, Filter, Download } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const mockTrustHubData = {
  brandScore: 85,
  a2pCampaigns: [
    { id: 'CM001', name: 'Marketing Notifications Q3', status: 'Approved', type: 'Low Volume Mixed', throughput: 5, registrationDate: '2024-05-15' },
    { id: 'CM002', name: '2FA Alerts - Main App', status: 'Pending Review', type: 'Transactional', throughput: 60, registrationDate: '2024-06-01' },
    { id: 'CM003', name: 'Customer Support Updates', status: 'Approved', type: 'Conversational', throughput: 10, registrationDate: '2024-04-20' },
  ],
  alerts: 1,
};

const mockSpamData = {
  overallBlockRate: 1.2,
  carrierFiltering: [
    { carrier: 'Verizon', blockRate: 0.8, trend: 'stable' },
    { carrier: 'AT&T', blockRate: 1.5, trend: 'increasing' },
    { carrier: 'T-Mobile', blockRate: 1.1, trend: 'decreasing' },
  ]
};

export function ComplianceCenter() {
  const [activeTab, setActiveTab] = useState("trusthub");

  const getStatusColor = (status) => {
    if (status === 'Approved') return 'text-green-600';
    if (status === 'Pending Review') return 'text-yellow-600';
    if (status === 'Rejected') return 'text-red-600';
    return 'text-muted-foreground';
  };

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Gavel className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Compliance Center
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Manage regulatory compliance, TrustHub registrations, and messaging policies. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6"
      >
        <motion.div variants={itemVariants}>
          <Card className="frosty-glass p-0.5 h-full">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-sm font-medium text-muted-foreground">Overall Compliance Score</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <p className="text-3xl font-bold text-green-500">{mockTrustHubData.brandScore}%</p>
              <Progress value={mockTrustHubData.brandScore} className="h-2 mt-1.5 bg-green-500/20" indicatorClassName="bg-green-500" />
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={itemVariants}>
          <Card className="frosty-glass p-0.5 h-full">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active A2P 10DLC Campaigns</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <p className="text-3xl font-bold">{mockTrustHubData.a2pCampaigns.filter(c => c.status === 'Approved').length}</p>
              <p className="text-xs text-muted-foreground mt-1">out of {mockTrustHubData.a2pCampaigns.length} total registered</p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={itemVariants}>
          <Card className="frosty-glass p-0.5 h-full">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-sm font-medium text-muted-foreground">Alerts Requiring Attention</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <p className="text-3xl font-bold text-amber-500">{mockTrustHubData.alerts}</p>
              <p className="text-xs text-muted-foreground mt-1">Review pending actions or rejections.</p>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2}
        className="flex-grow flex flex-col"
      >
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex-grow flex flex-col">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-1 shadcn-tabs-list mb-4">
            <TabsTrigger value="trusthub" className="shadcn-tabs-trigger"><ShieldCheck size={14} className="mr-1.5"/>TrustHub & A2P</TabsTrigger>
            <TabsTrigger value="tcpa" className="shadcn-tabs-trigger"><FileText size={14} className="mr-1.5"/>TCPA & Consent</TabsTrigger>
            <TabsTrigger value="stirshaken" className="shadcn-tabs-trigger"><ClipboardList size={14} className="mr-1.5"/>STIR/SHAKEN</TabsTrigger>
            <TabsTrigger value="spam" className="shadcn-tabs-trigger"><BarChartBig size={14} className="mr-1.5"/>Spam & Policy</TabsTrigger>
            <TabsTrigger value="audits" className="shadcn-tabs-trigger"><Search size={14} className="mr-1.5"/>Audits & Logs</TabsTrigger>
          </TabsList>

          <div className="flex-grow overflow-y-auto scrollbar-hide">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2, ease: "easeInOut" }}
                className="mt-1"
              >
                <TabsContent value="trusthub" className="m-0 p-0">
                  <Card className="frosty-glass p-0.5">
                    <CardHeader className="flex flex-row justify-between items-center px-5 pt-5 pb-3">
                      <div>
                        <CardTitle className="text-lg font-semibold">A2P 10DLC Campaign Registrations</CardTitle>
                        <CardDescription className="text-sm">Manage and monitor your 10DLC campaign statuses.</CardDescription>
                      </div>
                      <Button variant="outline" className="shadcn-button text-xs" onClick={() => window.open('https://console.twilio.com/us1/develop/sms/trust-hub', '_blank')}>
                        <ExternalLink size={13} className="mr-1.5"/> Go to Twilio Trust Hub
                      </Button>
                    </CardHeader>
                    <CardContent className="px-5 pb-5">
                      <div className="overflow-x-auto">
                        <table className="min-w-full text-sm">
                          <thead className="text-left text-muted-foreground">
                            <tr>
                              <th className="p-2 font-medium">Campaign ID</th>
                              <th className="p-2 font-medium">Name</th>
                              <th className="p-2 font-medium">Type</th>
                              <th className="p-2 font-medium">Status</th>
                              <th className="p-2 font-medium">Throughput/Sec</th>
                              <th className="p-2 font-medium">Registered</th>
                            </tr>
                          </thead>
                          <tbody>
                            {mockTrustHubData.a2pCampaigns.map(campaign => (
                              <tr key={campaign.id} className="border-b border-border/50 hover:bg-muted/20">
                                <td className="p-2 font-mono text-xs">{campaign.id}</td>
                                <td className="p-2">{campaign.name}</td>
                                <td className="p-2">{campaign.type}</td>
                                <td className={`p-2 font-medium ${getStatusColor(campaign.status)}`}>{campaign.status}</td>
                                <td className="p-2 text-center">{campaign.throughput}</td>
                                <td className="p-2">{campaign.registrationDate}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                       {mockTrustHubData.a2pCampaigns.length === 0 && <p className="text-center py-6 text-muted-foreground">No A2P campaigns registered yet.</p>}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="tcpa" className="m-0 p-0">
                  <Card className="frosty-glass p-0.5">
                    <CardHeader className="px-5 pt-5 pb-3">
                      <CardTitle className="text-lg font-semibold">TCPA & Consent Management</CardTitle>
                      <CardDescription className="text-sm">Guidelines and tools for managing user consent (opt-ins/opt-outs).</CardDescription>
                    </CardHeader>
                    <CardContent className="px-5 pb-5 space-y-4">
                      <p className="text-xs text-muted-foreground">
                        The Telephone Consumer Protection Act (TCPA) requires obtaining proper consent before sending marketing messages. Ensure your practices align with these regulations. This section would typically allow managing opt-in lists, processing opt-out requests, and maintaining consent records.
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Button variant="outline" className="shadcn-button"><Download size={14} className="mr-2"/> Download Opt-Out List (Mock)</Button>
                        <Button variant="outline" className="shadcn-button"><Filter size={14} className="mr-2"/> Manage Consent Records (Mock)</Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="stirshaken" className="m-0 p-0">
                  <Card className="frosty-glass p-0.5">
                    <CardHeader className="px-5 pt-5 pb-3">
                      <CardTitle className="text-lg font-semibold">STIR/SHAKEN (CAIA) Compliance</CardTitle>
                      <CardDescription className="text-sm">Information on call attestation and robocall mitigation.</CardDescription>
                    </CardHeader>
                    <CardContent className="px-5 pb-5 space-y-3">
                      <p className="text-xs text-muted-foreground">
                        STIR/SHAKEN is a framework to combat illegal robocalls by verifying caller ID information. Full attestation (A-level) indicates you are authorized to use the displayed number.
                      </p>
                      <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-md">
                        <ShieldCheck className="h-5 w-5 text-green-600"/>
                        <p className="text-sm font-medium text-green-700">STIR/SHAKEN Status: Implemented (Full Attestation - A)</p>
                      </div>
                       <Button variant="outline" className="shadcn-button text-xs" onClick={() => window.open('https://www.twilio.com/docs/voice/outbound/stir-shaken', '_blank')}>
                        <ExternalLink size={13} className="mr-1.5"/> Learn More about STIR/SHAKEN
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="spam" className="m-0 p-0">
                  <Card className="frosty-glass p-0.5">
                    <CardHeader className="px-5 pt-5 pb-3">
                      <CardTitle className="text-lg font-semibold">Spam Monitoring & Messaging Policy</CardTitle>
                      <CardDescription className="text-sm">Insights into message filtering and adherence to policies.</CardDescription>
                    </CardHeader>
                    <CardContent className="px-5 pb-5 space-y-4">
                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-md">
                        <p className="text-sm font-medium">Overall Message Block Rate:</p>
                        <p className="text-lg font-bold text-amber-600">{mockSpamData.overallBlockRate}%</p>
                      </div>
                      <div>
                        <h4 className="text-xs font-semibold mb-1.5 text-muted-foreground">Carrier Filtering Insights (Mock):</h4>
                        <ul className="space-y-1.5 text-xs">
                          {mockSpamData.carrierFiltering.map(carrier => (
                            <li key={carrier.carrier} className="flex justify-between items-center p-1.5 bg-background/40 rounded">
                              <span>{carrier.carrier}: <span className="font-medium">{carrier.blockRate}%</span></span>
                              <Badge variant={carrier.trend === 'increasing' ? 'destructive' : carrier.trend === 'decreasing' ? 'default' : 'secondary'} className="shadcn-badge text-[10px] py-0.5 px-1.5">
                                {carrier.trend.charAt(0).toUpperCase() + carrier.trend.slice(1)}
                              </Badge>
                            </li>
                          ))}
                        </ul>
                      </div>
                       <Button variant="outline" className="shadcn-button text-xs" onClick={() => window.open('https://www.twilio.com/legal/messaging-policy', '_blank')}>
                        <ExternalLink size={13} className="mr-1.5"/> Twilio Messaging Policy
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="audits" className="m-0 p-0">
                  <Card className="frosty-glass p-0.5">
                    <CardHeader className="px-5 pt-5 pb-3">
                      <CardTitle className="text-lg font-semibold">Audit Trails & Logs</CardTitle>
                      <CardDescription className="text-sm">Access logs for compliance checks and historical review (Conceptual).</CardDescription>
                    </CardHeader>
                    <CardContent className="px-5 pb-5 text-center min-h-[200px] flex flex-col items-center justify-center">
                      <Search className="h-12 w-12 text-muted-foreground opacity-40 mb-3"/>
                      <p className="text-sm text-muted-foreground">Audit log functionality is planned for a future update.</p>
                      <p className="text-xs text-muted-foreground/80 mt-1">This section will provide access to detailed activity logs.</p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </motion.div>
            </AnimatePresence>
          </div>
        </Tabs>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={3} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Compliance Disclaimer</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This Compliance Center provides a conceptual overview. All information is illustrative. Always consult official Twilio documentation, legal counsel, and regulatory guidelines for actual compliance requirements and implementation.
            </p>
        </div>
      </motion.div>
    </div>
  );
}