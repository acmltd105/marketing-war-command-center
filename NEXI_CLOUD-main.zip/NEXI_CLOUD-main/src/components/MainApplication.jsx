import React from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dashboard } from '@/components/Dashboard';
import { CampaignManager } from '@/components/CampaignManager';
import { AnimatedMessageBuilder } from '@/components/AnimatedMessageBuilder';
import { HolidayUrgencyManager } from '@/components/HolidayUrgencyManager';
import { TwilioAPIs } from '@/components/TwilioAPIs';
import { DataConnections } from '@/components/DataConnections';
import { FileUploadManager } from '@/components/FileUploadManager';
import { ReportsPage } from '@/components/ReportsPage';
import { SettingsPage } from '@/components/SettingsPage';
import { SystemStatus } from '@/components/SystemStatus';
import { PhoneServicesManager } from '@/components/PhoneServicesManager';
import { BillingUsageManager } from '@/components/BillingUsageManager';
import { useTwilioData } from '@/hooks/useTwilioData';
import { 
    LayoutDashboard, MessageCircle, Database, Zap, Rss, Briefcase, UploadCloud, Settings as SettingsIcon, 
    BarChart2, History, Film, CalendarClock, Palette, Phone, CreditCard
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function MainApplication() {
  const twilioData = useTwilioData();

  const pageVariants = {
    initial: { opacity: 0, y: 20, scale: 0.98 },
    in: { opacity: 1, y: 0, scale: 1 },
    out: { opacity: 0, y: -20, scale: 0.98 }
  };

  const pageTransition = {
    type: "spring", 
    stiffness: 260, 
    damping: 25,
  };
  
  const TABS_CONFIG = [
    { value: "dashboard", label: "Dashboard", icon: LayoutDashboard, component: <Dashboard data={twilioData} handleTabChange={twilioData.setCurrentTab} /> },
    { value: "campaigns", label: "Campaigns", icon: MessageCircle, component: <CampaignManager 
        data={twilioData}
        addCampaign={twilioData.addCampaign}
        updateCampaign={twilioData.updateCampaign}
        deleteCampaign={twilioData.deleteCampaign}
      /> 
    },
    { value: "billing", label: "Billing", icon: CreditCard, component: <BillingUsageManager /> },
    { value: "phone-services", label: "Phone Services", icon: Phone, component: <PhoneServicesManager /> },
    { value: "message-crafting", label: "Message Crafting", icon: Palette, component: <AnimatedMessageBuilder /> },
    { value: "offer-calendar", label: "Offer Calendar", icon: CalendarClock, component: <HolidayUrgencyManager /> },
    { value: "apis", label: "Twilio APIs", icon: Rss, component: <TwilioAPIs /> },
    { value: "data-connections", label: "Data Connections", icon: Database, component: <DataConnections /> },
    { value: "file-uploads", label: "File Uploads", icon: UploadCloud, component: <FileUploadManager standaloneView={true}/> },
    { value: "reports", label: "Reporting", icon: History, component: <ReportsPage reportsData={twilioData.reports} settingsData={twilioData.settings} updateReportFilters={twilioData.updateReportFilters} /> },
    { value: "settings", label: "Settings", icon: SettingsIcon, component: <SettingsPage settingsData={twilioData.settings} updateSettings={twilioData.updateSettings} /> },
  ];

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground selection:bg-primary/20 h-full flex flex-col flex-grow">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="flex items-center justify-start max-w-screen-xl mx-auto">
          <Briefcase className="h-8 w-8 md:h-9 md:w-9 text-primary mr-2.5 md:mr-3 opacity-85" />
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
            Operations Hub Dashboard
          </h1>
        </div>
        <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground max-w-screen-xl mx-auto">
          Centralized platform for campaign execution, message design, and data integration.
        </p>
      </motion.header>

      <Tabs defaultValue="dashboard" value={twilioData.currentTab} className="w-full max-w-screen-xl mx-auto flex-grow flex flex-col" onValueChange={(value) => twilioData.setCurrentTab(value)}>
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-11 gap-1 p-1 rounded-lg shadcn-tabs-list mb-4 md:mb-5 relative">
            {TABS_CONFIG.map(tab => (
              <TabsTrigger key={tab.value} value={tab.value} className={cn("py-2 text-xs sm:text-sm font-medium shadcn-tabs-trigger relative z-10", 
                twilioData.currentTab === tab.value ? "" : "hover:text-apple-primary/80"
              )}>
                <tab.icon className={cn("w-3.5 h-3.5 mr-1.5 transition-colors", twilioData.currentTab === tab.value ? "text-apple-accent" : "text-apple-secondary group-hover:text-apple-primary/80 opacity-75")} />
                {tab.label}
              </TabsTrigger>
            ))}
            {TABS_CONFIG.find(t => t.value === twilioData.currentTab) && (
              <motion.div
                layoutId="activeTabIndicator"
                className="absolute inset-0 bg-apple-bg shadow-sm rounded-md z-0"
                style={{
                  left: `${(TABS_CONFIG.findIndex(t => t.value === twilioData.currentTab) / TABS_CONFIG.length) * 100}%`,
                  width: `${100 / TABS_CONFIG.length}%`,
                }}
                transition={{ type: "spring", stiffness: 350, damping: 30 }}
              />
            )}
          </TabsList>
        </motion.div>
        
        <motion.div
          key={twilioData.currentTab || 'dashboard'} 
          initial="initial"
          animate="in"
          exit="out"
          variants={pageVariants}
          transition={pageTransition}
          className="flex-grow"
        >
          {TABS_CONFIG.map(tab => (
            <TabsContent key={tab.value} value={tab.value} className="p-0 slide-in-subtle h-full">
              {tab.component}
            </TabsContent>
          ))}
        </motion.div>
      </Tabs>
      <motion.footer 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="mt-auto pt-4 pb-2 text-center text-muted-foreground text-[10px] border-t border-border/30"
      >
        <div className="flex justify-center items-center flex-col">
          <p>Operations Hub &copy; {new Date().getFullYear()}. All Rights Reserved.</p>
          <p className="mt-0.5">Powered by Hostinger Horizons AI - Nexie Edition</p>
          <SystemStatus />
        </div>
      </motion.footer>
    </div>
  );
}