import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Rewind, PlusCircle, Edit3, Trash2, FileImage, PlayCircle, Settings2, AlertTriangle, Eye, Clock, Zap, Tag } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialResumeCampaign = {
  id: '',
  name: 'New Resume Campaign',
  targetSegment: 'all_dropoffs',
  prefillFields: { firstName: true, email: true, phone: false, productInterest: false, lastStep: false },
  welcomeHeadline: 'Welcome back, {{FirstName}}!',
  subHeadline: "Let's finish this in 2 minutes.",
  ctaText: 'Continue Your Application',
  countdownTimerEnabled: true,
  countdownDuration: '00:30:00', // HH:MM:SS
  logicHighlightEnabled: true,
  logicHighlightCondition: 'zip_code', // zip_code, job_title, previous_interest
  logicHighlightValue: '', // e.g. 90210, Teacher, ProductX
  logicHighlightProduct: '', // e.g. Special CA Offer, Teacher Discount, Premium Telemed
  abTestEnabled: false,
  variantB: { headline: '', subHeadline: '', ctaText: '' },
  status: 'Draft'
};

const LOCAL_STORAGE_KEY = 'hostingerHorizons_leadResumeCampaigns';

export function LeadResumeEngine() {
  const [campaigns, setCampaigns] = useState([]);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [currentConfig, setCurrentConfig] = useState({...initialResumeCampaign});
  const { toast } = useToast();

  useEffect(() => {
    const storedCampaigns = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (storedCampaigns) {
      setCampaigns(JSON.parse(storedCampaigns));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(campaigns));
  }, [campaigns]);


  const handleInputChange = (field, value) => {
    setCurrentConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleCheckboxChange = (area, field, checked) => {
     setCurrentConfig(prev => ({
      ...prev,
      [area]: {
        ...prev[area],
        [field]: checked
      }
    }));
  };

  const handleVariantBChange = (field, value) => {
    setCurrentConfig(prev => ({
      ...prev,
      variantB: {
        ...prev.variantB,
        [field]: value
      }
    }));
  };

  const handleSaveCampaign = () => {
    let campaignToSave = {...currentConfig};
    if (!campaignToSave.id) campaignToSave.id = `lre_${Date.now()}`;
    
    const existingIndex = campaigns.findIndex(c => c.id === campaignToSave.id);
    if (existingIndex > -1) {
      setCampaigns(campaigns.map(c => c.id === campaignToSave.id ? campaignToSave : c));
      toast({ title: "Campaign Updated!", description: `"${campaignToSave.name}" has been saved.`, variant: "default" });
    } else {
      setCampaigns([...campaigns, campaignToSave]);
      toast({ title: "Campaign Created!", description: `"${campaignToSave.name}" is ready.`, variant: "default" });
    }
    setSelectedCampaign(campaignToSave);
  };

  const handleNewCampaign = () => {
    setSelectedCampaign(null);
    setCurrentConfig({...initialResumeCampaign, id: `lre_${Date.now()}`});
  };

  const handleSelectCampaign = (campaign) => {
    setSelectedCampaign(campaign);
    // Ensure all fields from initialResumeCampaign are present, especially for older saved campaigns
    const completeCampaignConfig = {
      ...initialResumeCampaign, // Default structure
      ...campaign, // Overwrite with saved values
      prefillFields: { // Ensure prefillFields is an object
        ...initialResumeCampaign.prefillFields,
        ...(campaign.prefillFields || {})
      },
      variantB: { // Ensure variantB is an object
        ...initialResumeCampaign.variantB,
        ...(campaign.variantB || {})
      }
    };
    setCurrentConfig(completeCampaignConfig);
  };
  
  const handleDeleteCampaign = (campaignId) => {
    const campaignToDelete = campaigns.find(c => c.id === campaignId);
    setCampaigns(prev => prev.filter(c => c.id !== campaignId));
    if (selectedCampaign && selectedCampaign.id === campaignId) {
      handleNewCampaign();
    }
    toast({ title: "Campaign Deleted", description: `"${campaignToDelete?.name}" has been removed.`, variant: "destructive" });
  };


  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <Rewind className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Auto Resume Landing Page Engine
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Craft personalized re-engagement pages for leads who drop off mid-flow.
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        <motion.div variants={itemVariants} className="lg:col-span-1 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3 flex flex-row justify-between items-center">
              <CardTitle className="text-lg font-semibold text-foreground">Resume Campaigns</CardTitle>
              <Button size="sm" variant="outline" onClick={handleNewCampaign} className="shadcn-button"><PlusCircle className="h-4 w-4 mr-1.5" /> New</Button>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-2.5 max-h-[calc(100vh-350px)] overflow-y-auto scrollbar-hide">
              {campaigns.length === 0 ? <p className="text-xs text-muted-foreground text-center py-4">No resume campaigns created yet.</p> : campaigns.map(c => (
                <div key={c.id} className={`p-2.5 rounded-md border cursor-pointer ${selectedCampaign?.id === c.id ? 'bg-primary/10 border-primary/50' : 'bg-muted/30 hover:bg-muted/50 border-transparent'}`} onClick={() => handleSelectCampaign(c)}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-foreground">{c.name}</span>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={(e) => {e.stopPropagation(); handleDeleteCampaign(c.id);}}><Trash2 size={12}/></Button>
                    </div>
                  </div>
                  <p className="text-[11px] text-muted-foreground">Target: {c.targetSegment}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    {selectedCampaign ? <Edit3 className="h-5 w-5 text-primary" /> : <PlusCircle className="h-5 w-5 text-primary" />}
                    <CardTitle className="text-lg font-semibold text-foreground">{selectedCampaign ? `Edit: ${currentConfig.name}` : 'Create Resume Campaign'}</CardTitle>
                </div>
                <Button onClick={handleSaveCampaign} className="shadcn-button" size="sm"><Settings2 className="h-4 w-4 mr-1.5"/> Save Campaign</Button>
              </div>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
              <div>
                <Label htmlFor="rcName" className="text-xs">Campaign Name</Label>
                <Input id="rcName" value={currentConfig.name} onChange={e => handleInputChange('name', e.target.value)} className="shadcn-input mt-1 text-sm" />
              </div>
              <div>
                <Label htmlFor="rcTargetSegment" className="text-xs">Target Segment</Label>
                <Select value={currentConfig.targetSegment} onValueChange={val => handleInputChange('targetSegment', val)}>
                  <SelectTrigger id="rcTargetSegment" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="shadcn-select-content">
                    <SelectItem value="all_dropoffs" className="shadcn-select-item">All Drop-offs</SelectItem>
                    <SelectItem value="cart_abandonment_high_value" className="shadcn-select-item">Cart Abandonment (High Value)</SelectItem>
                    <SelectItem value="form_incomplete_step3" className="shadcn-select-item">Form Incomplete (Step 3+)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Pre-fill Form Fields (from CRM/URL)</Label>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
                  {Object.keys(currentConfig.prefillFields).map(key => (
                    <div key={key} className="flex items-center space-x-1.5">
                      <Checkbox id={`pf-${key}`} checked={currentConfig.prefillFields[key]} onCheckedChange={checked => handleCheckboxChange('prefillFields', key, checked)} />
                      <Label htmlFor={`pf-${key}`} className="text-xs font-normal capitalize">{key.replace(/([A-Z])/g, ' $1')}</Label>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <Label htmlFor="rcWelcomeHeadline" className="text-xs">Welcome Headline</Label>
                <Input id="rcWelcomeHeadline" value={currentConfig.welcomeHeadline} onChange={e => handleInputChange('welcomeHeadline', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="Welcome back, {{FirstName}}!"/>
              </div>
              <div>
                <Label htmlFor="rcSubHeadline" className="text-xs">Sub-Headline</Label>
                <Input id="rcSubHeadline" value={currentConfig.subHeadline} onChange={e => handleInputChange('subHeadline', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="Let's finish this in 2 minutes."/>
              </div>
               <div>
                <Label htmlFor="rcCtaText" className="text-xs">CTA Button Text</Label>
                <Input id="rcCtaText" value={currentConfig.ctaText} onChange={e => handleInputChange('ctaText', e.target.value)} className="shadcn-input mt-1 text-sm" />
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <Checkbox id="countdownTimerEnabled" checked={currentConfig.countdownTimerEnabled} onCheckedChange={checked => handleInputChange('countdownTimerEnabled', checked)} />
                <Label htmlFor="countdownTimerEnabled" className="text-xs font-normal">Enable Countdown Timer</Label>
              </div>
              {currentConfig.countdownTimerEnabled && (
                <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} transition={{duration:0.3}} className="pl-3 border-l-2 border-primary/30">
                  <Label htmlFor="rcCountdownDuration" className="text-xs">Countdown Duration (HH:MM:SS)</Label>
                  <Input id="rcCountdownDuration" value={currentConfig.countdownDuration} onChange={e => handleInputChange('countdownDuration', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="00:30:00"/>
                </motion.div>
              )}

              <div className="flex items-center space-x-2 pt-1">
                <Checkbox id="logicHighlightEnabled" checked={currentConfig.logicHighlightEnabled} onCheckedChange={checked => handleInputChange('logicHighlightEnabled', checked)} />
                <Label htmlFor="logicHighlightEnabled" className="text-xs font-normal">Enable Logic-Based Product Highlight</Label>
              </div>
              {currentConfig.logicHighlightEnabled && (
                <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} transition={{duration:0.3}} className="pl-3 border-l-2 border-primary/30 space-y-2">
                   <div className="grid grid-cols-2 gap-2">
                        <div>
                            <Label htmlFor="rcLogicCondition" className="text-xs">Highlight Condition</Label>
                            <Select value={currentConfig.logicHighlightCondition} onValueChange={val => handleInputChange('logicHighlightCondition', val)}>
                            <SelectTrigger id="rcLogicCondition" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                            <SelectContent className="shadcn-select-content">
                                <SelectItem value="zip_code" className="shadcn-select-item">Based on ZIP Code</SelectItem>
                                <SelectItem value="job_title" className="shadcn-select-item">Based on Job Title</SelectItem>
                                <SelectItem value="previous_interest" className="shadcn-select-item">Based on Previous Interest</SelectItem>
                                <SelectItem value="behavior_score" className="shadcn-select-item">Based on Behavior Score</SelectItem>
                            </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label htmlFor="rcLogicValue" className="text-xs">Condition Value</Label>
                            <Input id="rcLogicValue" value={currentConfig.logicHighlightValue} onChange={e => handleInputChange('logicHighlightValue', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="e.g., 90210, Teacher, ProductX"/>
                        </div>
                   </div>
                   <div>
                        <Label htmlFor="rcLogicProduct" className="text-xs">Product/Service to Highlight</Label>
                        <Input id="rcLogicProduct" value={currentConfig.logicHighlightProduct} onChange={e => handleInputChange('logicHighlightProduct', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="e.g., Premium Telemed for CA"/>
                   </div>
                </motion.div>
              )}


              <div className="flex items-center space-x-2 pt-1">
                <Checkbox id="abTestEnabled" checked={currentConfig.abTestEnabled} onCheckedChange={checked => handleInputChange('abTestEnabled', checked)} />
                <Label htmlFor="abTestEnabled" className="text-xs font-normal">Enable A/B Test Variant</Label>
              </div>

              {currentConfig.abTestEnabled && (
                <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} transition={{duration:0.3}} className="pl-3 border-l-2 border-primary/30 space-y-2">
                  <p className="text-xs font-medium text-primary">Variant B Configuration:</p>
                  <div>
                    <Label htmlFor="rcVariantBHeadline" className="text-xs">Variant B Headline</Label>
                    <Input id="rcVariantBHeadline" value={currentConfig.variantB.headline} onChange={e => handleVariantBChange('headline', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="Alternative welcome headline"/>
                  </div>
                  <div>
                    <Label htmlFor="rcVariantBSubHeadline" className="text-xs">Variant B Sub-Headline</Label>
                    <Input id="rcVariantBSubHeadline" value={currentConfig.variantB.subHeadline} onChange={e => handleVariantBChange('subHeadline', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="Alternative sub-headline"/>
                  </div>
                  <div>
                    <Label htmlFor="rcVariantBCta" className="text-xs">Variant B CTA Text</Label>
                    <Input id="rcVariantBCta" value={currentConfig.variantB.ctaText} onChange={e => handleVariantBChange('ctaText', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="Alternative CTA"/>
                  </div>
                </motion.div>
              )}
              <Button variant="outline" className="w-full shadcn-button text-xs" onClick={() => alert("Conceptual Preview: This would open a new tab/modal showing the landing page with current settings and mock data like 'Welcome back, John!' and a countdown.")}><Eye size={14} className="mr-2"/> Preview Landing Page (Mock)</Button>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
       <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Dynamic Re-Engagement Engine</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This engine designs personalized landing pages (e.g., yourdomain.com/resume?id=UNIQUE_ID) to re-capture leads. Data is pre-filled from CRM/URL. Urgency (timers) and logic-based highlights enhance conversion. Actual page generation and A/B testing logic require backend integration.
            </p>
        </div>
      </motion.div>
    </div>
  );
}