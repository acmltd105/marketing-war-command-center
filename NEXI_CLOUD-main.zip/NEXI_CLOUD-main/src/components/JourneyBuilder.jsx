import React from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { JourneyTemplates } from '@/components/audience/JourneyTemplates';
import { TwilioEngageProfile } from '@/components/audience/TwilioEngageProfile';
import { GitFork, PlusCircle, AlertTriangle, Zap, MessageSquare, Bell, Settings, MousePointerSquareDashed, Network, LayoutTemplate, UserCog } from 'lucide-react';

const nodeTypes = [
  { name: 'Trigger: Lead Created', icon: Zap, type: 'trigger_lead_created', category: 'Triggers' },
  { name: 'Trigger: Form Submitted', icon: MousePointerSquareDashed, type: 'trigger_form_submit', category: 'Triggers' },
  { name: 'Action: Send SMS', icon: MessageSquare, type: 'action_send_sms', category: 'Actions' },
  { name: 'Action: Send Email', icon: Bell, type: 'action_send_email', category: 'Actions' },
  { name: 'Logic: If/Else', icon: GitFork, type: 'condition_if_else', category: 'Logic' },
  { name: 'Logic: Audience Rule', icon: Network, type: 'logic_audience_rule', category: 'Logic' },
  { name: 'Utility: Wait Timer', icon: Settings, type: 'settings_wait', category: 'Utilities' },
];

const Canvas = () => {
    const [nodes, setNodes] = React.useState([]);

    const addNode = (type) => {
        const newNode = {
        id: `node-${Date.now()}`,
        type,
        name: nodeTypes.find(n => n.type === type)?.name || 'New Node',
        position: { x: Math.random() * 350 + 50, y: Math.random() * 150 + 50 }, 
        };
        setNodes(prev => [...prev, newNode]);
    };

    return (
        <div className="flex-grow grid grid-cols-12 gap-4 md:gap-6 h-full">
            <aside className="col-span-12 md:col-span-3 lg:col-span-2">
            <Card className="frosty-glass p-0.5 h-full">
                <CardHeader className="px-3 py-3 md:px-4 md:py-4">
                <CardTitle className="text-base md:text-lg font-semibold text-foreground">Journey Nodes</CardTitle>
                <CardDescription className="text-xs">Drag or click to add</CardDescription>
                </CardHeader>
                <CardContent className="px-3 pb-3 md:px-4 md:pb-4 space-y-2">
                {Object.entries(nodeTypes.reduce((acc, node) => {
                    if (!acc[node.category]) acc[node.category] = [];
                    acc[node.category].push(node);
                    return acc;
                }, {})).map(([category, nodesInCategory]) => (
                    <div key={category} className="mb-2">
                    <h4 className="text-[10px] md:text-xs font-semibold text-muted-foreground mb-1 uppercase tracking-wider">{category}</h4>
                    {nodesInCategory.map(node => (
                        <motion.div
                        key={node.type}
                        className="p-2 border border-border/40 rounded-md cursor-pointer flex items-center gap-2 hover:bg-primary/5 bg-background/20 transition-colors mb-1.5 text-xs"
                        onClick={() => addNode(node.type)}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        >
                        <node.icon className="h-3.5 w-3.5 text-primary opacity-75" />
                        <span className="font-medium text-foreground text-[11px] md:text-xs">{node.name}</span>
                        </motion.div>
                    ))}
                    </div>
                ))}
                </CardContent>
            </Card>
            </aside>
            <main className="col-span-12 md:col-span-9 lg:col-span-10 frosty-glass p-3 md:p-5 rounded-lg relative min-h-[400px] md:min-h-[500px]">
            {nodes.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center border-2 border-dashed border-border/30 rounded-md py-10">
                <GitFork className="h-12 w-12 md:h-14 md:w-14 text-muted-foreground opacity-40 mb-3" />
                <h3 className="text-lg md:text-xl font-semibold text-foreground">Design Your Customer Journey</h3>
                <p className="text-xs md:text-sm text-muted-foreground mt-1 mb-3">Add nodes from the left panel to start building your automated workflow.</p>
                <Button variant="outline" size="sm" className="shadcn-button text-xs" onClick={() => addNode(nodeTypes[0].type)}>
                    <PlusCircle className="h-3.5 w-3.5 mr-1.5"/> Add First Node
                </Button>
                </div>
            )}
            <div className="absolute inset-2 md:inset-4 overflow-hidden">
                {nodes.map(node => (
                <motion.div
                    key={node.id}
                    initial={{ opacity:0, scale:0.75 }}
                    animate={{ opacity:1, scale:1 }}
                    className="frosty-glass p-2.5 rounded-md shadow-lg absolute w-40 md:w-44 cursor-grab"
                    style={{ top: node.position.y, left: node.position.x }}
                    drag 
                    dragConstraints={{ top: 0, left: 0, right: 500, bottom: 300 }} 
                    dragMomentum={false} 
                >
                    <div className="flex items-center gap-1.5 mb-1">
                        {React.createElement(nodeTypes.find(n => n.type === node.type)?.icon || Zap, {className: "h-3.5 w-3.5 text-primary shrink-0"})}
                        <p className="text-[10px] md:text-xs font-semibold text-foreground truncate">{node.name}</p>
                    </div>
                    <p className="text-[9px] md:text-[10px] text-muted-foreground">ID: {node.id.substring(node.id.length - 6)}</p>
                    {node.type === 'logic_audience_rule' && <p className="text-[9px] text-blue-500 mt-0.5">Links to Audience Logic Tree</p>}
                </motion.div>
                ))}
            </div>
            {nodes.length > 0 && (
                <div className="absolute bottom-4 right-4 md:bottom-5 md:right-5">
                    <Button size="sm" className="shadcn-button text-xs">
                        Save Journey
                    </Button>
                </div>
            )}
            </main>
        </div>
    );
}

const JourneyBuilder = () => {
  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <GitFork className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Customer Journeys & Audiences
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Visually design, templatize, and power your customer interactions with unified profile data.
          </p>
        </div>
      </motion.header>

      <Tabs defaultValue="canvas" className="w-full flex-grow flex flex-col">
        <TabsList className="grid w-full grid-cols-3 gap-1 p-1 shadcn-tabs-list mb-4">
          <TabsTrigger value="canvas" className="shadcn-tabs-trigger"><GitFork className="h-4 w-4 mr-2" />Canvas</TabsTrigger>
          <TabsTrigger value="templates" className="shadcn-tabs-trigger"><LayoutTemplate className="h-4 w-4 mr-2" />Templates</TabsTrigger>
          <TabsTrigger value="profile" className="shadcn-tabs-trigger"><UserCog className="h-4 w-4 mr-2" />Unified Profile</TabsTrigger>
        </TabsList>
        <TabsContent value="canvas" className="flex-grow">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }} className="h-full">
            <Canvas />
          </motion.div>
        </TabsContent>
        <TabsContent value="templates" className="flex-grow">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
                <JourneyTemplates />
            </motion.div>
        </TabsContent>
        <TabsContent value="profile" className="flex-grow">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
                <TwilioEngageProfile />
            </motion.div>
        </TabsContent>
      </Tabs>
      
       <motion.div 
        initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.4}}
        className="mt-auto pt-4"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Engagement Suite - Alpha</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
                This is a conceptual demonstration of Twilio's engagement tools. The templates and profile are for visualization.
                The canvas allows adding/dragging nodes. Full logic, connections, and API integrations are planned for future iterations.
            </p>
        </div>
      </motion.div>
    </div>
  );
};

export { JourneyBuilder };
