import React, { useState, useEffect, useRef } from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Send, AlertTriangle, TrendingUp, PhoneIncoming, PhoneOutgoing, Users } from 'lucide-react';

const AnimatedDigit = ({ digit, height }) => {
  const spring = useSpring(digit, { stiffness: 200, damping: 20 });

  useEffect(() => {
    spring.set(digit);
  }, [digit, spring]);

  const y = useTransform(spring, (latest) => `-${latest * height}px`);

  return (
    <div style={{ height: `${height}px` }} className="overflow-hidden w-[1ch]">
      <motion.div style={{ y }} className="flex flex-col items-center justify-start">
        {[...Array(10).keys()].map((i) => (
          <span key={i} style={{ height: `${height}px` }} className="flex items-center justify-center">
            {i}
          </span>
        ))}
      </motion.div>
    </div>
  );
};

const SlotMachineCounter = ({ value, height = 28, padLength = 6 }) => {
  const digits = String(value).padStart(padLength, '0').split('');
  return (
    <div className="flex">
      {digits.map((digit, index) => (
        <AnimatedDigit key={index} digit={parseInt(digit, 10)} height={height} />
      ))}
    </div>
  );
};

const StatDisplay = ({ title, value, icon: Icon, colorClass, trend, padLength = 6 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }} /* Adjusted for pop-out */
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "circOut" }} /* Adjusted for pop-out */
      className="frosty-glass p-0.5 rounded-lg flex-1 min-w-[180px] sm:min-w-[200px]" /* Adjusted for pop-out */
    >
      <Card className="h-full bg-card/70 backdrop-blur-sm"> {/* Slightly more blur for pop-out */ }
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 pt-2.5 px-3"> {/* Compact header */ }
          <CardTitle className="text-xs font-medium text-muted-foreground">{title}</CardTitle>
          <Icon className={`h-4 w-4 ${colorClass} opacity-75`} /> {/* Smaller icon */ }
        </CardHeader>
        <CardContent className="pb-2.5 px-3"> {/* Compact content */ }
          <div className={`text-2xl font-bold ${colorClass} tabular-nums tracking-tight`}> {/* Smaller text */ }
            <SlotMachineCounter value={value} height={24} padLength={padLength} /> {/* Smaller digits */ }
          </div>
          {trend !== undefined && (
            <div className={`text-[10px] flex items-center mt-0.5 ${trend > 0 ? 'text-green-500' : trend < 0 ? 'text-red-500' : 'text-muted-foreground'}`}> {/* Smaller trend text */ }
              <TrendingUp size={12} className={`mr-0.5 ${trend < 0 ? 'transform rotate-180' : ''} ${trend === 0 ? 'opacity-50' : ''}`} />
              {trend > 0 ? '+' : ''}{trend.toFixed(1)}%
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};


export function RealTimeStatsCounter() {
  const [textsSent, setTextsSent] = useState(12345);
  const [errorsLogged, setErrorsLogged] = useState(78);
  const [inboundCalls, setInboundCalls] = useState(56);
  const [outboundCalls, setOutboundCalls] = useState(102);
  const [activeInteractions, setActiveInteractions] = useState(158);


  useEffect(() => {
    const textsInterval = setInterval(() => {
      setTextsSent(prev => prev + Math.floor(Math.random() * 10) + 1);
    }, 1500); 

    const errorsInterval = setInterval(() => {
      if (Math.random() < 0.1) { 
        setErrorsLogged(prev => prev + 1);
      }
    }, 5000);

    const inboundInterval = setInterval(() => {
      setInboundCalls(prev => prev + Math.floor(Math.random() * 3));
    }, 2500);

    const outboundInterval = setInterval(() => {
      setOutboundCalls(prev => prev + Math.floor(Math.random() * 5));
    }, 2000);
    
    const activeInteractionsInterval = setInterval(() => {
        setActiveInteractions(inboundCalls + outboundCalls + Math.floor(Math.random()*5));
    }, 1000);


    return () => {
      clearInterval(textsInterval);
      clearInterval(errorsInterval);
      clearInterval(inboundInterval);
      clearInterval(outboundInterval);
      clearInterval(activeInteractionsInterval);
    };
  }, [inboundCalls, outboundCalls]);

  return (
    <motion.div 
      className="p-3 bg-background/30 backdrop-blur-md rounded-b-lg shadow-xl border-x border-b border-border/50" /* Pop-out panel styling */
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3, ease: "circOut" }}
    >
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 md:gap-3"> {/* Adjusted grid for pop-out */ }
        <StatDisplay 
          title="Texts Sent" 
          value={textsSent} 
          icon={Send} 
          colorClass="text-sky-400"
          trend={Math.random() * 5 + 2} 
        />
        <StatDisplay 
          title="Errors Logged" 
          value={errorsLogged} 
          icon={AlertTriangle} 
          colorClass="text-amber-400"
          trend={Math.random() * 1 - 0.5}
          padLength={3}
        />
         <StatDisplay 
          title="Inbound Calls" 
          value={inboundCalls} 
          icon={PhoneIncoming} 
          colorClass="text-emerald-400"
          trend={Math.random() * 2 + 0.5}
          padLength={3}
        />
        <StatDisplay 
          title="Outbound Calls" 
          value={outboundCalls} 
          icon={PhoneOutgoing} 
          colorClass="text-violet-400"
          trend={Math.random() * 3 - 1}
          padLength={3}
        />
        <StatDisplay 
          title="Active Interactions" 
          value={activeInteractions} 
          icon={Users} 
          colorClass="text-pink-400"
          trend={Math.random() * 1.5}
          padLength={3}
        />
      </div>
    </motion.div>
  );
}