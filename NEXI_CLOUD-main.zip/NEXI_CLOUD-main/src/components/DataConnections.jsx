import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { Database, Plus, Edit2, Trash2, AlertTriangle, CheckCircle2, Link as LinkIcon, Server, User, Key as KeyIcon, Shield, TestTube2 } from 'lucide-react';

const cardVariants = {
  hidden: { opacity: 0, y: 25, scale: 0.96 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.04,
      duration: 0.45,
      ease: [0.2, 0.8, 0.2, 1]
    }
  }),
  exit: { opacity: 0, x: -25, transition: { duration: 0.3, ease: "easeIn" } }
};

const formVariants = {
  hidden: { opacity: 0, height: 0, y: -25 },
  visible: { opacity: 1, height: 'auto', y: 0, transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] } },
  exit: { opacity: 0, height: 0, y: -25, transition: { duration: 0.35, ease: [0.76, 0, 0.24, 1] } }
};


const initialConnections = [
  { id: 'db1', name: 'Primary Marketing DB', type: 'MySQL', host: 'mysql.example.com', databaseName: 'prod_db', status: 'connected', lastChecked: new Date().toISOString(), username: 'user_prod' },
  { id: 'db2', name: 'Customer Analytics Store', type: 'PostgreSQL', host: 'pg.analytics.example.com', databaseName: 'analytics_data', status: 'error', lastChecked: new Date(Date.now() - 7200000).toISOString(), username: 'analyst' },
];

export function DataConnections() {
  const [connections, setConnections] = useState(initialConnections);
  const [showForm, setShowForm] = useState(false);
  const [editingConnection, setEditingConnection] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    type: 'MySQL',
    host: '',
    port: '',
    username: '',
    password: '',
    databaseName: '',
  });
  const [testingId, setTestingId] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value, port: getDefaultPort(value) }));
  };

  const getDefaultPort = (type) => {
    if (type === 'MySQL') return '3306';
    if (type === 'PostgreSQL') return '5432';
    if (type === 'MSSQL') return '1433';
    return '';
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.host || !formData.username || !formData.databaseName) {
        toast({ title: "Missing Fields", description: "Please fill in all required database connection details.", variant: "destructive", duration: 3000 });
        return;
    }

    if (editingConnection) {
      setConnections(prev => prev.map(conn => conn.id === editingConnection.id ? { ...conn, ...formData, status: 'pending', lastChecked: new Date().toISOString() } : conn));
      toast({ title: "Connection Updated", description: `Details for "${formData.name}" saved. Test connection to verify.`, duration: 3000 });
    } else {
      const newConnection = { id: `db${Date.now()}`, ...formData, status: 'pending', lastChecked: new Date().toISOString() };
      setConnections(prev => [...prev, newConnection]);
      toast({ title: "Connection Added", description: `"${formData.name}" added. Please test the connection.`, duration: 3000 });
    }
    resetForm();
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingConnection(null);
    setFormData({ name: '', type: 'MySQL', host: '', port: getDefaultPort('MySQL'), username: '', password: '', databaseName: '' });
  };

  const handleEdit = (connection) => {
    setEditingConnection(connection);
    setFormData({
        name: connection.name,
        type: connection.type,
        host: connection.host,
        port: connection.port || getDefaultPort(connection.type),
        username: connection.username || '',
        password: '', 
        databaseName: connection.databaseName || ''
    });
    setShowForm(true);
  };

  const handleDelete = (id) => {
    const connToRemove = connections.find(c => c.id === id);
    setConnections(prev => prev.filter(conn => conn.id !== id));
    toast({ title: "Connection Removed", description: `"${connToRemove.name}" database connection configuration has been removed.`, duration: 3000 });
  };

  const testConnection = async (id) => {
    setTestingId(id);
    const connToTest = connections.find(c => c.id === id);
    toast({ title: "Testing Connection...", description: `Attempting to connect to "${connToTest.name}".`, duration: 2500 });
    
    await new Promise(resolve => setTimeout(resolve, 2200)); 
    
    const success = Math.random() > 0.35; 
    setConnections(prev => prev.map(conn => conn.id === id ? { ...conn, status: success ? 'connected' : 'error', lastChecked: new Date().toISOString() } : conn));
    setTestingId(null);

    if (success) {
      toast({ title: "Connection Successful!", description: `Successfully connected to "${connToTest.name}".`, variant: "default", duration: 3000 });
    } else {
      toast({ title: "Connection Failed", description: `Could not connect to "${connToTest.name}". Check details & network.`, variant: "destructive", duration: 4000 });
    }
  };

  return (
    <div className="space-y-8 md:space-y-10">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "circOut" }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div>
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground tracking-tight">Database Connections</h2>
          <p className="text-base md:text-lg text-muted-foreground mt-1">Manage connections to your SQL databases for campaign data.</p>
        </div>
        <Button onClick={() => { setShowForm(true); setEditingConnection(null); resetForm(); }} className="shadcn-button mt-3 sm:mt-0">
          <Plus className="h-4 w-4 mr-1.5" /> Add New Connection
        </Button>
      </motion.div>

      <AnimatePresence>
      {showForm && (
        <motion.div 
            key="db-connection-form"
            variants={formVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="mb-6 md:mb-8 overflow-hidden"
        >
          <Card className="frosty-glass p-0.5">
            <CardHeader className="px-5 md:px-6 pt-5 md:pt-6 pb-4">
              <CardTitle className="text-xl md:text-2xl font-semibold text-foreground">{editingConnection ? 'Edit Database Connection' : 'Add New Database Connection'}</CardTitle>
              <CardDescription className="text-sm md:text-base">{editingConnection ? `Modifying: ${editingConnection.name}` : 'Configure connection parameters for your SQL database.'}</CardDescription>
            </CardHeader>
            <CardContent className="px-5 md:px-6 pb-5 md:pb-6">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Connection Name *</label>
                    <Input name="name" value={formData.name} onChange={handleInputChange} placeholder="e.g., Main Production DB" className="shadcn-input" required />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Database Type *</label>
                    <Select name="type" value={formData.type} onValueChange={(value) => handleSelectChange('type', value)}>
                      <SelectTrigger className="shadcn-input"><SelectValue /></SelectTrigger>
                      <SelectContent className="shadcn-select-content">
                        <SelectItem value="MySQL" className="shadcn-select-item">MySQL</SelectItem>
                        <SelectItem value="PostgreSQL" className="shadcn-select-item">PostgreSQL</SelectItem>
                        <SelectItem value="MSSQL" className="shadcn-select-item">SQL Server (MSSQL)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Host Address *</label>
                    <Input name="host" value={formData.host} onChange={handleInputChange} placeholder="e.g., db.example.com or IP" className="shadcn-input" required />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Port</label>
                    <Input name="port" type="number" value={formData.port} onChange={handleInputChange} placeholder={getDefaultPort(formData.type)} className="shadcn-input" />
                  </div>
                   <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Database Name *</label>
                    <Input name="databaseName" value={formData.databaseName} onChange={handleInputChange} placeholder="e.g., marketing_data" className="shadcn-input" required/>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Username *</label>
                    <Input name="username" value={formData.username} onChange={handleInputChange} placeholder="Database user" className="shadcn-input" required />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Password</label>
                    <Input name="password" type="password" value={formData.password} onChange={handleInputChange} placeholder="••••••••" className="shadcn-input" />
                  </div>
                </div>
                <div className="pt-3 flex gap-3">
                  <Button type="submit" className="shadcn-button">
                    <LinkIcon className="w-4 h-4 mr-2"/>
                    {editingConnection ? 'Save Changes' : 'Add Connection'}
                  </Button>
                  <Button type="button" variant="outline" className="shadcn-button" onClick={resetForm}>Cancel</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      )}
      </AnimatePresence>

      {connections.length > 0 ? (
        <motion.div 
          className="space-y-5"
          initial="hidden"
          animate="visible"
          variants={{ visible: { transition: { staggerChildren: 0.06 } } }}
        >
          {connections.map((conn, index) => {
            const Icon = conn.type === 'MySQL' ? Database : conn.type === 'PostgreSQL' ? Server : Database;
            const isTestingThis = testingId === conn.id;
            const statusColor = conn.status === 'connected' ? 'text-green-600' : conn.status === 'error' ? 'text-red-600' : 'text-yellow-600';
            const StatusIcon = conn.status === 'connected' ? CheckCircle2 : conn.status === 'error' ? AlertTriangle : LinkIcon;
            return (
            <motion.div key={conn.id} variants={cardVariants} custom={index}>
              <Card className="frosty-glass">
                <CardContent className="p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5 flex-grow">
                    <Icon className={`h-9 w-9 ${statusColor} opacity-75`} />
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground text-md">{conn.name} <span className="text-xs font-normal text-muted-foreground">({conn.type})</span></h4>
                      <p className="text-xs text-muted-foreground">Host: {conn.host}{conn.port ? `:${conn.port}` : ''} {conn.databaseName ? `| DB: ${conn.databaseName}` : ''}</p>
                       <p className={`text-xs flex items-center gap-1 mt-1.5 ${statusColor}`}>
                        <StatusIcon className="inline h-3.5 w-3.5" />
                        <span className="capitalize font-medium">{conn.status}</span>
                         <span className="text-muted-foreground/80 ml-1"> (Checked: {new Date(conn.lastChecked).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})})</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2.5 shrink-0 mt-3 sm:mt-0 self-center sm:self-auto">
                    <Button size="sm" variant="outline" className="shadcn-button" onClick={() => testConnection(conn.id)} disabled={isTestingThis}>
                      {isTestingThis ? <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-primary mr-1.5"></div> : <TestTube2 className="h-3.5 w-3.5 mr-1.5 opacity-80" />}
                      {isTestingThis ? 'Testing...' : 'Test'}
                    </Button>
                    <Button size="sm" variant="outline" className="shadcn-button" onClick={() => handleEdit(conn)}><Edit2 className="h-3.5 w-3.5 opacity-80" /></Button>
                    <Button size="sm" variant="destructive" className="shadcn-button bg-destructive/90 hover:bg-destructive" onClick={() => handleDelete(conn.id)}><Trash2 className="h-3.5 w-3.5 opacity-80" /></Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
          })}
        </motion.div>
      ) : (
         <motion.div 
            initial={{ opacity: 0, y: 15 }} 
            animate={{ opacity: 1, y: 0 }} 
            className="text-center py-16 md:py-20 border-2 border-dashed border-border/50 rounded-lg frosty-glass"
          >
          <Database className="h-16 w-16 text-muted-foreground mx-auto mb-5 opacity-60" />
          <h3 className="text-xl font-semibold text-foreground mb-2.5">No Database Connections Yet</h3>
          <p className="text-base text-muted-foreground mb-6 max-w-md mx-auto">Add your SQL database connections to integrate with campaigns and unlock data-driven insights.</p>
          <Button className="shadcn-button" onClick={() => { setShowForm(true); setEditingConnection(null); resetForm(); }}>
            <Plus className="h-5 w-5 mr-2" /> Add First Connection
          </Button>
        </motion.div>
      )}
      
      <motion.div
        initial={{ opacity: 0, y:15 }}
        animate={{ opacity: 1, y:0 }}
        transition={{ delay: connections.length * 0.06 + (showForm ? 0.45 : 0) }}
      >
        <Card className="frosty-glass mt-10 md:mt-12 p-0.5">
          <CardHeader className="px-5 pt-5 pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2 text-foreground"><Shield className="h-5 w-5 text-amber-500 opacity-90"/>Important Security Note</CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-5">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Database credentials entered here are handled locally within your browser for configuration and testing purposes. 
              For production environments, always utilize secure methods like environment variables or a dedicated secrets management service (e.g., Supabase Secrets) once backend integration is established.
              Avoid committing sensitive credentials directly into frontend code.
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}