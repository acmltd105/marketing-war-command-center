
import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { useAppContext } from '@/contexts/AppContext';
import { SmsTestSender } from '@/components/SmsTestSender'; // New Import
import { Search, Phone, MessageSquare, Image as ImageIcon, Hash, Globe, Loader2, CheckCircle, XCircle, ShoppingCart, Star, Shield, PlusCircle, TestTube as TestTubeDiagonal } from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: { y: 0, opacity: 1 }
};

const CapabilityBadge = ({ icon: Icon, enabled, label }) => (
  <Badge variant={enabled ? "default" : "outline"} className={`flex items-center gap-1.5 transition-all duration-200 ${enabled ? 'bg-green-500/15 text-green-700' : 'text-muted-foreground'}`}>
    <Icon className="h-3.5 w-3.5" />
    <span>{label}</span>
  </Badge>
);

const SearchNumbers = ({ onPurchase }) => {
  const [searchParams, setSearchParams] = useState({ country: 'US', type: 'local', contains: '' });
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isBuying, setIsBuying] = useState(null);

  const handleSearch = async () => {
    setIsLoading(true);
    setSearchResults([]);
    try {
      const { data, error } = await supabase.functions.invoke('twilio-services-proxy', {
        body: { action: 'search_numbers', payload: { country: searchParams.country, type: searchParams.type } },
      });

      if (error || !data.success) throw new Error(error?.message || data.error);
      
      let filteredData = data.data;
      if (searchParams.contains) {
        filteredData = filteredData.filter(n => n.phoneNumber.includes(searchParams.contains));
      }
      setSearchResults(filteredData);

    } catch (err) {
      toast({ title: "Search Failed", description: `Could not fetch numbers. ${err.message}`, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleBuy = async (number) => {
    setIsBuying(number.phoneNumber);
    try {
      await onPurchase(number);
      toast({ title: "Purchase Successful!", description: `Successfully provisioned ${number.friendlyName}.`, variant: "success" });
    } catch (err) {
      toast({ title: "Purchase Failed", description: err.message, variant: "destructive" });
    } finally {
      setIsBuying(null);
    }
  };

  return (
    <motion.div variants={itemVariants} className="space-y-6">
      <Card className="frosty-glass">
        <CardHeader>
          <CardTitle>Find Your Number</CardTitle>
          <CardDescription>Search for available local, mobile, or toll-free numbers.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Select value={searchParams.country} onValueChange={(value) => setSearchParams(p => ({ ...p, country: value }))}>
            <SelectTrigger><SelectValue placeholder="Country" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="US">United States</SelectItem>
              <SelectItem value="GB">United Kingdom</SelectItem>
            </SelectContent>
          </Select>
          <Select value={searchParams.type} onValueChange={(value) => setSearchParams(p => ({ ...p, type: value }))}>
            <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="local">Local</SelectItem>
              <SelectItem value="mobile">Mobile</SelectItem>
              <SelectItem value="tollFree">Toll-Free</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Contains digits (e.g., 555)"
            value={searchParams.contains}
            onChange={(e) => setSearchParams(p => ({ ...p, contains: e.target.value }))}
          />
          <Button onClick={handleSearch} disabled={isLoading} className="w-full">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4 mr-2" />}
            Search
          </Button>
        </CardContent>
      </Card>

      {isLoading && <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}

      {!isLoading && searchResults.length > 0 && (
        <div className="space-y-3">
          {searchResults.map(number => (
            <Card key={number.phoneNumber} className="frosty-glass flex items-center justify-between p-4">
              <div>
                <p className="font-mono text-lg text-foreground">{number.friendlyName}</p>
                <div className="flex items-center gap-2 mt-2">
                  <CapabilityBadge icon={Phone} enabled={number.capabilities.voice} label="Voice" />
                  <CapabilityBadge icon={MessageSquare} enabled={number.capabilities.SMS} label="SMS" />
                  <CapabilityBadge icon={ImageIcon} enabled={number.capabilities.MMS} label="MMS" />
                </div>
              </div>
              <Button onClick={() => handleBuy(number)} disabled={isBuying === number.phoneNumber} className="w-32">
                {isBuying === number.phoneNumber ? <Loader2 className="h-4 w-4 animate-spin" /> : <><ShoppingCart className="h-4 w-4 mr-2" /> Buy</>}
              </Button>
            </Card>
          ))}
        </div>
      )}
       {!isLoading && searchResults.length === 0 && (
        <div className="text-center py-12 frosty-glass rounded-lg">
            <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold text-foreground mb-1.5">No Numbers Found</h3>
            <p className="text-sm text-muted-foreground">Adjust your search criteria or try again.</p>
        </div>
      )}
    </motion.div>
  );
};

const MyNumbers = ({ ownedNumbers, isLoading, onToggleCapability }) => {
  if (isLoading) {
    return <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  if (ownedNumbers.length === 0) {
    return (
      <motion.div variants={itemVariants} className="text-center py-12 frosty-glass rounded-lg">
        <Phone className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
        <h3 className="text-lg font-semibold text-foreground mb-1.5">No Numbers Yet</h3>
        <p className="text-sm text-muted-foreground">Purchase a number from the "Search Numbers" tab to get started.</p>
      </motion.div>
    );
  }

  return (
    <motion.div variants={itemVariants} className="space-y-4">
      {ownedNumbers.map(number => (
        <Card key={number.id} className="frosty-glass p-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <p className="font-mono text-lg text-foreground">{number.friendly_name}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline">{number.number_type}</Badge>
                <Badge variant="outline">{number.country_code}</Badge>
              </div>
            </div>
            <div className="flex items-center gap-4 mt-4 md:mt-0">
              <CapabilityBadge icon={Phone} enabled={number.capabilities.voice} label="Voice" />
              <CapabilityBadge icon={MessageSquare} enabled={number.capabilities.SMS} label="SMS" />
              <CapabilityBadge icon={ImageIcon} enabled={number.capabilities.MMS} label="MMS" />
            </div>
          </div>
        </Card>
      ))}
    </motion.div>
  );
};

const ShortCodes = () => (
  <motion.div variants={itemVariants}>
    <Card className="frosty-glass">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Hash className="h-6 w-6 text-primary" /> Short Codes</CardTitle>
        <CardDescription>High-throughput numbers for A2P messaging. Application required.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Short codes are 5-6 digit numbers ideal for high-volume application-to-person (A2P) messaging like alerts, marketing notifications, and two-factor authentication. Due to carrier regulations, they require a manual application and approval process which can take several weeks.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-start gap-3 p-3 bg-background/30 rounded-lg">
            <Star className="h-5 w-5 text-amber-500 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold">High Throughput</h4>
              <p className="text-xs text-muted-foreground">Send hundreds of messages per second.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-background/30 rounded-lg">
            <Shield className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold">Carrier Approved</h4>
              <p className="text-xs text-muted-foreground">Pre-approved for A2P traffic, reducing filtering.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-background/30 rounded-lg">
            <Globe className="h-5 w-5 text-sky-500 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold">Brand Recognition</h4>
              <p className="text-xs text-muted-foreground">Easy to remember and builds trust.</p>
            </div>
          </div>
        </div>
        <Button onClick={() => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀", description: "Short code applications are handled directly with Twilio sales." })}>
          <PlusCircle className="h-4 w-4 mr-2" /> Start Application
        </Button>
      </CardContent>
    </Card>
  </motion.div>
);

export function PhoneServicesManager() {
  const [ownedNumbers, setOwnedNumbers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { withSavingState } = useAppContext();

  const fetchOwnedNumbers = useCallback(async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.from('owned_numbers').select('*').order('purchased_at', { ascending: false });
      if (error) throw error;
      setOwnedNumbers(data);
    } catch (error) {
      toast({ title: "Error", description: "Could not fetch your numbers.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchOwnedNumbers();
  }, [fetchOwnedNumbers]);

  const handlePurchase = async (numberToBuy) => {
    return withSavingState(async () => {
      const { data: purchaseData, error: purchaseError } = await supabase.functions.invoke('twilio-services-proxy', {
        body: { action: 'buy_number', payload: { ...numberToBuy, country: 'US' } },
      });

      if (purchaseError || !purchaseData.success) {
        throw new Error(purchaseError?.message || purchaseData.error || 'Failed to purchase number via proxy.');
      }

      const newNumber = purchaseData.data;

      const { error: dbError } = await supabase.from('owned_numbers').insert({
        sid: newNumber.sid,
        phone_number: newNumber.phoneNumber,
        friendly_name: newNumber.friendlyName,
        number_type: newNumber.numberType,
        country_code: newNumber.countryCode,
        capabilities: newNumber.capabilities,
      });

      if (dbError) {
        throw new Error(`Failed to save number to database: ${dbError.message}`);
      }
      await fetchOwnedNumbers();
    });
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="p-4 sm:p-6 md:p-8 h-full"
    >
      <motion.div variants={itemVariants} className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Phone Services</h1>
        <p className="text-muted-foreground mt-1">Search, provision, and manage your Twilio phone numbers and services.</p>
      </motion.div>

      <Tabs defaultValue="search" className="w-full">
        <motion.div variants={itemVariants}>
          <TabsList>
            <TabsTrigger value="search">Search Numbers</TabsTrigger>
            <TabsTrigger value="my-numbers">My Numbers</TabsTrigger>
            <TabsTrigger value="short-codes">Short Codes</TabsTrigger>
            <TabsTrigger value="sms-test">
              <TestTubeDiagonal className="h-4 w-4 mr-1.5" /> Test SMS
            </TabsTrigger>
          </TabsList>
        </motion.div>
        <TabsContent value="search" className="mt-6">
          <SearchNumbers onPurchase={handlePurchase} />
        </TabsContent>
        <TabsContent value="my-numbers" className="mt-6">
          <MyNumbers ownedNumbers={ownedNumbers} isLoading={isLoading} />
        </TabsContent>
        <TabsContent value="short-codes" className="mt-6">
          <ShortCodes />
        </TabsContent>
        <TabsContent value="sms-test" className="mt-6">
          <SmsTestSender />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}
