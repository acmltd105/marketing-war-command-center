
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { CampaignHeader } from '@/components/campaign_manager_parts/CampaignHeader';
import { CampaignForm } from '@/components/campaign_manager_parts/CampaignForm';
import { CampaignList } from '@/components/campaign_manager_parts/CampaignList';
import { CampaignStatsTicker } from '@/components/campaign_manager_parts/CampaignStatsTicker';

const initialFormData = {
  name: '',
  type: 'sms', // sms, voice, email
  message: '',
  recipients: 0,
  segmentRules: [],
  budget: '',
  scheduledAt: '',
  senderId: '', // For SMS
  subject: '', // For Email
  senderEmail: '', // For Email
  isTimedCampaign: false,
  eventName: '',
  triggerType: 'specific_date', // specific_date, holiday
  holidayType: '',
  startDate: '',
  endDate: '',
  // New sending configuration fields
  sendingNumberType: '', // e.g., 'us_short_code', 'us_toll_free_verified'
  specificSendTime: '', // HH:MM
  mpsRate: null, // Messages Per Second
  mpmRate: null, // Messages Per Minute
  mp10mRate: null, // Messages Per 10 Minutes
  mphRate: null, // Messages Per Hour
  // countdownEnabled: false, // This was in HolidayUrgencyManager, might be different context
  // countdownDurationHours: 48,
  // targetSegment: 'all_users', // This was in HolidayUrgencyManager
};

export function CampaignManager({ data, addCampaign, updateCampaign, deleteCampaign }) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [formData, setFormData] = useState(initialFormData);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (editingCampaign) {
      setFormData({
        name: editingCampaign.name || '',
        type: editingCampaign.type || 'sms',
        message: editingCampaign.message || '',
        recipients: editingCampaign.recipients || 0,
        segmentRules: editingCampaign.segmentRules || [],
        budget: editingCampaign.budget?.toString() || '',
        scheduledAt: editingCampaign.scheduledAt ? new Date(editingCampaign.scheduledAt).toISOString().slice(0,16) : '',
        senderId: editingCampaign.senderId || '',
        subject: editingCampaign.subject || '',
        senderEmail: editingCampaign.senderEmail || '',
        isTimedCampaign: editingCampaign.isTimedCampaign || false,
        eventName: editingCampaign.eventName || editingCampaign.name || '',
        triggerType: editingCampaign.triggerType || 'specific_date',
        holidayType: editingCampaign.holidayType || '',
        startDate: editingCampaign.startDate ? new Date(editingCampaign.startDate).toISOString().split('T')[0] : '',
        endDate: editingCampaign.endDate ? new Date(editingCampaign.endDate).toISOString().split('T')[0] : '',
        // Sending config fields
        sendingNumberType: editingCampaign.sendingNumberType || '',
        specificSendTime: editingCampaign.specificSendTime || '',
        mpsRate: editingCampaign.mpsRate === undefined ? null : editingCampaign.mpsRate,
        mpmRate: editingCampaign.mpmRate === undefined ? null : editingCampaign.mpmRate,
        mp10mRate: editingCampaign.mp10mRate === undefined ? null : editingCampaign.mp10mRate,
        mphRate: editingCampaign.mphRate === undefined ? null : editingCampaign.mphRate,
      });
    } else {
      setFormData(prev => ({ ...initialFormData, type: prev.type, name: prev.name, eventName: prev.name }));
    }
  }, [editingCampaign, showCreateForm]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    let val = type === 'checkbox' ? checked : value;

    if (['mpsRate', 'mpmRate', 'mp10mRate', 'mphRate', 'budget'].includes(name)) {
        val = value === '' ? null : parseFloat(value);
        if (isNaN(val)) val = null;
    }

    setFormData(prev => ({ 
        ...prev, 
        [name]: val,
        ...(name === 'name' && !prev.isTimedCampaign && { eventName: val }),
        ...(name === 'name' && prev.isTimedCampaign && !prev.eventName && { eventName: val })
    }));
  };
  
  const handleSelectChange = (name, value) => {
     setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleAudienceUpdate = (rules, count) => {
    setFormData(prev => ({
      ...prev,
      segmentRules: rules,
      recipients: count,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    let errorMessages = [];
    if (!formData.name.trim()) errorMessages.push("Campaign Name is required.");
    if (formData.recipients <= 0) errorMessages.push("Audience must be calculated and greater than zero.");
    if (!formData.message.trim()) errorMessages.push("Message Content/Script is required.");
    if (formData.isTimedCampaign && !formData.startDate) errorMessages.push("Start Date is required for timed campaigns.");
    if (formData.isTimedCampaign && !formData.endDate) errorMessages.push("End Date is required for timed campaigns.");
    if (formData.type === 'sms' && !formData.senderId.trim()) errorMessages.push("Sender ID is required for SMS campaigns.");
    if (formData.type === 'sms' && !formData.sendingNumberType) errorMessages.push("Sending Number Type is required for SMS campaigns to determine throughput.");
    
    if (errorMessages.length > 0) {
      toast({
        title: "Validation Error",
        description: errorMessages.join(" \n"),
        variant: "destructive",
        duration: 4000,
      });
      return;
    }

    const campaignData = {
      id: editingCampaign ? editingCampaign.id : Date.now().toString(),
      name: formData.name,
      type: formData.type,
      message: formData.message,
      recipients: formData.recipients || 0,
      segmentRules: formData.segmentRules || [],
      budget: formData.budget === null ? 0 : parseFloat(formData.budget) || 0,
      status: editingCampaign ? editingCampaign.status : 'draft',
      scheduledAt: formData.isTimedCampaign ? null : (formData.scheduledAt || null),
      createdAt: editingCampaign ? editingCampaign.createdAt : new Date().toISOString(),
      senderId: formData.type === 'sms' ? formData.senderId : null,
      subject: formData.type === 'email' ? formData.subject : null,
      senderEmail: formData.type === 'email' ? formData.senderEmail : null,
      delivered: editingCampaign ? editingCampaign.delivered : 0,
      failed: editingCampaign ? editingCampaign.failed : 0,
      isTimedCampaign: formData.isTimedCampaign,
      eventName: formData.isTimedCampaign ? formData.eventName : null,
      triggerType: formData.isTimedCampaign ? formData.triggerType : null,
      holidayType: formData.isTimedCampaign && formData.triggerType === 'holiday' ? formData.holidayType : null,
      startDate: formData.isTimedCampaign ? formData.startDate : null,
      endDate: formData.isTimedCampaign ? formData.endDate : null,
      // Sending config
      sendingNumberType: formData.sendingNumberType,
      specificSendTime: formData.specificSendTime,
      mpsRate: formData.mpsRate,
      mpmRate: formData.mpmRate,
      mp10mRate: formData.mp10mRate,
      mphRate: formData.mphRate,
    };

    if (editingCampaign) {
      updateCampaign(editingCampaign.id, campaignData);
      toast({ title: "Campaign Updated", description: `Campaign "${campaignData.name}" has been successfully updated.`, duration: 3000 });
    } else {
      addCampaign(campaignData);
      toast({ title: "Campaign Created", description: `New campaign "${campaignData.name}" has been created as a draft.`, duration: 3000 });
    }

    setFormData(initialFormData);
    setShowCreateForm(false);
    setEditingCampaign(null);
  };

  const handleEdit = (campaign) => {
    setEditingCampaign(campaign);
    setShowCreateForm(true);
  };

  const handleCancelForm = () => {
    setShowCreateForm(false);
    setEditingCampaign(null);
    setFormData(initialFormData);
  }

  const handleStatusChange = (campaignId, currentStatus) => {
    let newStatus;
    let toastMessage = "";
    if (currentStatus === 'active') { newStatus = 'paused'; toastMessage = "Campaign Paused"; } 
    else if (currentStatus === 'paused') { newStatus = 'active'; toastMessage = "Campaign Resumed & Active"; } 
    else if (currentStatus === 'draft') { newStatus = 'active'; toastMessage = "Campaign Launched & Active!"; } 
    else { newStatus = 'active'; toastMessage = "Campaign Reactivated"; }
    
    updateCampaign(campaignId, { status: newStatus });
    toast({ title: toastMessage, description: `Campaign status changed to ${newStatus}.`, duration: 2500 });
  };
  
  const filteredCampaigns = data.campaigns.filter(campaign => {
    if (filter === 'all') return true;
    return campaign.status === filter;
  });

  return (
    <div className="space-y-6 md:space-y-8">
      <CampaignHeader 
        filter={filter} 
        setFilter={setFilter} 
        onNewCampaignClick={() => { setShowCreateForm(true); setEditingCampaign(null); setFormData(initialFormData);}} 
      />
      
      <CampaignStatsTicker campaigns={data.campaigns} />

      <CampaignForm 
        showForm={showCreateForm}
        editingCampaign={editingCampaign}
        formData={formData}
        onInputChange={handleInputChange}
        onSelectChange={handleSelectChange}
        onAudienceUpdate={handleAudienceUpdate}
        onSubmit={handleSubmit}
        onCancel={handleCancelForm}
      />

      <CampaignList
        campaigns={filteredCampaigns}
        filter={filter}
        onEdit={handleEdit}
        onStatusChange={handleStatusChange}
        onDelete={deleteCampaign}
        onNewCampaignClick={() => { setShowCreateForm(true); setEditingCampaign(null); setFormData(initialFormData);}}
      />
    </div>
  );
}
