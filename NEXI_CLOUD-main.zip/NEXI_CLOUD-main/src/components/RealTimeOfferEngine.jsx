import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, PlusCircle, Edit3, Trash2, Zap, Settings2, AlertTriangle, Info, Shuffle, Filter } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { staggerChildren: 0.1, delayChildren: i * 0.1, duration: 0.5, ease: "circOut" }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const initialRule = {
  id: '',
  name: 'New Upsell Rule',
  triggerType: 'link_click', // page_visit_duration, cart_add, score_threshold
  triggerCondition: '', // e.g., URL for link_click, duration in seconds, product ID, score value
  initialOffer: 'Standard Plan',
  upgradedOffer: 'Premium Plan - 10% Off First Month',
  displayMethod: 'inline_banner', // popup, inline_banner, chat_message
  status: 'Draft', // Draft, Active, Paused
};

const triggerTypeOptions = [
    { value: 'link_click', label: 'Lead Clicks Specific Link', placeholder: 'Enter URL or Link ID' },
    { value: 'page_visit_duration', label: 'Lead Spends X Time on Page (seconds)', placeholder: 'Enter duration in seconds (e.g., 60)' },
    { value: 'cart_add_item', label: 'Lead Adds Specific Item to Cart', placeholder: 'Enter Product ID or Name' },
    { value: 'score_threshold', label: 'Lead Score Exceeds Threshold', placeholder: 'Enter score (e.g., 75)' },
    { value: 'interaction_count', label: 'Lead Interacts X Times', placeholder: 'Enter interaction count (e.g., 3)' },
];

const displayMethodOptions = [
    { value: 'popup_modal', label: 'Pop-up Modal' },
    { value: 'inline_banner', label: 'Inline Banner/Section' },
    { value: 'chat_message_bot', label: 'Automated Chat Message' },
    { value: 'email_follow_up', label: 'Immediate Email Follow-up' },
];


export function RealTimeOfferEngine() {
  const [rules, setRules] = useState([]);
  const [selectedRule, setSelectedRule] = useState(null);
  const [currentConfig, setCurrentConfig] = useState({...initialRule});

  const handleInputChange = (field, value) => {
    setCurrentConfig(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSaveRule = () => {
    let ruleToSave = {...currentConfig};
    if (!ruleToSave.id) ruleToSave.id = `rule_${Date.now()}`;
    
    const existingIndex = rules.findIndex(r => r.id === ruleToSave.id);
    if (existingIndex > -1) {
      setRules(rules.map(r => r.id === ruleToSave.id ? ruleToSave : r));
    } else {
      setRules([...rules, ruleToSave]);
    }
    setSelectedRule(ruleToSave);
    // Add toast for success
  };

  const handleNewRule = () => {
    setSelectedRule(null);
    setCurrentConfig({...initialRule, id: `rule_${Date.now()}`});
  };

  const handleSelectRule = (rule) => {
    setSelectedRule(rule);
    setCurrentConfig(rule);
  };
  
  const handleDeleteRule = (ruleId) => {
    setRules(prev => prev.filter(r => r.id !== ruleId));
    if (selectedRule && selectedRule.id === ruleId) {
      handleNewRule();
    }
    // Add toast for deletion
  };

  const toggleRuleStatus = (ruleId, currentStatus) => {
    let newStatus = currentStatus === 'Active' ? 'Paused' : 'Active';
    if (currentStatus === 'Draft') newStatus = 'Active';

    setRules(prev => prev.map(r => r.id === ruleId ? { ...r, status: newStatus } : r));
     if (selectedRule && selectedRule.id === ruleId) {
        setCurrentConfig(prev => ({...prev, status:newStatus}));
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-6 text-foreground h-full flex flex-col flex-grow overflow-y-auto">
      <motion.header 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-center gap-3">
            <TrendingUp className="h-8 w-8 md:h-9 md:w-9 text-primary opacity-85" />
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Real-Time Offer Engine
            </h1>
          </div>
          <p className="mt-1 md:mt-1.5 text-xs sm:text-sm text-muted-foreground">
            Define rules to trigger instant offer upgrades based on lead interactions. (Conceptual Mockup)
          </p>
        </div>
      </motion.header>

      <motion.div 
        variants={sectionVariants} 
        initial="hidden" 
        animate="visible" 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 flex-grow"
      >
        <motion.div variants={itemVariants} className="lg:col-span-1 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
            <CardHeader className="px-5 pt-5 pb-3 flex flex-row justify-between items-center">
              <CardTitle className="text-lg font-semibold text-foreground">Upsell Rules</CardTitle>
              <Button size="sm" variant="outline" onClick={handleNewRule} className="shadcn-button"><PlusCircle className="h-4 w-4 mr-1.5" /> New Rule</Button>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-2.5 max-h-[calc(100vh-350px)] overflow-y-auto scrollbar-hide">
              {rules.length === 0 ? <p className="text-xs text-muted-foreground text-center py-4">No upsell rules defined.</p> : rules.map(r => (
                <div key={r.id} className={`p-2.5 rounded-md border cursor-pointer ${selectedRule?.id === r.id ? 'bg-primary/10 border-primary/50' : 'bg-muted/30 hover:bg-muted/50 border-transparent'}`} onClick={() => handleSelectRule(r)}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-foreground">{r.name}</span>
                    <Badge variant={r.status === 'Active' ? 'default' : 'outline'} className="shadcn-badge capitalize text-[10px]">{r.status}</Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground">Trigger: {triggerTypeOptions.find(t => t.value === r.triggerType)?.label || 'N/A'}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="lg:col-span-2 flex flex-col">
          <Card className="frosty-glass p-0.5 flex-grow">
             <CardHeader className="px-5 pt-5 pb-3">
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        {selectedRule ? <Edit3 className="h-5 w-5 text-primary" /> : <PlusCircle className="h-5 w-5 text-primary" />}
                        <CardTitle className="text-lg font-semibold text-foreground">{selectedRule ? `Edit: ${currentConfig.name}` : 'Create New Upsell Rule'}</CardTitle>
                    </div>
                    <Button onClick={handleSaveRule} className="shadcn-button" size="sm"><Settings2 className="h-4 w-4 mr-1.5"/> Save Rule</Button>
                </div>
            </CardHeader>
            <CardContent className="px-5 pb-5 space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-hide">
              <div>
                <Label htmlFor="ruleName" className="text-xs">Rule Name</Label>
                <Input id="ruleName" value={currentConfig.name} onChange={e => handleInputChange('name', e.target.value)} className="shadcn-input mt-1 text-sm" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                    <Label htmlFor="ruleTriggerType" className="text-xs">Trigger Type</Label>
                    <Select value={currentConfig.triggerType} onValueChange={val => handleInputChange('triggerType', val)}>
                        <SelectTrigger id="ruleTriggerType" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent className="shadcn-select-content">{triggerTypeOptions.map(opt => <SelectItem key={opt.value} value={opt.value} className="shadcn-select-item text-xs">{opt.label}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="ruleTriggerCondition" className="text-xs">Trigger Condition</Label>
                    <Input id="ruleTriggerCondition" value={currentConfig.triggerCondition} onChange={e => handleInputChange('triggerCondition', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder={triggerTypeOptions.find(t => t.value === currentConfig.triggerType)?.placeholder || 'Define condition value'}/>
                </div>
              </div>
              <div>
                <Label htmlFor="ruleInitialOffer" className="text-xs">Initial Offer Displayed (e.g., Product Name, Plan)</Label>
                <Input id="ruleInitialOffer" value={currentConfig.initialOffer} onChange={e => handleInputChange('initialOffer', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="Standard Plan"/>
              </div>
               <div>
                <Label htmlFor="ruleUpgradedOffer" className="text-xs">Upgraded Offer (e.g., Product Name, Discount)</Label>
                <Input id="ruleUpgradedOffer" value={currentConfig.upgradedOffer} onChange={e => handleInputChange('upgradedOffer', e.target.value)} className="shadcn-input mt-1 text-sm" placeholder="Premium Plan - 20% Off"/>
              </div>
              <div>
                <Label htmlFor="ruleDisplayMethod" className="text-xs">Display Method for Upgraded Offer</Label>
                <Select value={currentConfig.displayMethod} onValueChange={val => handleInputChange('displayMethod', val)}>
                    <SelectTrigger id="ruleDisplayMethod" className="shadcn-input mt-1 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent className="shadcn-select-content">{displayMethodOptions.map(opt => <SelectItem key={opt.value} value={opt.value} className="shadcn-select-item text-xs">{opt.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
               <div className="flex gap-2 pt-2">
                <Button variant="default" className="w-full shadcn-button text-xs" onClick={() => toggleRuleStatus(currentConfig.id, currentConfig.status)} disabled={!selectedRule}>
                   <Zap size={14} className="mr-2"/>
                   {currentConfig.status === 'Active' ? 'Pause Rule' : 'Activate Rule'}
                </Button>
                 <Button variant="outline" className="w-full shadcn-button text-xs" onClick={() => { if(selectedRule) handleDeleteRule(selectedRule.id) }} disabled={!selectedRule}>
                    <Trash2 size={14} className="mr-2"/> Delete Rule
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
      
      <motion.div 
        variants={itemVariants} 
        initial="hidden" 
        animate="visible" 
        custom={2} 
        className="mt-auto pt-6"
      >
        <div className="p-3 frosty-glass rounded-md">
            <div className="flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500"/>
                <h4 className="font-semibold text-foreground text-xs">Intelligent Upselling</h4>
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5">
               The Real-Time Offer Engine conceptualizes dynamic offer adjustments. Full functionality requires deep integration with website/app tracking, CRM data for context, and a rules engine backend.
            </p>
        </div>
      </motion.div>
    </div>
  );
}