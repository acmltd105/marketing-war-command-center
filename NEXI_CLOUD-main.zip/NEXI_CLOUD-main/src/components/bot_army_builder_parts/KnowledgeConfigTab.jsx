import React from 'react';
import { Button } from '@/components/ui/button';
import { BookOpen, DatabaseZap, FileText, Brain } from 'lucide-react';

export function KnowledgeConfigTab() {
  return (
    <div className="space-y-3 p-3 border border-dashed border-border/50 rounded-md min-h-[200px] flex flex-col items-center justify-center text-center">
      <BookOpen className="h-12 w-12 text-muted-foreground opacity-40 mb-2"/>
      <p className="text-sm font-medium text-muted-foreground">Knowledge Base & Training</p>
      <p className="text-xs text-muted-foreground/80">Connect data sources (FAQs, documents) or provide Q&A pairs to make your bot smarter. Fine-tune its responses with specific training data.</p>
      <div className="flex flex-wrap gap-2 mt-2.5 justify-center">
          <Button variant="outline" className="shadcn-button text-xs"><DatabaseZap size={13} className="mr-1"/> Connect Data Source (Mock)</Button>
          <Button variant="outline" className="shadcn-button text-xs"><FileText size={13} className="mr-1"/> Upload Documents (Mock)</Button>
          <Button variant="outline" className="shadcn-button text-xs"><Brain size={13} className="mr-1"/> Start Training (Mock)</Button>
      </div>
    </div>
  );
}