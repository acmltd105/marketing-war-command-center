import React from 'react';
import { Button } from '@/components/ui/button';
import { PlusCircle, MessageCircle as MessageCircleQuestion } from 'lucide-react';

export function IntentsConfigTab() {
  return (
    <div className="space-y-3 p-3 border border-dashed border-border/50 rounded-md min-h-[200px] flex flex-col items-center justify-center text-center">
      <MessageCircleQuestion className="h-12 w-12 text-muted-foreground opacity-40 mb-2"/>
      <p className="text-sm font-medium text-muted-foreground">Intent & Entity Management</p>
      <p className="text-xs text-muted-foreground/80">Define what users want to achieve (intents) and the key pieces of information (entities) needed. Example: Intent - 'Order Status', Entity - 'Order ID'.</p>
      <div className="flex gap-2 mt-2.5">
          <Button variant="outline" className="shadcn-button text-xs"><PlusCircle size={13} className="mr-1"/> Add Intent (Mock)</Button>
          <Button variant="outline" className="shadcn-button text-xs"><PlusCircle size={13} className="mr-1"/> Add Entity (Mock)</Button>
      </div>
    </div>
  );
}