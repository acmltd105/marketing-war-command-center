import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bot, PlusCircle, ListChecks, Edit3, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const itemVariants = {
  hidden: { opacity: 0, y: 15, scale: 0.98 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.35, ease: "circOut" } }
};

const getStatusColor = (status) => {
  if (status === 'Active') return 'bg-green-500';
  if (status === 'Training') return 'bg-yellow-500';
  if (status === 'Error') return 'bg-red-500';
  return 'bg-gray-400';
};

export function BotList({ bots, selectedBot, onSelectBot, onCreateNewBot, onDeleteBot }) {
  return (
    <Card className="frosty-glass p-0.5">
      <CardHeader className="px-5 pt-5 pb-3 flex flex-row justify-between items-center">
        <div className="flex items-center gap-2.5">
          <ListChecks className="h-5 w-5 text-primary opacity-90" />
          <CardTitle className="text-lg font-semibold text-foreground">My Bot Army ({bots.length})</CardTitle>
        </div>
        <Button size="sm" variant="outline" onClick={onCreateNewBot} className="shadcn-button">
          <PlusCircle className="h-4 w-4 mr-1.5" /> New Bot
        </Button>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-2.5 max-h-[calc(100vh-450px)] overflow-y-auto scrollbar-hide">
        {bots.length === 0 ? (
          <div className="text-center py-6">
            <Bot className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="text-sm text-muted-foreground">No bots deployed yet. Create your first AI assistant!</p>
          </div>
        ) : (
          bots.map(bot => (
            <motion.div
              key={bot.id}
              variants={itemVariants}
              className={cn(
                "p-3 rounded-md border cursor-pointer transition-all duration-200",
                selectedBot?.id === bot.id ? "frosty-glass ring-2 ring-primary bg-primary/5 shadow-lg" : "bg-muted/30 hover:bg-muted/50 border-transparent hover:border-primary/30"
              )}
              onClick={() => onSelectBot(bot)}
            >
              <div className="flex justify-between items-center mb-1">
                <h4 className="text-sm font-semibold text-foreground">{bot.name}</h4>
                <div className={`h-2.5 w-2.5 rounded-full ${getStatusColor(bot.status)}`} title={bot.status}></div>
              </div>
              <p className="text-[11px] text-muted-foreground capitalize">{bot.type} &bull; {bot.languageModel}</p>
              <div className="mt-2 flex gap-1.5">
                 <Button size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground hover:text-primary" onClick={(e) => {e.stopPropagation(); onSelectBot(bot);}}>
                    <Edit3 size={12} />
                 </Button>
                 <Button size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={(e) => {e.stopPropagation(); onDeleteBot(bot.id);}}>
                    <Trash2 size={12} />
                 </Button>
              </div>
            </motion.div>
          ))
        )}
      </CardContent>
    </Card>
  );
}