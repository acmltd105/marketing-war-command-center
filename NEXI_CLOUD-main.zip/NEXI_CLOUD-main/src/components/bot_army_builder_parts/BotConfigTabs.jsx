import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Cog, SlidersHorizontal, MessageCircle as MessageCircleQuestion, BookOpen, Share2, Rocket } from 'lucide-react';
import { GeneralConfigTab } from '@/components/bot_army_builder_parts/GeneralConfigTab';
import { BehaviorConfigTab } from '@/components/bot_army_builder_parts/BehaviorConfigTab';
import { IntentsConfigTab } from '@/components/bot_army_builder_parts/IntentsConfigTab';
import { KnowledgeConfigTab } from '@/components/bot_army_builder_parts/KnowledgeConfigTab';
import { ChannelsConfigTab } from '@/components/bot_army_builder_parts/ChannelsConfigTab';
import { DeployConfigTab } from '@/components/bot_army_builder_parts/DeployConfigTab';

export function BotConfigTabs({ 
  activeTab, 
  onTabChange, 
  currentBotConfig, 
  onInputChange, 
  onNestedInputChange,
  onGreetingChange,
  onAddGreeting,
  onRemoveGreeting,
  mockChat,
  userInput,
  onUserInput,
  onMockChatSubmit,
  onUpdateBotStatusAndSave
}) {
  const tabContent = [
    { value: "general", label: "General", icon: Cog, component: <GeneralConfigTab currentBotConfig={currentBotConfig} onInputChange={onInputChange} /> },
    { value: "behavior", label: "Behavior", icon: SlidersHorizontal, component: <BehaviorConfigTab currentBotConfig={currentBotConfig} onInputChange={onInputChange} onGreetingChange={onGreetingChange} addGreeting={onAddGreeting} removeGreeting={onRemoveGreeting} /> },
    { value: "intents", label: "Intents", icon: MessageCircleQuestion, component: <IntentsConfigTab /> },
    { value: "knowledge", label: "Knowledge", icon: BookOpen, component: <KnowledgeConfigTab /> },
    { value: "channels", label: "Channels", icon: Share2, component: <ChannelsConfigTab currentBotConfig={currentBotConfig} onNestedInputChange={onNestedInputChange} /> },
    { value: "deploy", label: "Deploy", icon: Rocket, component: <DeployConfigTab currentBotConfig={currentBotConfig} mockChat={mockChat} userInput={userInput} onUserInput={onUserInput} onMockChatSubmit={onMockChatSubmit} onUpdateBotStatusAndSave={onUpdateBotStatusAndSave} /> },
  ];

  return (
    <Tabs value={activeTab} onValueChange={onTabChange} className="w-full flex-grow flex flex-col">
      <TabsList className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-6 gap-1 mx-4 mt-3 mb-2 shadcn-tabs-list">
        {tabContent.map(tab => (
          <TabsTrigger key={tab.value} value={tab.value} className="shadcn-tabs-trigger">
            <tab.icon size={14} className="mr-1.5"/>{tab.label}
          </TabsTrigger>
        ))}
      </TabsList>

      <div className="px-4 pb-4 flex-grow overflow-y-auto scrollbar-hide">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: activeTab === "general" ? 0 : 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2, ease: "easeInOut" }}
            className="mt-2 space-y-5"
          >
            {tabContent.map(tab => (
              <TabsContent key={tab.value} value={tab.value} className="m-0 p-0">
                {tab.component}
              </TabsContent>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </Tabs>
  );
}