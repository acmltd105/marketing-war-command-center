import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Rocket, Play, Cog } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

export function DeployConfigTab({ currentBotConfig, mockChat, userInput, onUserInput, onMockChatSubmit, onUpdateBotStatusAndSave }) {
  
  const handleDeploy = () => {
    onUpdateBotStatusAndSave("Active");
    toast({title: "Bot Deployed (Mock)", description: `${currentBotConfig.name} is now active!`});
  };

  const handleDeactivate = () => {
    onUpdateBotStatusAndSave("Draft");
    toast({title: "Bot Deactivated (Mock)", description: `${currentBotConfig.name} is now in draft.`});
  };

  return (
    <div className="grid grid-rows-[auto_1fr] gap-4 h-full">
      <div className="space-y-3 p-3 border border-dashed border-border/50 rounded-md text-center">
          <Rocket className="h-12 w-12 text-muted-foreground opacity-40 mx-auto mb-2"/>
          <p className="text-sm font-medium text-muted-foreground">Test & Deploy Bot</p>
          <p className="text-xs text-muted-foreground/80 mb-2.5">Test your bot's responses and deploy it to your selected channels when ready.</p>
          <div className="flex gap-2 justify-center">
            <Button onClick={handleDeploy} className="shadcn-button text-xs" disabled={currentBotConfig.status === 'Active' || !currentBotConfig.name}><Play size={13} className="mr-1"/> Deploy Bot</Button>
            <Button variant="outline" className="shadcn-button text-xs" onClick={handleDeactivate} disabled={currentBotConfig.status !== 'Active' || !currentBotConfig.name}><Cog size={13} className="mr-1"/> Deactivate Bot</Button>
          </div>
      </div>
      <div className="flex-grow flex flex-col p-3 border border-dashed border-border/50 rounded-md">
          <Label className="text-xs font-medium text-muted-foreground mb-1.5">Mock Conversation Test:</Label>
          <div className="flex-grow bg-muted/20 rounded p-2 overflow-y-auto h-40 scrollbar-hide mb-2 space-y-1.5 text-xs">
              {mockChat.map((msg, i) => (
                  <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <p className={`max-w-[70%] p-1.5 px-2 rounded-lg ${msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-background text-foreground shadow-sm'}`}>
                          {msg.text}
                      </p>
                  </div>
              ))}
              {mockChat.length === 0 && <p className="text-center text-muted-foreground/70 italic pt-4">Test conversation will appear here.</p>}
          </div>
          <div className="flex gap-2">
              <Input value={userInput} onChange={e => onUserInput(e.target.value)} placeholder="Type your message..." className="shadcn-input text-xs h-8" onKeyPress={e => e.key === 'Enter' && onMockChatSubmit()}/>
              <Button onClick={onMockChatSubmit} size="sm" className="shadcn-button h-8 text-xs">Send</Button>
          </div>
      </div>
    </div>
  );
}