import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

export function GeneralConfigTab({ currentBotConfig, onInputChange }) {
  return (
    <div className="space-y-3.5">
      <div>
        <Label htmlFor="botName" className="text-xs font-medium text-muted-foreground">Bot Name</Label>
        <Input id="botName" value={currentBotConfig.name} onChange={(e) => onInputChange('name', e.target.value)} placeholder="e.g., SupportMaster 3000" className="shadcn-input mt-1" />
      </div>
      <div>
        <Label htmlFor="botDescription" className="text-xs font-medium text-muted-foreground">Description / Goal</Label>
        <Textarea id="botDescription" value={currentBotConfig.description} onChange={(e) => onInputChange('description', e.target.value)} placeholder="e.g., Handles customer support queries for order status and returns." className="shadcn-input mt-1 min-h-[60px]" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        <div>
          <Label htmlFor="botType" className="text-xs font-medium text-muted-foreground">Bot Type</Label>
          <Select value={currentBotConfig.type} onValueChange={(val) => onInputChange('type', val)}>
            <SelectTrigger id="botType" className="shadcn-input mt-1"><SelectValue /></SelectTrigger>
            <SelectContent className="shadcn-select-content">
              <SelectItem value="chatbot" className="shadcn-select-item">Chatbot (Text)</SelectItem>
              <SelectItem value="voicebot" className="shadcn-select-item">Voicebot (Speech)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="languageModel" className="text-xs font-medium text-muted-foreground">Language Model (NLP)</Label>
          <Select value={currentBotConfig.languageModel} onValueChange={(val) => onInputChange('languageModel', val)}>
            <SelectTrigger id="languageModel" className="shadcn-input mt-1"><SelectValue /></SelectTrigger>
            <SelectContent className="shadcn-select-content">
              <SelectItem value="gpt-4o" className="shadcn-select-item">GPT-4o (Advanced)</SelectItem>
              <SelectItem value="gpt-3.5-turbo" className="shadcn-select-item">GPT-3.5 Turbo</SelectItem>
              <SelectItem value="claude-3-opus" className="shadcn-select-item">Claude 3 Opus</SelectItem>
              <SelectItem value="custom-rasa" className="shadcn-select-item">Custom Rasa NLU</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="complianceProfile" className="text-xs font-medium text-muted-foreground">Compliance Profile</Label>
        <Select value={currentBotConfig.complianceProfile} onValueChange={(val) => onInputChange('complianceProfile', val)}>
          <SelectTrigger id="complianceProfile" className="shadcn-input mt-1"><SelectValue /></SelectTrigger>
          <SelectContent className="shadcn-select-content">
            <SelectItem value="standard" className="shadcn-select-item">Standard</SelectItem>
            <SelectItem value="hipaa" className="shadcn-select-item">HIPAA</SelectItem>
            <SelectItem value="pci-dss" className="shadcn-select-item">PCI-DSS</SelectItem>
            <SelectItem value="gdpr" className="shadcn-select-item">GDPR</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}