import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { PlusCircle, Trash2 } from 'lucide-react';

export function BehaviorConfigTab({ currentBotConfig, onInputChange, onGreetingChange, addGreeting, removeGreeting }) {
  return (
    <div className="space-y-4">
      <div>
        <Label className="text-xs font-medium text-muted-foreground">Greeting Messages (Bot says first)</Label>
        {currentBotConfig.greetingMessages.map((msg, index) => (
          <div key={index} className="flex items-center gap-2 mt-1">
            <Input value={msg} onChange={(e) => onGreetingChange(index, e.target.value)} placeholder={`Greeting ${index + 1}`} className="shadcn-input flex-grow"/>
            {currentBotConfig.greetingMessages.length > 1 && <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => removeGreeting(index)}><Trash2 size={13}/></Button>}
          </div>
        ))}
        <Button size="sm" variant="outline" className="shadcn-button mt-1.5 text-xs" onClick={addGreeting}><PlusCircle size={13} className="mr-1"/> Add Greeting</Button>
      </div>
      <div>
        <Label htmlFor="fallbackMessages" className="text-xs font-medium text-muted-foreground">Fallback / Error Messages</Label>
        <Textarea id="fallbackMessages" value={currentBotConfig.fallbackMessages.join('\n')} onChange={(e) => onInputChange('fallbackMessages', e.target.value.split('\n'))} placeholder="e.g., I'm sorry, I can't help with that." className="shadcn-input mt-1 min-h-[60px]" />
        <p className="text-[11px] text-muted-foreground/80 mt-0.5">Enter one message per line.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        <div>
          <Label htmlFor="humanHandoffTrigger" className="text-xs font-medium text-muted-foreground">Human Handoff Trigger</Label>
          <Select value={currentBotConfig.humanHandoffTrigger} onValueChange={(val) => onInputChange('humanHandoffTrigger', val)}>
            <SelectTrigger id="humanHandoffTrigger" className="shadcn-input mt-1"><SelectValue /></SelectTrigger>
            <SelectContent className="shadcn-select-content">
              <SelectItem value="never" className="shadcn-select-item">Never Handoff</SelectItem>
              <SelectItem value="3_failed_attempts" className="shadcn-select-item">3 Failed Attempts</SelectItem>
              <SelectItem value="specific_keyword" className="shadcn-select-item">Specific Keyword (e.g., 'agent')</SelectItem>
              <SelectItem value="negative_sentiment" className="shadcn-select-item">Negative Sentiment Detected</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="humanHandoffTarget" className="text-xs font-medium text-muted-foreground">Handoff Target/Queue</Label>
          <Input id="humanHandoffTarget" value={currentBotConfig.humanHandoffTarget} onChange={(e) => onInputChange('humanHandoffTarget', e.target.value)} placeholder="Queue SID or Email" className="shadcn-input mt-1" />
        </div>
      </div>
    </div>
  );
}