import React from 'react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Share2 } from 'lucide-react';

export function ChannelsConfigTab({ currentBotConfig, onNestedInputChange }) {
  return (
    <div className="space-y-3 p-3 border border-dashed border-border/50 rounded-md min-h-[200px] flex flex-col items-center justify-center text-center">
      <Share2 className="h-12 w-12 text-muted-foreground opacity-40 mb-2"/>
      <p className="text-sm font-medium text-muted-foreground">Channel Integration</p>
      <p className="text-xs text-muted-foreground/80">Enable and configure the communication channels where your bot will operate.</p>
      <div className="grid grid-cols-2 gap-3 mt-3 w-full max-w-sm">
        {Object.keys(currentBotConfig.channels).map(channelKey => (
            <div key={channelKey} className="flex items-center justify-between p-2.5 bg-muted/30 rounded-md">
                <Label htmlFor={`channel-${channelKey}`} className="text-xs font-medium capitalize">{channelKey}</Label>
                <Switch id={`channel-${channelKey}`} checked={currentBotConfig.channels[channelKey]} onCheckedChange={(checked) => onNestedInputChange('channels', channelKey, checked)} className="shadcn-switch" />
            </div>
        ))}
      </div>
    </div>
  );
}