import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';

const panelVariants = {
  hidden: { x: '100%' },
  visible: { x: 0, transition: { type: 'spring', stiffness: 300, damping: 30 } },
  exit: { x: '100%', transition: { ease: 'easeInOut' } },
};

export default function PropertiesPanel({ selectedNode, onClose, onPropertiesChange }) {
  const [properties, setProperties] = useState({});

  useEffect(() => {
    if (selectedNode) {
      setProperties(selectedNode.data.properties || {});
    }
  }, [selectedNode]);

  const handlePropertyChange = (key, value) => {
    const newProps = { ...properties, [key]: value };
    setProperties(newProps);
    onPropertiesChange(selectedNode.id, newProps);
  };

  const renderProperties = () => {
    if (!selectedNode) return null;

    switch (selectedNode.type) {
      case 'messageNode':
        return (
          <>
            <div className="flex items-center gap-3 mb-4">
                <MessageSquare className="h-6 w-6 text-primary" />
                <h3 className="text-lg font-semibold">Send Message Properties</h3>
            </div>
            <div>
              <Label htmlFor="messageBody" className="text-sm font-medium">Message Body</Label>
              <Textarea
                id="messageBody"
                value={properties.body || ''}
                onChange={(e) => handlePropertyChange('body', e.target.value)}
                className="mt-1 min-h-[120px]"
                placeholder="Enter the message to send. You can use {{variables}}."
              />
            </div>
            <div className="mt-4">
              <Label htmlFor="fromNumber" className="text-sm font-medium">From</Label>
              <Input
                id="fromNumber"
                value={properties.from || ''}
                onChange={(e) => handlePropertyChange('from', e.target.value)}
                className="mt-1"
                placeholder="e.g., {{contact.channel.address}}"
              />
            </div>
          </>
        );
      default:
        return (
            <>
                <h3 className="text-lg font-semibold mb-2">{selectedNode.data.label}</h3>
                <p className="text-sm text-muted-foreground mb-4">This node type does not have configurable properties in this editor yet.</p>
                <pre className="text-xs bg-muted p-2 rounded-md overflow-x-auto">
                    {JSON.stringify(selectedNode.data, null, 2)}
                </pre>
            </>
        );
    }
  };

  return (
    <AnimatePresence>
      {selectedNode && (
        <motion.div
          variants={panelVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          className="w-96 bg-background/80 backdrop-blur-lg border-l border-border shadow-2xl flex flex-col"
        >
          <header className="p-4 border-b border-border flex items-center justify-between flex-shrink-0">
            <h2 className="font-semibold">Properties</h2>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </header>
          <div className="p-4 flex-grow overflow-y-auto">
            {renderProperties()}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}