import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import { MessageSquare } from 'lucide-react';

const MessageNode = ({ data }) => {
  return (
    <div className="p-3 border-2 border-primary/60 rounded-lg bg-background shadow-lg w-64">
      <Handle type="target" position={Position.Top} className="w-2 h-2 !bg-teal-500" />
      <div className="flex items-center gap-2 mb-2">
        <MessageSquare className="h-5 w-5 text-primary" />
        <div className="font-bold text-sm text-foreground">{data.label}</div>
      </div>
      <p className="text-xs text-muted-foreground truncate">
        {data.properties?.body || 'No message configured.'}
      </p>
      <Handle type="source" position={Position.Bottom} className="w-2 h-2 !bg-blue-500" />
    </div>
  );
};

export default memo(MessageNode);