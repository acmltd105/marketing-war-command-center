import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, GitBranch, CheckSquare } from 'lucide-react';

const onDragStart = (event, nodeType) => {
  event.dataTransfer.setData('application/reactflow', nodeType);
  event.dataTransfer.effectAllowed = 'move';
};

const SidebarItem = ({ icon: Icon, label, nodeType }) => (
  <motion.div
    className="p-3 border border-border rounded-lg flex flex-col items-center justify-center cursor-grab frosty-glass hover:bg-primary/10 transition-colors duration-200"
    draggable
    onDragStart={(event) => onDragStart(event, nodeType)}
    whileHover={{ scale: 1.05 }}
    whileTap={{ scale: 0.95 }}
  >
    <Icon className="h-7 w-7 mb-2 text-primary" />
    <span className="text-xs font-medium text-center">{label}</span>
  </motion.div>
);

export default function FlowSidebar() {
  return (
    <aside className="w-64 p-4 border-r border-border bg-background/50 space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Widgets</h3>
      <p className="text-xs text-muted-foreground -mt-3">Drag these onto the canvas.</p>
      <div className="grid grid-cols-2 gap-3">
        <SidebarItem icon={MessageSquare} label="Send Message" nodeType="messageNode" />
        <SidebarItem icon={GitBranch} label="Split Branch" nodeType="default" />
        <SidebarItem icon={CheckSquare} label="Gather Input" nodeType="default" />
      </div>
      <div className="text-xs text-muted-foreground pt-4">
        More widgets like 'Make HTTP Request', 'Run Function', etc., can be added here.
      </div>
    </aside>
  );
}