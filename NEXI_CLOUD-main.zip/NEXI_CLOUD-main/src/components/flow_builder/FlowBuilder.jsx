import React, { useState, useCallback, useMemo } from 'react';
import ReactFlow, {
  MiniMap,
  Controls,
  Background,
  addEdge,
  useNodesState,
  useEdgesState,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';

import FlowSidebar from './FlowSidebar';
import PropertiesPanel from './PropertiesPanel';
import MessageNode from './nodes/MessageNode';

import { Button } from '@/components/ui/button';
import { ArrowLeft, Save, Send, Loader2 } from 'lucide-react';

const nodeTypes = { messageNode: MessageNode };

const transformToFlowElements = (definition) => {
  const nodes = [];
  const edges = [];
  let yPos = 100;

  definition.states.forEach((state, index) => {
    nodes.push({
      id: state.name,
      type: state.type === 'send-message' ? 'messageNode' : 'default',
      data: { label: state.name, properties: state.properties, transitions: state.transitions },
      position: { x: 250 * (index % 4), y: yPos },
    });
    if ((index + 1) % 4 === 0) yPos += 200;

    if (state.transitions) {
      state.transitions.forEach(transition => {
        edges.push({
          id: `e-${state.name}-${transition.next}`,
          source: state.name,
          target: transition.next,
          label: transition.event,
          animated: true,
        });
      });
    }
  });

  return { nodes, edges };
};

const transformToTwilioDefinition = (nodes, edges, initialDefinition) => {
    const newDefinition = JSON.parse(JSON.stringify(initialDefinition));
    const nodeStates = nodes.map(node => {
        const transitions = edges
            .filter(edge => edge.source === node.id)
            .map(edge => ({
                event: edge.label || 'next',
                next: edge.target,
                conditions: [] 
            }));
        
        const existingState = initialDefinition.states.find(s => s.name === node.id);
        
        return {
            name: node.id,
            type: existingState?.type || 'send-message',
            properties: node.data.properties,
            transitions: transitions,
        };
    });

    newDefinition.states = nodeStates;
    return newDefinition;
};


function FlowBuilder({ flow, initialDefinition, onBack }) {
  const { nodes: initialNodes, edges: initialEdges } = useMemo(() => transformToFlowElements(initialDefinition), [initialDefinition]);
  
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState(null);
  const [isSaving, setIsSaving] = useState(false);

  const onConnect = useCallback((params) => setEdges((eds) => addEdge(params, eds)), [setEdges]);

  const onNodeClick = (event, node) => {
    setSelectedNode(node);
  };

  const updateNodeProperties = (nodeId, newProperties) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === nodeId) {
          return {
            ...node,
            data: {
              ...node.data,
              properties: newProperties,
            },
          };
        }
        return node;
      })
    );
  };

  const handleSave = async (status) => {
    setIsSaving(status);
    const newDefinition = transformToTwilioDefinition(nodes, edges, initialDefinition);
    
    const { data, error } = await supabase.functions.invoke('twilio-proxy', {
        method: 'POST',
        body: JSON.stringify({
            path: `/flows/${flow.sid}`,
            definition: newDefinition,
            status: status,
            commitMessage: `Updated via NEXIE - ${status}`
        })
    });

    setIsSaving(false);

    if (error || data.error) {
        toast({ title: `Error ${status === 'published' ? 'Publishing' : 'Saving'} Flow`, description: error?.message || data.error, variant: "destructive" });
    } else {
        toast({ title: `Flow ${status === 'published' ? 'Published' : 'Saved'} Successfully`, description: `${flow.friendly_name} has been updated.` });
    }
  };

  return (
    <div className="w-full h-full flex flex-col">
      <header className="p-3 border-b border-border flex items-center justify-between bg-background/80 backdrop-blur-sm flex-shrink-0">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack}><ArrowLeft className="h-5 w-5" /></Button>
          <div>
            <h1 className="text-lg font-semibold">{flow.friendly_name}</h1>
            <p className="text-xs text-muted-foreground font-mono">{flow.sid}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => handleSave('draft')} disabled={!!isSaving}>
            {isSaving === 'draft' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save Draft
          </Button>
          <Button size="sm" onClick={() => handleSave('published')} disabled={!!isSaving}>
            {isSaving === 'published' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
            Save & Publish
          </Button>
        </div>
      </header>
      <div className="flex-grow flex">
        <FlowSidebar />
        <div className="flex-grow h-full" style={{ height: 'calc(100vh - 125px)' }}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeClick={onNodeClick}
            nodeTypes={nodeTypes}
            fitView
          >
            <Controls />
            <MiniMap />
            <Background variant="dots" gap={12} size={1} />
          </ReactFlow>
        </div>
        <PropertiesPanel 
            selectedNode={selectedNode} 
            onClose={() => setSelectedNode(null)}
            onPropertiesChange={updateNodeProperties}
        />
      </div>
    </div>
  );
}

export default FlowBuilder;