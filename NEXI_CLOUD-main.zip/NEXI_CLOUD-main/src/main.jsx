import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/styles/base.css';
import '@/styles/themes.css';
import '@/styles/components.css';
import '@/styles/utilities.css';
import { BrowserRouter } from 'react-router-dom';
import { AppProvider } from '@/contexts/AppContext';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AppProvider>
        <App />
      </AppProvider>
    </BrowserRouter>
  </React.StrictMode>
);