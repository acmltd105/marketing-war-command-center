import { useState, useEffect } from 'react';

const initialAnalytics = {
  totalMessages: 12560,
  totalCalls: 3450,
  totalSpent: 7890.50,
  deliveryRate: 98.5,
  activeCampaigns: 3,
  smsSent: 8500,
  voiceMinutes: 12000,
  emailSent: 4060,
};

const initialApiStatus = {
  messaging: 'operational',
  voice: 'operational',
  video: 'degraded_performance',
  verify: 'error',
  lookup: 'operational',
};

const initialCampaigns = [
  { id: '1', name: 'Q2 Product Launch SMS Blitz', type: 'sms', senderId: 'MyBrand', subject: null, senderEmail: null, message: 'Exciting news! Our new product line just dropped. Check it out now! [Link]', recipients: 4850, segmentRules: [], budget: 150, status: 'active', createdAt: '2025-04-10T10:00:00Z', scheduledAt: null, delivered: 4850, failed: 150 },
  { id: '2', name: 'Welcome Series - Email Drip', type: 'email', senderId: null, subject: 'Welcome to the Club!', senderEmail: 'welcome@example.com', message: 'Hi {{name}}, thanks for signing up! Here is your special offer...', recipients: 1200, segmentRules: [], budget: 50, status: 'active', createdAt: '2025-04-15T14:30:00Z', scheduledAt: null, delivered: 1150, failed: 50 },
  { id: '3', name: 'Customer Satisfaction Voice Survey', type: 'voice', senderId: null, subject: null, senderEmail: null, message: 'Hello, this is a short survey about your recent experience with us. Press 1 for yes, 2 for no.', recipients: 800, segmentRules: [], budget: 200, status: 'paused', createdAt: '2025-04-20T09:00:00Z', scheduledAt: '2025-05-01T10:00:00Z', delivered: 300, failed: 20 },
  { id: '4', name: 'Holiday Flash Sale Reminder', type: 'sms', senderId: 'SaleAlert', subject: null, senderEmail: null, message: 'Last chance for 50% off everything! Sale ends tonight. Shop now: [Link]', recipients: 0, segmentRules: [], budget: 250, status: 'draft', createdAt: '2025-05-01T11:00:00Z', scheduledAt: '2025-05-10T12:00:00Z', delivered: 0, failed: 0 },
];

const initialSettings = {
  notifications: {
    lowBalanceAlert: true,
    campaignCompletion: true,
    apiErrors: false,
  },
  billing: {
    currency: 'USD',
    paymentMethod: '**** **** **** 1234',
    autoRefillEnabled: false,
    autoRefillAmount: 50,
    spendingLimitEnabled: true,
    spendingLimitAmount: 1000,
  },
  team: [
    { id: 'user1', name: 'Alice Wonderland', role: 'Admin', email: 'alice@example.com' },
    { id: 'user2', name: 'Bob The Builder', role: 'Campaign Manager', email: 'bob@example.com' },
  ],
  twilioCredentials: {
    accountSid: '',
    authToken: '',
    messagingServiceSid: '',
    phoneNumberSid: '',
  }
};

const initialReports = {
  kpiOverview: {
    totalSpendYTD: 12850.75,
    overallDeliveryRate: 97.2,
    avgCostPerConversion: 1.85, 
    activeSubscribersGrowth: 15.3, 
    currency: 'USD',
  },
  detailedUsage: {
    smsMms: {
      sent: 135000,
      received: 12500,
      failed: 1800,
      deliveryRate: 98.7,
      spend: 4050.00,
      currency: 'USD',
    },
    voice: {
      minutesUsed: 75000,
      callsMade: 8200,
      callsReceived: 3500,
      avgCallDuration: 5.2, 
      spend: 3100.50,
      currency: 'USD',
    },
    email: {
      sent: 250000,
      openRate: 22.5,
      clickThroughRate: 3.1,
      spend: 650.25,
      currency: 'USD',
    },
    whatsApp: {
      messagesSent: 5000,
      messagesDelivered: 4950,
      messagesRead: 4500,
      spend: 150.00,
      currency: 'USD',
    }
  },
  campaignPerformance: [
    { campaignId: '1', campaignName: 'Q2 Product Launch SMS Blitz', type: 'sms', delivered: 4850, failed: 150, ctr: 0.15, cost: 145.50, conversionRate: 5.2, roi: 250 },
    { campaignId: '2', campaignName: 'Welcome Series - Email Drip', type: 'email', delivered: 1150, failed: 50, openRate: 0.45, clickRate: 0.10, cost: 25.00, conversionRate: 2.5, roi: 180 },
    { campaignId: 'cpn_voice_survey_003', campaignName: 'Post-Purchase Voice Feedback', type: 'voice', callsCompleted: 750, avgDuration: 1.5, cost: 75.00, responseRate: 65, sentimentScore: 0.8 },
    { campaignId: 'cpn_whatsapp_promo_004', campaignName: 'Exclusive WhatsApp Offer', type: 'whatsapp', messagesSent: 1200, readRate: 92, engagementRate: 35, cost: 30.00, conversionRate: 8.1, roi: 320 },
  ],
  usageSummary: { 
    period: 'Last 30 Days',
    totalSms: 12800,
    totalVoiceMinutes: 15000,
    totalEmails: 5200,
    totalCost: 950.75,
    currency: 'USD',
  },
  spendByService: [
    { service: 'SMS', spend: 4050.00 },
    { service: 'Voice', spend: 3100.50 },
    { service: 'Email', spend: 650.25 },
    { service: 'WhatsApp', spend: 150.00 },
    { service: 'Lookup', spend: 50.00 },
    { service: 'Verify', spend: 75.00 },
  ],
  dataFilters: {
    dateRange: 'Last 30 Days', 
    availableRanges: ['Last 7 Days', 'Last 30 Days', 'Last 90 Days', 'Year to Date', 'Custom Range'],
    customStartDate: null,
    customEndDate: null,
    campaignType: 'All',
    availableCampaignTypes: ['All', 'SMS', 'Email', 'Voice', 'WhatsApp'],
    specificSid: '',
  }
};


const LOCAL_STORAGE_KEY = 'twilioHubData_v5'; // Incremented version

export function useTwilioData() {
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [data, setData] = useState(() => {
    try {
      const storedData = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (storedData) {
        const parsed = JSON.parse(storedData);
        
        const mergedSettings = {
          ...initialSettings,
          ...parsed.settings,
          notifications: { ...initialSettings.notifications, ...(parsed.settings?.notifications || {}) },
          billing: { ...initialSettings.billing, ...(parsed.settings?.billing || {}) },
          twilioCredentials: { ...initialSettings.twilioCredentials, ...(parsed.settings?.twilioCredentials || {}) },
        };

        const mergedReports = {
          ...initialReports,
          ...parsed.reports,
          kpiOverview: {...initialReports.kpiOverview, ...(parsed.reports?.kpiOverview || {})},
          detailedUsage: {
            smsMms: {...initialReports.detailedUsage.smsMms, ...(parsed.reports?.detailedUsage?.smsMms || {})},
            voice: {...initialReports.detailedUsage.voice, ...(parsed.reports?.detailedUsage?.voice || {})},
            email: {...initialReports.detailedUsage.email, ...(parsed.reports?.detailedUsage?.email || {})},
            whatsApp: {...initialReports.detailedUsage.whatsApp, ...(parsed.reports?.detailedUsage?.whatsApp || {})},
          },
          campaignPerformance: Array.isArray(parsed.reports?.campaignPerformance) ? parsed.reports.campaignPerformance : initialReports.campaignPerformance,
          usageSummary: {...initialReports.usageSummary, ...(parsed.reports?.usageSummary || {})},
          spendByService: Array.isArray(parsed.reports?.spendByService) ? parsed.reports.spendByService : initialReports.spendByService,
          dataFilters: {...initialReports.dataFilters, ...(parsed.reports?.dataFilters || {})},
        };
        
        return {
          analytics: { ...initialAnalytics, ...parsed.analytics },
          apiStatus: { ...initialApiStatus, ...parsed.apiStatus },
          campaigns: Array.isArray(parsed.campaigns) ? parsed.campaigns : initialCampaigns,
          settings: mergedSettings,
          reports: mergedReports,
        };
      }
    } catch (error) {
      console.error("Error reading from localStorage:", error);
    }
    return { 
      analytics: initialAnalytics, 
      apiStatus: initialApiStatus, 
      campaigns: initialCampaigns,
      settings: initialSettings,
      reports: initialReports,
    };
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error("Error writing to localStorage:", error);
    }
  }, [data]);

  const addCampaign = (campaign) => {
    setData(prevData => ({
      ...prevData,
      campaigns: [...prevData.campaigns, campaign],
      analytics: {
        ...prevData.analytics,
        activeCampaigns: prevData.campaigns.filter(c => c.status === 'active').length + (campaign.status === 'active' ? 1:0),
      }
    }));
  };

  const updateCampaign = (campaignId, updatedFields) => {
    setData(prevData => {
      const updatedCampaigns = prevData.campaigns.map(c => 
        c.id === campaignId ? { ...c, ...updatedFields } : c
      );
      return {
        ...prevData,
        campaigns: updatedCampaigns,
        analytics: {
          ...prevData.analytics,
          activeCampaigns: updatedCampaigns.filter(c => c.status === 'active').length,
        }
      };
    });
  };

  const deleteCampaign = (campaignId) => {
    setData(prevData => {
      const updatedCampaigns = prevData.campaigns.filter(c => c.id !== campaignId);
       return {
        ...prevData,
        campaigns: updatedCampaigns,
        analytics: {
          ...prevData.analytics,
          activeCampaigns: updatedCampaigns.filter(c => c.status === 'active').length,
        }
      };
    });
  };

  const updateSettings = (category, newSettingsData) => {
    setData(prevData => ({
      ...prevData,
      settings: {
        ...prevData.settings,
        [category]: { 
          ...(prevData.settings[category] || {}), 
          ...newSettingsData,
        },
      },
    }));
  };
  
  const updateReportFilters = (newFilterData) => {
    setData(prevData => ({
      ...prevData,
      reports: {
        ...prevData.reports,
        dataFilters: {
          ...prevData.reports.dataFilters,
          ...newFilterData,
        }
      }
    }));
  };


  return {
    ...data,
    currentTab,
    setCurrentTab,
    addCampaign,
    updateCampaign,
    deleteCampaign,
    updateSettings,
    updateReportFilters,
  };
}
