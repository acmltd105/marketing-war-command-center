
import React, { createContext, useState, useContext, useCallback } from 'react';

const AppContext = createContext();

export const useAppContext = () => useContext(AppContext);

export const AppProvider = ({ children }) => {
  const [isSaving, setIsSaving] = useState(false);

  const withSavingState = useCallback(async (asyncFunc) => {
    setIsSaving(true);
    try {
      await asyncFunc();
    } catch (error) {
      console.error("An error occurred during save:", error);
    } finally {
      setTimeout(() => setIsSaving(false), 600);
    }
  }, []);

  const value = {
    isSaving,
    withSavingState,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
