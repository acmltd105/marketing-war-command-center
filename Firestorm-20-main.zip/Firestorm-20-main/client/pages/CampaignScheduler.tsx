import React from "react";
import CampaignScheduler from "../components/CampaignScheduler";

export default function CampaignSchedulerPage() {
  return (
    <div className="p-6">
      <CampaignScheduler />
    </div>
  );
}
