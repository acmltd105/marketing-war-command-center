# Twilio ASCII Command Map (React + Vite)

AI‑first, no‑human workflow with an **interactive ASCII diagram** you can move with arrow keys.
Includes:
- Full Twilio category families (Roman numerals) and **every usage category** shown on demand
- **Free & $0** tooling list (Conversations free tier, Studio/Functions, Event Streams, Content API, Pricing APIs, TwiML Bins, Test Creds)
- **Numbers & Short Code Fast‑Track** (TrustHub, A2P, provisioning, warm‑up)

## Run
```bash
npm i
npm run dev
```

Open http://localhost:5173

## Controls
- Click a stage in the legend to select
- Use **Arrow keys** to move the ASCII box
- Press **E** to toggle the full ASCII list for that stage's family
