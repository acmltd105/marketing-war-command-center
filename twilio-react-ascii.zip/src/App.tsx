import React, { useState } from 'react'
import AsciiWorkflow from './components/AsciiWorkflow'
import FreeTools from './components/FreeTools'
import NumbersAccelerator from './components/NumbersAccelerator'

type Tab = 'diagram' | 'catalog' | 'free' | 'numbers'

export default function App(){
  const [tab, setTab] = useState<Tab>('diagram')
  return (
    <div style={{maxWidth:1200, margin:'0 auto', padding:16}}>
      <h1 style={{margin:'8px 0 12px'}}>Twilio ASCII Command Map <span style={{fontSize:14, color:'#9bb0ca'}}>AI‑first • No Humans</span></h1>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <TabBtn label="Diagram" active={tab==='diagram'} onClick={()=>setTab('diagram')}/>
        <TabBtn label="Free Tools" active={tab==='free'} onClick={()=>setTab('free')}/>
        <TabBtn label="Numbers Fast‑Track" active={tab==='numbers'} onClick={()=>setTab('numbers')}/>
      </div>

      {tab==='diagram' && <AsciiWorkflow/>}
      {tab==='free' && <FreeTools/>}
      {tab==='numbers' && <NumbersAccelerator/>}

      <div style={{marginTop:16, fontSize:12, color:'#9bb0ca'}}>
        Controls: Click a stage in the legend to select. Use <b>Arrow keys</b> to move. Press <b>E</b> to toggle full ASCII list for that family.
      </div>
    </div>
  )
}

function TabBtn({label, active, onClick}:{label:string, active:boolean, onClick:()=>void}){
  return <button onClick={onClick} style={{padding:'8px 10px', borderRadius:8, border:'1px solid #1d2736', background: active?'#111a28':'#0e1623', color:'#e6edf3'}}>{label}</button>
}
