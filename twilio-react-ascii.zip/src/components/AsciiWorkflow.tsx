import React, { useEffect, useMemo, useRef, useState } from 'react'
import { FAMILIES, Family } from '../data/twilio'
import create from 'zustand'

type Node = { id: string, label: string, x: number, y: number, w: number, h: number, family: Family }
type Edge = { from: string, to: string }

type StoreState = {
  nodes: Node[]
  selected?: string
  setSelected: (id?: string)=>void
  move: (dx:number, dy:number)=>void
}

const GRID_W = 160
const GRID_H = 50

function boxToGrid(grid: string[][], n: Node){
  const {x,y,w,h} = n
  const maxY = Math.min(GRID_H-1, y+h-1)
  const maxX = Math.min(GRID_W-1, x+w-1)
  for(let i=y;i<=maxY;i++){
    for(let j=x;j<=maxX;j++){
      const top = i===y, bottom = i===maxY, left = j===x, right = j===maxX
      if((top||bottom) && (j>=x && j<=maxX)) grid[i][j] = (top||bottom) ? (j===x||j===maxX ? '+' : '-') : grid[i][j]
      if((left||right) && (i>=y && i<=maxY)) grid[i][j] = (left||right) ? (i===y||i===maxY ? '+' : '|') : grid[i][j]
    }
  }
  const label = `[${n.label}]`
  const lx = Math.max(x+1, Math.min(maxX-1, x + Math.floor((w - label.length)/2)))
  const ly = y + Math.floor(h/2)
  for(let k=0;k<label.length && lx+k<GRID_W;k++){
    grid[ly][lx+k] = label[k]
  }
}

function drawManhattan(grid: string[][], a: Node, b: Node){
  const ax = a.x + Math.floor(a.w/2), ay = a.y + a.h
  const bx = b.x + Math.floor(b.w/2), by = b.y - 1
  let x = ax, y = ay
  while(y<by && y<GRID_H){ grid[y][x] = '|'; y++ }
  while(x!==bx && y<GRID_H){
    grid[y][x] = x<bx ? '-' : '-'
    x += (bx>x?1:-1)
  }
  while(y<by && y<GRID_H){ grid[y][x] = '|'; y++ }
  if(y<GRID_H) grid[y][x] = 'v'
}

const useStore = create<StoreState>((set,get)=>({
  nodes: [],
  setSelected: (id)=> set({selected:id}),
  move: (dx,dy)=> set(s=>{
    const id = s.selected
    if(!id) return s
    const nodes = s.nodes.map(n=> n.id===id ? {...n, x: Math.max(0, Math.min(GRID_W-n.w, n.x+dx)), y: Math.max(0, Math.min(GRID_H-n.h, n.y+dy)) } : n)
    return {...s, nodes}
  })
}))

function initialNodes(): Node[] {
  const labels = [
    'Lead Ingest','Verify & Auth','Segment & Profile','Engage Campaigns','Nurture Journeys',
    'AI Voice Bots','Payments','Compliance & Trust','Observability','Optimization'
  ]
  const famMap: Record<string, Family[]> = {
    'Lead Ingest': FAMILIES.filter(f=> f.family.includes('Phone Numbers') || f.family.startsWith('Lookup')),
    'Verify & Auth': FAMILIES.filter(f=> f.family.startsWith('Verify')),
    'Segment & Profile': FAMILIES.filter(f=> f.family.startsWith('Studio') || f.family.startsWith('Verify')),
    'Engage Campaigns': FAMILIES.filter(f=> ['SMS & MMS','RCS (Rich Communication Services)','WhatsApp Business','Conversations / Chat (incl. legacy pchat)','Phone Numbers & Short Codes'].includes(f.family)),
    'Nurture Journeys': FAMILIES.filter(f=> f.family.startsWith('Studio') || f.family.startsWith('TaskRouter')),
    'AI Voice Bots': FAMILIES.filter(f=> f.family.startsWith('Voice') || f.family.startsWith('Elastic SIP Trunking')),
    'Payments': FAMILIES.filter(f=> f.family.startsWith('Voice')),
    'Compliance & Trust': FAMILIES.filter(f=> f.family.includes('Phone Numbers') || f.family.startsWith('Studio')),
    'Observability': FAMILIES.filter(f=> f.family.startsWith('Studio')),
    'Optimization': FAMILIES.filter(f=> f.family.startsWith('Studio'))
  }
  const positions = [
    (x:number,y:number)=>({x,y}),
    (x:number,y:number)=>({x,y}),
  ]
  const nodes: Node[] = [
    {id:'A', label:labels[0], x:2, y:2,  w:28, h:5, family: FAMILIES[5]},
    {id:'B', label:labels[1], x:34, y:2, w:28, h:5, family: FAMILIES[11]},
    {id:'C', label:labels[2], x:66, y:2, w:34, h:5, family: FAMILIES[12]},
    {id:'D', label:labels[3], x:104,y:2, w:44, h:5, family: FAMILIES[1]},
    {id:'E', label:labels[4], x:2,  y:12, w:30, h:5, family: FAMILIES[9]},
    {id:'F', label:labels[5], x:36, y:12, w:34, h:5, family: FAMILIES[0]},
    {id:'G', label:labels[6], x:74, y:12, w:20, h:5, family: FAMILIES[0]},
    {id:'H', label:labels[7], x:98, y:12, w:32, h:5, family: FAMILIES[12]},
    {id:'I', label:labels[8], x:134,y:12, w:22, h:5, family: FAMILIES[12]},
    {id:'J', label:labels[9], x:2,  y:22, w:24, h:5, family: FAMILIES[12]},
  ]
  return nodes
}

export default function AsciiWorkflow(){
  const [grid, setGrid] = useState<string[][]>(Array.from({length:GRID_H},()=>Array(GRID_W).fill(' ')))
  const [selected, setSelected] = useState<string | undefined>(undefined)
  const [expanded, setExpanded] = useState<boolean>(false)
  const nodes = useMemo(()=>initialNodes(), [])
  const edges: Edge[] = [
    {from:'A',to:'B'},{from:'B',to:'C'},{from:'C',to:'D'},
    {from:'D',to:'E'},{from:'E',to:'F'},{from:'F',to:'G'},
    {from:'G',to:'H'},{from:'H',to:'I'},{from:'I',to:'J'},
  ]

  function redraw(){
    const g = Array.from({length:GRID_H},()=>Array(GRID_W).fill(' '))
    nodes.forEach(n=> boxToGrid(g, n))
    edges.forEach(e=>{
      const a = nodes.find(n=>n.id===e.from)!
      const b = nodes.find(n=>n.id===e.to)!
      drawManhattan(g, a, b)
    })
    setGrid(g)
  }

  useEffect(()=>{ redraw() }, [])

  useEffect(()=>{
    function onKey(e: KeyboardEvent){
      if(!selected) return
      const node = nodes.find(n=>n.id===selected)!
      if(!node) return
      let moved=false
      if(e.key==='ArrowLeft'){ node.x=Math.max(0,node.x-1); moved=true }
      if(e.key==='ArrowRight'){ node.x=Math.min(GRID_W-node.w,node.x+1); moved=true }
      if(e.key==='ArrowUp'){ node.y=Math.max(0,node.y-1); moved=true }
      if(e.key==='ArrowDown'){ node.y=Math.min(GRID_H-node.h,node.y+1); moved=true }
      if(e.key==='e' || e.key==='E'){ setExpanded(v=>!v) }
      if(moved){ e.preventDefault(); redraw() }
    }
    window.addEventListener('keydown', onKey)
    return ()=> window.removeEventListener('keydown', onKey)
  }, [selected])

  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 380px', gap:16}}>
      <div>
        <div className="mono" style={{whiteSpace:'pre', background:'#0a1019', border:'1px solid #1d2736', borderRadius:10, padding:8, overflow:'auto'}} onClick={()=>setSelected(undefined)}>
          {grid.map(r=>r.join('')).join('\n')}
        </div>
        <div style={{marginTop:8, fontSize:13, color:'#9bb0ca'}} className="mono">
          Click a stage number (A–J) in the legend to select. Use <b>Arrow keys</b> to move. Press <b>E</b> to toggle details.
        </div>
      </div>
      <div style={{background:'#0a1019', border:'1px solid #1d2736', borderRadius:10, padding:12}}>
        <Legend nodes={nodes} selected={selected} onSelect={setSelected}/>
        <Details node={nodes.find(n=>n.id===selected)} expanded={expanded}/>
      </div>
    </div>
  )
}

function Legend({nodes, selected, onSelect}:{nodes:Node[], selected?:string, onSelect:(id:string)=>void}){
  return <div style={{display:'grid', gap:8}}>
    <div style={{fontWeight:700}}>Legend</div>
    {nodes.map(n=>(
      <button key={n.id} onClick={()=>onSelect(n.id)} style={{textAlign:'left', border:'1px solid #1d2736', background:selected===n.id?'#111a28':'#0e1623', color:'#e6edf3', borderRadius:8, padding:'8px'}}>
        <div className="mono">{n.id}. {n.label}</div>
        <div style={{fontSize:12, color:'#9bb0ca'}}>{n.family.family}</div>
      </button>
    ))}
  </div>
}

function Details({node, expanded}:{node?:Node, expanded:boolean}){
  if(!node) return <div style={{marginTop:12, color:'#9bb0ca'}}>Select a stage to see families & categories.</div>
  return <div style={{marginTop:12}}>
    <div style={{fontWeight:700, marginBottom:6}}>Stage: {node.label}</div>
    <div style={{fontSize:13, color:'#9bb0ca'}}>Primary family: {node.family.roman}. {node.family.family}</div>
    <div className="mono" style={{whiteSpace:'pre-wrap', fontSize:12, marginTop:8, background:'#0b111b', padding:8, borderRadius:8, border:'1px solid #1d2736'}}>
      {expanded ? node.family.categories.map((c,i)=> `${node.family.roman}.${i+1}  ${c}`).join('\n') : 'Press E to expand ASCII list of every category in this family.'}
    </div>
  </div>
}
