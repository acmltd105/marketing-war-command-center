import React from 'react'
import { NUMBERS_FAST_TRACK } from '../data/twilio'

export default function NumbersAccelerator(){
  return (
    <div style={{background:'#0a1019', border:'1px solid #1d2736', borderRadius:10, padding:12}}>
      <h3 style={{marginTop:0}}>Numbers & Short Code Fast‑Track (TrustHub Ready)</h3>
      <ol style={{margin:0, paddingLeft:18}}>
        {NUMBERS_FAST_TRACK.map((s,i)=>(
          <li key={i}><b>{s.step}:</b> {s.detail}</li>
        ))}
      </ol>
      <div style={{fontSize:12, color:'#9bb0ca', marginTop:8}}>
        Pro tip: use Messaging Service + Geo‑Match/Sticky Sender; auto‑rotate templates via Content API; stream carrier feedback via Event Streams.
      </div>
    </div>
  )
}
