import React from 'react'
import { FREE_TOOLS } from '../data/twilio'

export default function FreeTools(){
  return (
    <div style={{background:'#0a1019', border:'1px solid #1d2736', borderRadius:10, padding:12}}>
      <h3 style={{marginTop:0}}>Free & $0 Layers</h3>
      <ul style={{margin:0, paddingLeft:16}}>
        {FREE_TOOLS.map(t=> <li key={t.name}><b>{t.name}</b> — {t.note}</li>)}
      </ul>
    </div>
  )
}
