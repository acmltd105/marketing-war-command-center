export type Family = {
  roman: string;
  family: string;
  categories: string[];
};

export const FAMILIES: Family[] = [
  { roman: 'I', family: 'Voice & PSTN', categories: [
    'agent-conference','answering-machine-detection','amazon-polly','calls','calls-inbound',
    'calls-inbound-local','calls-inbound-mobile','calls-inbound-tollfree','calls-outbound','calls-sip',
    'calls-sip-inbound','calls-sip-outbound','calls-client','calls-globalconference','calls-media-stream-minutes',
    'call-progress-events','calls-pay-verb-transactions','calls-recordings','ivr-virtual-agent-genai',
    'ivr-virtual-agent-custom-voices','programmablevoice-platform','programmablevoiceconnectivity',
    'programmablevoiceconn-sip','programmablevoiceconn-sip-inbound','programmablevoiceconn-sip-outbound',
    'programmablevoiceconn-clientsdk','pstnconnectivity','pstnconnectivity-inbound','pstnconnectivity-outbound',
    'recordings','recordingstorage','speech-recognition','transcriptions','tts-google','virtual-agent',
    'voice-intelligence','voice-intelligence-transcription','voice-intelligence-operators','voice-insights',
    'voice-insights-ptsn-insights-on-demand-minute','voice-insights-sip-trunking-insights-on-demand-minute'
  ]},
  { roman: 'II', family: 'SMS & MMS', categories: [
    'a2p-registration-fees','sms','sms-inbound','sms-inbound-longcode','sms-inbound-shortcode',
    'sms-outbound','sms-outbound-longcode','sms-outbound-shortcode','sms-messages-carrierfees',
    'mms','mms-inbound','mms-inbound-longcode','mms-inbound-shortcode','mms-outbound',
    'mms-outbound-longcode','mms-outbound-shortcode','mms-messages-carrierfees','mediastorage'
  ]},
  { roman: 'III', family: 'RCS (Rich Communication Services)', categories: [
    'Usage-RCS-Messages','Usage-RCS-basic-Messages-Outbound','Usage-RCS-Single-Messages-Outbound',
    'Usage-RCS-Messages-Inbound','Usage-RCS-Messaging-Carrier-Fees','RCS-Activation-Fee'
  ]},
  { roman: 'IV', family: 'WhatsApp Business', categories: [
    'channels-whatsapp-template-authentication','channels-whatsapp-template-marketing',
    'channels-whatsapp-template-utility','channels-whatsapp-service',
    'channels-whatsapp-conversation-free','channels-messaging-inbound','channels-messaging-outbound'
  ]},
  { roman: 'V', family: 'Conversations / Chat (incl. legacy pchat)', categories: [
    'pchat-users','pchat-conv-med-storage'
  ]},
  { roman: 'VI', family: 'Phone Numbers & Short Codes', categories: [
    'phonenumbers','phonenumbers-local','phonenumbers-mobile','phonenumbers-tollfree',
    'phonenumbers-cps','phonenumbers-setups','shortcodes','shortcodes-customerowned',
    'shortcodes-mms-enablement','shortcodes-mps','shortcodes-random','shortcodes-uk','shortcodes-vanity'
  ]},
  { roman: 'VII', family: 'Lookup (Identity, Risk, Enrichment)', categories: [
    'lookups','carrier-lookups','calleridlookups','number-format-lookups','call-forwarding-lookups',
    'sim-swap-lookups','live-activity-lookups','enhanced-line-type-lookups','identity-match'
  ]},
  { roman: 'VIII', family: 'Elastic SIP Trunking', categories: [
    'trunking-origination','trunking-origination-local','trunking-origination-mobile','trunking-origination-tollfree',
    'trunking-termination','trunking-recordings','trunking-cps','trunking-secure',
    'voice-insights-sip-trunking-insights-on-demand-minute'
  ]},
  { roman: 'IX', family: 'Sync', categories: [
    'sync-actions','sync-endpoint-hours','sync-endpoint-hours-above-daily-cap'
  ]},
  { roman: 'X', family: 'TaskRouter (Workforce Routing)', categories: [
    'taskrouter-tasks'
  ]},
  { roman: 'XI', family: 'Programmable Video', categories: [
    'pv','group-rooms','group-rooms-participant-minutes','group-rooms-data-track','small-group-rooms',
    'small-group-rooms-participant-minutes','small-group-rooms-data-track','pv-rooms',
    'peer-to-peer-rooms-participant-minutes','video-recordings','group-rooms-recorded-minutes',
    'pv-composition-minutes','group-rooms-encrypted-media-recorded','group-rooms-media-stored',
    'group-rooms-media-downloaded','turnmegabytes','turnmegabytes-australia','turnmegabytes-brasil',
    'turnmegabytes-india','turnmegabytes-ireland','turnmegabytes-japan','turnmegabytes-singapore',
    'turnmegabytes-useast','turnmegabytes-uswest','turnmegabytes-germany'
  ]},
  { roman: 'XII', family: 'Verify & Authy', categories: [
    'verify-push','verify-totp','verify-sna','authy-phone-verifications','authy-verify-email-verifications',
    'authy-verify-outbound-email','verify-whatsapp-template-business-initiated','authy-authentications',
    'authy-calls-outbound','authy-monthly-fees','authy-phone-intelligence','authy-sms-outbound','authy-outbound-email'
  ]},
  { roman: 'XIII', family: 'Studio / Monitor / Event Streams / Engagement Suite / Other', categories: [
    'studio-engagements','monitor-reads','monitor-writes','monitor-storage','events',
    'engagement-suite-packaged-plans','sms-messages-features-engagement-suite','premiumsupport','totalprice'
  ]},
]

export const FREE_TOOLS = [
  { name: 'Content API Templates', note: 'No per-template fee; sending still bills' },
  { name: 'Conversations', note: 'Up to 200 MAU free' },
  { name: 'Studio', note: 'First 1,000 flow executions free/mo' },
  { name: 'Functions', note: 'First 10,000 invocations free/mo' },
  { name: 'Event Streams', note: 'No additional charge' },
  { name: 'TwiML Bins', note: 'No separate fee' },
  { name: 'Pricing APIs', note: 'Free to call' },
  { name: 'Test Credentials', note: 'Simulate SMS/calls in CI (Verify excluded)' },
];

export const NUMBERS_FAST_TRACK = [
  { step: 'TrustHub Brand', detail: 'Register brand + use-case early; upload docs once per entity' },
  { step: 'A2P Campaigns', detail: 'Create evergreen campaigns (notifications, auth, care). Auto-rotate templates via Content API' },
  { step: 'Number Procurement', detail: 'Bulk-buy local & toll-free; geo-match via Messaging Service' },
  { step: 'Short Code Program', detail: 'Start application asap (8–12 weeks typical). Preload sample messaging + opt-in proof' },
  { step: 'Warm-up & Throughput', detail: 'Ramp volumes; watch carrier feedback via Event Streams' },
  { step: 'Compliance Gates', detail: 'STOP/UNSUB ledger + rate-limiters wired into send path' },
]
