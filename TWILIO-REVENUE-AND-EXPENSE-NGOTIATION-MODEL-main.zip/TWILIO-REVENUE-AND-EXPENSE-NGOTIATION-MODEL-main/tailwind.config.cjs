module.exports = require('./apps/pro-dashboard/tailwind.config.cjs');
