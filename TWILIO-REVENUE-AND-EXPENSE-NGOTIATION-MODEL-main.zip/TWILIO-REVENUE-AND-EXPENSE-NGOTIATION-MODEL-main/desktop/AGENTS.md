# Desktop Instructions
- Use Rust 2021 edition.
- Prefer async reqwest client with structured error handling.
- Configuration should be overridable via environment variables.
